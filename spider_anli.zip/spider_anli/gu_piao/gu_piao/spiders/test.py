#coding = utf-8
import re,requests,json
from lxml import etree
#
#
# # def get_Biaoqian(html):
# #     dr = re.compile(r'<[^>]+>', re.S)
# #     dd = dr.sub(' ', html)
# #     return dd
#
#
#
# url = 'http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?cb=jQuery112403560190627223534_1532313512468&type=CT&token=4f1862fc3b5e77c150a2b985b12db0fd&js=(%7Bdata%3A%5B(x)%5D%2CrecordsTotal%3A(tot)%2CrecordsFiltered%3A(tot)%7D)&cmd=C._A&sty=FCOIATC&st=(ChangePercent)&sr=-1&p=1&ps=20&_=1532313512667'
# dade = {
#  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) "
#  "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36",
# }

# htm = requests.get(url, headers=dade)
# print(htm)
# body = htm.text
# print(body )
# body = json.loads(json_str)
# print(body)
# print(type(body))
# print(body)d
# jsondata=body.replace("jQuery112403560190627223534_1532313512468({data:","").replace(",recordsTotal:3549,recordsFiltered:3549}",'').replace(')','').replace("[",'')
#
#
# jsondata=jsondata.replace('[','').replace(']','')
# jsondata=jsondata.split('"')
# data2=[]
# for i  in jsondata:
#     if len(i)>10:
#         data2 .append(i.split(","))
# for k in data2:
#     print(k[1])

# print(data2)
# data = [jsondata]
# data =jsondata.split(",")
#
#
# # print(type(aa))
# # print(jsondata)
# # cc = jsondata.split('"1,')[1:21]
# # for i in cc:
# #    ss=i.split(",")
# #    aa=ss[0][0]
