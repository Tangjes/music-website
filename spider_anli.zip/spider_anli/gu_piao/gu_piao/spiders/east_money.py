# -*- coding: utf-8 -*-
import scrapy
from gu_piao.items import GuPiaoItem

url="http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?cb=jQuery1124039832551017365314_1532154355340&type=CT&token=4f1862fc3b5e77c150a2b985b12db0fd&js=(%7Bdata%3A%5B(x)%5D%2CrecordsTotal%3A(tot)%2CrecordsFiltered%3A(tot)%7D)&sty=FCOIATC&cmd=C.BK07071&st=(ChangePercent)&sr=-1&"
url2= "http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?cb=jQuery112403560190627223534_1532313512468&type=CT&token=4f1862fc3b5e77c150a2b985b12db0fd&js=(%7Bdata%3A%5B(x)%5D%2CrecordsTotal%3A(tot)%2CrecordsFiltered%3A(tot)%7D)&cmd=C._A&sty=FCOIATC&st=(ChangePercent)&sr=-1&"
class EastMoneySpider(scrapy.Spider):
    name = 'east_money'
    allowed_domains = ['eastmoney.com']

    start_urls = [url2 + "p=%s&ps=20&_=1532313512491" % i for i in range(1, 179)]
                #[[url+"&p=%s&ps=20&_=1532154355345"%i for i in range(1,30)],
    def parse(self, response):

        body = response.body.decode('utf-8').replace("jQuery112403560190627223534_1532313512468({data:","").replace(",recordsTotal:3549,recordsFiltered:3549}",'').replace(')','').replace("[",'')
        jsondata = body
        jsondata = jsondata.replace('[', '').replace(']', '')
        jsondata = jsondata.split('"')
        info = GuPiaoItem()
        data2 = []
        for i in jsondata:
            if len(i) > 10:
                data2.append(i.split(","))
        for item in data2:

            info["dai_ma"] =item[1]
            info["gu_piao_name"] = item[2]
            info["new_frice"] = item[3]+"元"
            info["fudong_price"] = item[4]+"元"
            info["fu_du"] = item[5]+"%"

            info["chen_jiao_liang"] = item[6]
            if len(info["chen_jiao_liang"])>0:
                info["chen_jiao_liang"] = str(int(item[6])/10000)+"万"
                # info["chen_jiao_liang"]=str(info["chen_jiao_liang"])+"万"

            info["chen_jiao_price"]=item[7]
            if len(info["chen_jiao_price"])>0:
                info["chen_jiao_price"]=str(int(item[7])/100000000)+"亿"

            info["zhen_fu"] = item[8]+"%"
            info["max_frice"] = item[9]+"元"
            info["min_price"] = item[10]+"元"
            info["start_price"] =item[11]+"元"
            info["yesterday_price"] = item[12]+"元"
            info["liang_bi"] = item[14]
            info["huan_shou_lv"] = item[15]+"%"
            info["dong_tai"]=item[16]+"%"

            yield info



