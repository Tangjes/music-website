# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class GuPiaoItem(scrapy.Item):
    # define the fields for your item here like:
    # gu_piao_name = scrapy.Field()
    dai_ma=scrapy.Field()#股票代码
    gu_piao_name  =scrapy.Field()#股票名称
    new_frice = scrapy.Field()#最新价格
    fudong_price = scrapy.Field()#浮动价格
    fu_du = scrapy.Field()#浮动率
    chen_jiao_liang=scrapy.Field()#成交量
    chen_jiao_price =scrapy.Field()#交易额度
    zhen_fu = scrapy.Field()#振幅
    max_frice =scrapy.Field()#最高价
    min_price =scrapy.Field()#最低价
    start_price=scrapy.Field()
    yesterday_price=scrapy.Field()#昨收价
    liang_bi =scrapy.Field()#量比
    huan_shou_lv = scrapy.Field()#换手率
    dong_tai=scrapy.Field()#动态

    pass
