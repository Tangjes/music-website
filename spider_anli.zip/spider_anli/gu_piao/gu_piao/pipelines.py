# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import json
import codecs
import pymysql.cursors
import pymongo
import uuid
#
# class GuPiaoPipeline(object):
#     def __init__(self):
#         self.file = codecs.open('east_money.json', 'wb', encoding='utf-8')
#
#     def open_spider(self, spider):
#         pass
#
#     def spider_closed(self, spider):
#         self.file.close()
#
#     def process_item(self, item, spider):
#         print('Json---------------------Write')
#         line = json.dumps(dict(item), ensure_ascii=False) + '\n'
#         self.file.write(line)
#         return item


class GuPiaoPipeline(object):

    def __init__(self):# 连接数据库

        self.connect = pymysql.connect(

            host = 'localhost',  # 数据库地址
            port = 3305,  # 数据库端口
            db = 'east_money',  # 数据库名
            user = 'root',  # 数据库用户名
            passwd = '',  # 数据库密码
            charset = 'utf8',  # 编码方式
            use_unicode = True)# 通过cursor执行增删查改

        self.cursor = self.connect.cursor()

    def process_item(self, item, spider):
        self.cursor.execute(

            """insert into eastmoney(id,dai_ma,gu_piao_name,new_frice,fudong_price,fu_du,chen_jiao_liang,chen_jiao_price,zhen_fu,max_frice,min_price,start_price,yesterday_price,liang_bi,huan_shou_lv,dong_tai)
              value(uuid(),%s,%s, %s,%s, %s,%s, %s,%s, %s,%s, %s,%s, %s,%s,%s)""",  # 纯属python操作mysql知识，不熟悉请恶补
            (
                 item['dai_ma'],  # item里面定义的字段和表字段对应
                 item['gu_piao_name'],
                 item['new_frice'],
                 item['fudong_price'],
                 item['fu_du'],
                 item['chen_jiao_liang'],
                 item['chen_jiao_price'],
                 item['zhen_fu'],
                 item['max_frice'],
                 item['min_price'],
                 item['start_price'],
                 item['yesterday_price'],
                 item['liang_bi'],
                 item['huan_shou_lv'],
                 item['dong_tai'],

             ))# 提交sql语句

        self.connect.commit()
        return item  # 必须实现返回

# class GuPiaoPipeline(object):
#     def __init__(self):
#         cleint = pymongo.MongoClient(host='127.0.0.1',port=27017)
#         db = cleint.scrapybook
#         self.table = db.scrapyread
#
#     def process_item(self, item, spider):
#         items = dict(item)
#         self.table.insert(items)
#         return item
