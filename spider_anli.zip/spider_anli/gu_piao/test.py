from selenium import webdriver


browser = webdriver.Chrome()
browser.get('https://www.baidu.com')
# a = browser.find_element_by_xpath('//div[@class="row wrap-login"]//div[2]//a')
# a.click()
a = browser.find_element_by_xpath('//input[@id="kw"]')
print(a)
a.send_keys('http://www.scrapyd.cn/download/138.html')
a.click()
b=browser.find_element_by_xpath('//input[@id="su"]')
b.click()
c=browser.find_element_by_xpath('//div[@id="content_left"]/div/div[2]/a[2]')
# c.window.open()
# browser.back()

c.click()
print(c)


