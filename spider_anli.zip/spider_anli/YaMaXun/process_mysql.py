import redis
import pymysql
import json


def process_item():
    rediscli = redis.Redis(host='127.0.0.1', port=6379, db=0)  # 创建Redis连接对象
    mysqlcli = pymysql.connect(
            host = 'localhost',  # 数据库地址
            port = 3305,  # 数据库端口
            db = 'ya_ma_xun',  # 数据库名
            user = 'root',  # 数据库用户名
            passwd = '',  # 数据库密码
            charset = 'utf8',  # 编码方式
            use_unicode = True)# 通过cursor执行增删查改 # 创建MySQL连接对象
    count = 0

    while True:
        source, data = rediscli.blpop('YaMaXunSpider:items')  # 使用循环通过redis连接对象的blpop()方法,不断取出redis中的数据(blpop即FIFO,rlpop即FILO)
        data = json.loads(data)  # 将取出的json字符串类型的数据转化为python类型的对象
        try:
            cursor = mysqlcli.cursor()  # 利用mysql连接对象创建cursor操作游标,并使用该操作游标向Mysql表中插入数据,数据通过python对象获取其值
            cursor.execute(

                """insert into yamaxun(book_url,img ,book_name,autother ,Pub_time ,info ,price,star)
                  value(%s,%s,%s,%s, %s,%s, %s, %s)""",  # 纯属python操作mysql知识，不熟悉请恶补
                (
                    data['book_url'],  # data里面定义的字段和表字段对应
                    data['img'],
                    data['book_name'],
                    data['autother'],
                    data['Pub_time'],
                    data['info'],
                    data["price"],
                    data['star'],
                ))  # 提交sql语句

            mysqlcli.connect.commit()
            cursor.close()  # 关闭操作游标
            count += 1
            print("已经成功从redis转移" + str(count) + "条数据到mysql")
        except Exception as e:
            print(e)
        pass


if __name__ == "__main__":
    process_item()