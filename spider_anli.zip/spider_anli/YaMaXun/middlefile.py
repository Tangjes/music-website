# import random
# import base64
# from scrapy import signals
#
# #导入setting中写的UA池和IP池
# from tutorial.settings import USER_AGENTS,PROXIES
#
# #处理请求时候，会被自动调用
# class RandomUserAgent(object):
#     def process_request(self,request,spider):
#         useragent = random.choice(USER_AGENTS)
#         request.headers.setdefault("User_Agent",useragent) #设置请求头
#
# class RandomPROXIES(object):
#     def process_request(self,request,spider):
#         proxy = random.choice(PROXIES)
#         #代理的使用不同于UA，代理要写在request.meta信息里
#         #代理是个字典，第一个值为ip，第二个键位用户名和密码
#         if proxy["user_password"] is None:
#             #判断如果没有代理账户验证用户名和密码则
#             request.meta["proxy"] = "http://" + proxy["ip_port"]
#         else:
#             #如果有代理验证，要对账户密码进行编码转换，使用base64
#             #base64编码是吧3个8位字节，转为4个6位字节，这是怕数据太多
#             base64_userpassword = base64.b64encode(proxy["user_password"])
#             request.meta["proxy"] = "http://" + proxy["ip_port"]
#             #对应到代理服务器的信令格式里
#             request.headers["Proxy-Authorization"] = "Basic" + base64_userpassword












