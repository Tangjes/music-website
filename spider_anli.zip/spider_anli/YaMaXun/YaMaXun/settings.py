# -*- coding: utf-8 -*-

# Scrapy settings for YaMaXun project
#
# For simplicity, this file contains only settings considered important or
# commonly used. You can find more settings consulting the documentation:
#
#     https://doc.scrapy.org/en/latest/topics/settings.html
#     https://doc.scrapy.org/en/latest/topics/downloader-middleware.html
#     https://doc.scrapy.org/en/latest/topics/spider-middleware.html

BOT_NAME = 'YaMaXun'

SPIDER_MODULES = ['YaMaXun.spiders']
NEWSPIDER_MODULE = 'YaMaXun.spiders'


# Crawl responsibly by identifying yourself (and your website) on the user-agent
#USER_AGENT = 'YaMaXun (+http://www.yourdomain.com)'

# Obey robots.txt rules
ROBOTSTXT_OBEY = False

# Configure maximum concurrent requests performed by Scrapy (default: 16)
#CONCURRENT_REQUESTS = 32

# Configure a delay for requests for the same website (default: 0)
# See https://doc.scrapy.org/en/latest/topics/settings.html#download-delay
# See also autothrottle settings and docs
DOWNLOAD_DELAY =3
# The download delay setting will honor only one of:
#CONCURRENT_REQUESTS_PER_DOMAIN = 16
#CONCURRENT_REQUESTS_PER_IP = 16

# Disable cookies (enabled by default)
#COOKIES_ENABLED = False

# Disable Telnet Console (enabled by default)
#TELNETCONSOLE_ENABLED = False

# Override the default request headers:
#DEFAULT_REQUEST_HEADERS = {
#   'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
#   'Accept-Language': 'en',
#}

# Enable or disable spider middlewares
# See https://doc.scrapy.org/en/latest/topics/spider-middleware.html
#SPIDER_MIDDLEWARES = {
#    'YaMaXun.middlewares.YamaxunSpiderMiddleware': 543,
#}

# Enable or disable downloader middlewares
# See https://doc.scrapy.org/en/latest/topics/downloader-middleware.html
# DOWNLOADER_MIDDLEWARES = {

   # 'YaMaXun.middlewares.YamaxunDownloaderMiddleware': 543,
# }

# Enable or disable extensions
# See https://doc.scrapy.org/en/latest/topics/extensions.html
#EXTENSIONS = {
#    'scrapy.extensions.telnet.TelnetConsole': None,
#}

# Configure item pipelines
# See https://doc.scrapy.org/en/latest/topics/item-pipeline.html
# ITEM_PIPELINES = {
#    'YaMaXun.pipelines.YamaxunPipeline': 300,
# }

# Enable and configure the AutoThrottle extension (disabled by default)
# See https://doc.scrapy.org/en/latest/topics/autothrottle.html
#AUTOTHROTTLE_ENABLED = True
# The initial download delay
#AUTOTHROTTLE_START_DELAY = 5
# The maximum download delay to be set in case of high latencies
#AUTOTHROTTLE_MAX_DELAY = 60
# The average number of requests Scrapy should be sending in parallel to
# each remote server
#AUTOTHROTTLE_TARGET_CONCURRENCY = 1.0
# Enable showing throttling stats for every response received:
#AUTOTHROTTLE_DEBUG = False

# Enable and configure HTTP caching (disabled by default)
# See https://doc.scrapy.org/en/latest/topics/downloader-middleware.html#httpcache-middleware-settings
#HTTPCACHE_ENABLED = True
#HTTPCACHE_EXPIRATION_SECS = 0
#HTTPCACHE_DIR = 'httpcache'
#HTTPCACHE_IGNORE_HTTP_CODES = []
#HTTPCACHE_STORAGE = 'scrapy.extensions.httpcache.FilesystemCacheStorage'
# HTTPERROR_ALLOWED_CODES = [301]
RANDOM_UA_TYPE = 'random'##random    chrome

# DOWNLOADER_MIDDLEWARES = {
#
#    'YaMaXun.MidWare.user_agent_middlewares.RandomUserAgentMiddlware': 543,
#    # 'YaMaXun.middlewares.ProxyMiddleWare':125,
#    # 'YaMaXun.downloadermiddlewares.useragent.UserAgentMiddleware':None,
#
# }
MEDIA_ALLOW_REDIRECTS =True



#在redis中启用调度存储请求队列。
SCHEDULER  =  "scrapy_redis.scheduler.Scheduler"

#确保所有蜘蛛通过redis共享相同的重复过滤器。
DUPEFILTER_CLASS  =  "scrapy_redis.dupefilter.RFPDupeFilter"

#默认请求序列化程序是pickle，但它可以更改为
#具有加载和转储功能的
#任何模块#。请注意，#python版本
#之间的pickle不兼容。#Caveat：在python 3.x中，序列化程序必须返回字符串键并支持
#bytes作为值。由于这个原因，json或msgpack模块
#默认
#不会#工作。在python 2.x中没有这样的问题，您可以使用#'json'或'msgpack'作为序列化程序。
#SCHEDULER_SERIALIZER ="scrapy_redis.picklecompat"

#不要清理redis队列，允许暂停/恢复抓取。
SCHEDULER_PERSIST = True

#使用优先级队列安排请求。（默认）
SCHEDULER_QUEUE_CLASS ='scrapy_redis.queue.PriorityQueue'

#替代队列。
#SCHEDULER_QUEUE_CLASS ='scrapy_redis.queue.FifoQueue' 
#SCHEDULER_QUEUE_CLASS ='scrapy_redis.queue.LifoQueue'

#最大空闲时间，防止蜘蛛在分布式爬网时被关闭。
#这仅在队列类为SpiderQueue或SpiderStack时才有效，
#也可能在您的蜘蛛第一次启动时阻塞同一时间（因为队列为空）。
#SCHEDULER_IDLE_BEFORE_CLOSE = 10

#将已删除的项目存储在redis中进行后期处理。
ITEM_PIPELINES  =  { 
    'scrapy_redis.pipelines.RedisPipeline': 300

}

#项目管道序列化并存储此redis密钥中的项目。
#REDIS_ITEMS_KEY ='％（蜘蛛）s：items'

#项目序列化程序默认为ScrapyJSONEncoder。您可以使用任何
#advableable路径到可调用对象。
#REDIS_ITEMS_SERIALIZER ='json.dumps'

#指定连接到Redis时使用的主机和端口（可选）。
REDIS_HOST ='localhost'
REDIS_PORT = 6379

#指定用于连接的完整Redis URL（可选）。
#如果设置，则优先于REDIS_HOST和REDIS_PORT设置。
#REDIS_URL ='redis：// user：pass @ hostname：9001'


#Custom 
#redis客户端参数（即：套接字超时等）#REDIS_PARAMS = {} #使用自定义redis客户端类。
#REDIS_PARAMS ['redis_cls'] ='myproject.RedisClient'

#如果为True，则使用redis'``spop``操作。如果您
#希望避免在开始网址列表中出现重复项，
#这可能很有用。在这种情况下，必须通过``sadd``命令添加
#URL，否则你将从redis中获得类型错误。#REDIS_START_URLS_AS_SET =错误

#RedisSpider和RedisCrawlSpider的默认启动URL键。
#REDIS_START_URLS_KEY ='％（name）s：start_urls'

#使用除utf-8之外的其他编码进行redis。
#REDIS_ENCODING ='latin1'