import re
import uuid


def Deltag2(html):  # 去标签函数

    dr = re.compile(r'<[^>]+>', re.S)
    dd = dr.sub('', html)
    re_cdata = re.compile('//<!--\[CDATA\[[^-->]*//\]\]>', re.I)  # 匹配CDATA
    re_script = re.compile('<\s*script[^>]*>[^<]*<\s*/\s*script\s*>', re.I)  # Script
    re_style = re.compile('<\s*style[^>]*>[^<]*<\s*/\s*style\s*>', re.I)  # style
    re_br = re.compile('<br\s*? ?="">')  # 处理换行
    re_h = re.compile('<!--?\w+[^-->]*>')  # HTML标签
    re_comment = re.compile('<!--[^>]*-->')  # HTML注释
    re_k = re.compile('<>')
    re_zz = re.compile('>')
    re_baiduyuedu = re.compile('<ul')
    re_wangyiyunyuedu = re.compile('descriptionj-desc"')
    re_dangdangyuedu = re.compile('&#47;')
    re_doubanfilm = re.compile('\u3000')
    re_doubanfilm2 = re.compile('\u200e')


    s = re_cdata.sub('', dd)  # 去掉CDATA
    re_kong = re.compile('&nbsp;')
    re_ch = re.compile('查看职位地图')
    re_m = re.compile('class="')
    re_mm =re.compile('tab-inner-cont"')
    re_mmm=re.compile('style="display:none;word-wrap:break-word;"')
    s = re_m.sub('',s)
    s = re_mm.sub('',s)
    s =re_mmm.sub('',s)
    re_s = re.compile('\s*')
    s = re_script.sub('', s)  # 去掉SCRIPT
    s = re_style.sub('', s)  # 去掉style
    s = re_br.sub('\n', s)  # 将br转换为换行
    blank_line = re.compile('\n+')  # 去掉多余的空行
    s = blank_line.sub('\n', s)
    s = re_s.sub('',s)
    s = re_ch.sub('',s)
    s = re_kong.sub('',s)
    s = re_k.sub('',s)
    s = re_zz.sub('',s)
    s = re_baiduyuedu.sub('',s)
    s = re_wangyiyunyuedu.sub('',s)
    s = re_dangdangyuedu.sub('',s)
    s = re_doubanfilm.sub('',s)
    s = re_doubanfilm2.sub('',s)


    return s


def getNumber(html):
    if 'class="rating_nums"' in html:
        s = re.findall('class="rating_nums">(.*?)<',html)
        return s
    else:
        return ' '
def getuuid():
    uuidkey = uuid.uuid4()
    return uuidkey

def ifNone(res):
    if res:
        res = res[0]
    else:
        res = ' '
    return res