<?php
    $hou_uname = $_POST["hou_uname"];
    $hou_upass = $_POST["hou_upass"];
    if($hou_uanme == "admin" and $hou_upass == "111"){
        echo "用户名和密码正确";
    }else{
        echo"用户民和密码不正确";
    }
?>
