from scrapy import cmdline
import time
while 1:
    name = 'shuma'
    cmd = 'scrapy crawl {0}'.format(name)
    cmdline.execute(cmd.split())
