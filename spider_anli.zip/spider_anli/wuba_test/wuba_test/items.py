# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy
import datetime 

class WubaTestItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    shu_ma_url = scrapy.Field()
    # 详情连接
    shu_ma_name = scrapy.Field()
    shu_ma_price = scrapy.Field()
    shu_ma_desc = scrapy.Field()
    shu_ma_img = scrapy.Field()
    shu_ma_addr = scrapy.Field()
    # shu_ma_time = datetime
    pass
