aa = "{1}，{0}"
aa= aa.format("hello","python")
print(aa)

a= ("a","c","d","f")

