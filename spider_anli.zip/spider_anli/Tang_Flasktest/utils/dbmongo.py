from pymongo import MongoClient
import config
conn = MongoClient(config.MongoConfig.MongoIp,config.MongoConfig.MongoPort)
db = conn.yjzx
