#coding=utf-8
import logging
try:
    logging.basicConfig(level=logging.INFO,filename= "F:\资料\mongo资料\Flasktest\my.log",
                        format="[%(asctime)s -%(filename)s-%(levelname)s-%(module)s]:%(message)s")
    logger = logging.getLogger()
except Exception as e:
    print(e)