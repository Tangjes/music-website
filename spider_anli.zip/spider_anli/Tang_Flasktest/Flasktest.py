from flask import Flask,render_template,request,redirect,session
from utils import util
import re,datetime
from biz import userbit,sessionbiz
from Shu_Ju import user_biao
from flask import make_response
import uuid,hashlib

app = Flask(__name__)
app.secret_key = r'O$9\xa2\xc3n\xbd\x84|\\\xbf\xf9\xc5\x18\x01w\x85~\xecd\xfc\xa8 \xd4'
@app.route('/')
@app.route("/index")
def index():
    sessionId = request.cookies.get('sessionId')
    if sessionId:
        return redirect('music')
    else:
        return render_template('index.html')

@app.route('/register')
@app.route('/register/<massage>')
def register(massage=None):
    return render_template("register.html",massage=massage)

@app.route('/login')
@app.route('/login/<massage>')
def login(massage=None):
    return render_template("login.html",massage=massage)

@app.route('/music')
def music():
    return render_template("music.html")

@app.route('/registers',methods=['POST'])
def registers():
    data=request.form
    username=data["username"]
    if len(username.strip())<5 or len(username.strip())>10:
        return redirect('register/您注册的账号不合规范')
    password=data["password"]
    if len(password.strip())<6 or len(password.strip())>12 :
        return redirect('register/您输入的密码不合理')
    email=data["email"]
    phoneNo=data["phoneNo"]
    info=re.search('^1[3458][0-9]{9}$',phoneNo)
    count= userbit.getUserByUserName(username=username)
    if info==None:
        return redirect('register/请输入正确的电话号码')
    elif count==None:
        userbit.insertUser(username=username, password=password, email=email, phoneNo=phoneNo)
        return render_template('music.html')
    else:
        return redirect('/register/你输入的账号已经被注册')

@app.route('/logins', methods=['POST'])
def logins():
    data=request.form
    username=data["username"]
    password=data["password"]
    count2 = userbit.getUserByUserName(username=username)
    if  count2!=None:
        count2 = userbit.iscorrectUserAndPassword(username=username,password=password)
        if count2!= None:
            outdate = datetime.datetime.now() + datetime.timedelta(minutes=30)
            sessiondata = sessionbiz.insertSession(userId=count2["userId"])
            resp = make_response(redirect('/music'))
            resp.set_cookie('sessionId', sessiondata["sessionId"], expires=outdate)
            session['sessionId'] = sessiondata["sessionId"]
            return resp
            # return render_template('success.html')
    return redirect('/login/用户名和密码不正确')
@app.route('/xieyi')
def xieyi():
    return render_template('xieyi.html')

@app.route('/',methods=['POST'])

def inserSpider():
    userId = request.form.get('userId')
    sig =request.form.get('sig')
    body =request.form.get('body')
    url=request.form.get('url')
    title =request.form.get('title')
    infoId = request.form.get('infoId')
    timestamp =request.form.get('timestamp')
    mw = body + title + userId + timestamp
    h1 = hashlib.md5()
    h1.update(mw.encode(encoding="utf-8"))


    return render_template('xieyi.html')

if __name__ == '__main__':
    app.run(port=5060,host="0.0.0.0")
