from utils import dbmongo,util#操作数据表
import requests
db=dbmongo.db
table=db.usertable

def insertData(userId,username,password,phoneNo,email):#插入数据
    datauser=None
    try:
        datauser={"userId":userId,"username":username,"password":password,"phoneNo":phoneNo,"email":email}
        table.insert(datauser)
        return datauser
    except Exception as e:
        util.logger.error(e)
        return None

def updataData():
    pass

def selectData(**kwargs):
    try:
        userdata = table.find_one(kwargs)
        return userdata
    except Exception as e:
        util.logger.error(e)
        return None

def selectUser(username):
    count = 0
    try:
        count = table.find({"$or": [{"username": username}, {"phoneNo": username}, {"email": username}]}).count()
    except Exception as e:
        util.logger.error(e)
    return count

# def getselectRequest(username,password):
# #查询用户名及密码是否匹配及存在
#     count2=0
#     try:
#         count2 = table.find({"username": username, "password": password}).count()#计数查询，存在则说明用户名正确
#         # a=list(count2)
#         # username1=a['username']
#         # password1=a['password']
#     except Exception as e:
#         util.logger.error(e)
#     return count2
def deleteData():
    pass

