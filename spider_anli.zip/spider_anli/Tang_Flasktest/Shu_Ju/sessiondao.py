from utils import dbmongo, util

db = dbmongo.db
table = db.sessionTable


def insertSession(userId, sessionId):
    try:
        datauser = {"userId": userId, "sessionId": sessionId}
        table.insert(datauser)
        return datauser
    except Exception as e:
        util.logger.error(e)
        return None