class MongoConfig():
    MongoIp = "127.0.0.1"
    MongoPort= 27017

class MysqlConfig():
    MongoIp = "127.0.0.1"
    MongoPort = 3306

