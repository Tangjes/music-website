from Shu_Ju import sessiondao
import uuid


def insertSession(userId):
    sessionId = str(uuid.uuid4())
    return sessiondao.insertSession(userId=userId, sessionId=sessionId)
