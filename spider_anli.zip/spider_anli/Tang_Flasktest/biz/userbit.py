from Shu_Ju import user_biao
import uuid
def getUserByUserName(username):
    return user_biao.selectData(username=username)


def insertUser(username,password,email,phoneNo):
    userId=str(uuid.uuid4())
    datauser=user_biao.insertData(userId=userId,username=username,password=password,email=email,phoneNo=phoneNo)
    return datauser

# def getLoginRequest(username,password):
#     return user_biao.getselectRequest(username=username,password=password)

def iscorrectUser(username,password):
    count = user_biao.selectUser(username=username)
    if count is not None:
        userdata = user_biao.selectData(username=username,password=password)
        return userdata
    return count

def iscorrectUserAndPassword(username,password):
    userdata= user_biao.selectData(username=username,password=password)
    return userdata