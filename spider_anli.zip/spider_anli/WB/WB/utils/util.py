import re

def get_Biaoqian(html):
    dr = re.compile(r'<[^>]+>', re.S)
    dd = dr.sub(' ', html)
    return dd
