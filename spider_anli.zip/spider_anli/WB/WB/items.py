# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class WbItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    jia_ju_url = scrapy.Field()
    # 详情连接
    jia_ju_name = scrapy.Field()
    jia_ju_price = scrapy.Field()
    jia_ju_desc = scrapy.Field()
    jia_ju_img = scrapy.Field()
    jia_ju_addr = scrapy.Field()
    pass
