#
# import re
# # #
# # aa= '/shouji/pn2/'
# # # print(aa.split("/"))
# # start_urls = ['https://hf.58.com/shouji/']
# # print(start_urls[0] +aa.split("/")[2])
# aa='<spanclass="zz_tag"><spanclass="tag">验货面付</span></span>'
#//td[@class='t t_b']| //td[@class='t']
# aa=re.sub(r'\s+', '',aa)
# print(aa)