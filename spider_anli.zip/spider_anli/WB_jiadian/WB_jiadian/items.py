# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class WbJiadianItem(scrapy.Item):
    jiadian_url = scrapy.Field()
    # 详情连接
    jiadian_name = scrapy.Field()
    jiadian_price = scrapy.Field()
    jiadian_desc = scrapy.Field()
    jiadian_img = scrapy.Field()
    jiadian_addr = scrapy.Field()
    # define the fields for your item here like:
    # name = scrapy.Field()
    pass
