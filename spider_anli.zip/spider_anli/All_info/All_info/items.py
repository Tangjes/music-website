# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class AllInfoItem(scrapy.Item):
    
    wu_ba__url = scrapy.Field()
    wu_ba__name = scrapy.Field()
    wu_ba__price = scrapy.Field()
    wu_ba__desc = scrapy.Field()
    wu_ba__img = scrapy.Field()
    wu_ba__addr = scrapy.Field()

