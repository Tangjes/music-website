# -*- coding: utf-8 -*-
import scrapy,re
from All_info.utils import util
from All_info.items import AllInfoItem


class wu_ba_Spider(scrapy.Spider):
    name = 'wuba_ershou'
    allowed_domains = ['58.com']
    start_urls = util.get_city()
    def parse(self,response):

        a=response.xpath('//tbody/tr')
        for each in a:
            item = AllInfoItem()
            item['url']= each.xpath("./div/div/a/@href").extract()[0]
            #city //div[@class='content-cities']/a[@class='content-city']

            item['name'] = each.xpath("./td/a[@class='t']/text()").extract()[0]
            item['name'] = util.get_Biaoqian(item['name'])

            item['price'] = each.xpath("./td/span/span[@class='price']").extract()[0]
            item['price'] = re.sub("\D", "", item['price']) +"RMB"

            item['desc'] = each.xpath("./td/span[@class='desc']").extract()[0]
            item['desc'] = util.get_Biaoqian(item['desc'])

            item['img'] = each.xpath("./td[@class='img']/a/img/@lazy_src").extract()[0]

            item['addr'] = each.xpath("./td/span[@class='fl']").extract()[0]
            item['addr'] = util.get_Biaoqian(item['addr'])
            item['addr'] = item['addr'].replace("\r", "").replace("\n", "").replace("\t", "")
            yield item
