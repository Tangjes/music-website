# def get_all_city():
#     city = []
#     url = "http://www.ganji.com/index.htm"
#     dadt = {
#     "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36",
#     }
#     htm = requests.get(url, headers=dadt)
#     html = htm.text
#     ret = etree.HTML(html)
#     retuu = ret.xpath("//div[@class='all-city']/dl/dd/a/@href")
#
#     if retuu:
#         all_city = ret.xpath("//div[@class='all-city']/dl/dd/a/@href")
#         for i in all_city:
#             a = i[:-1]
#             city.append(a)
#     return city