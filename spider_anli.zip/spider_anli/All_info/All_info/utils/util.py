import re,requests

def get_Biaoqian(html):
    dr = re.compile(r'<[^>]+>', re.S)
    dd = dr.sub(' ', html)
    return dd
import re,requests,scrapy
from lxml import etree

def get_all_lei():
    url = "http://sjz.ganji.com/wu/"
    dadt = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36",
    }
    htm = requests.get(url, headers=dadt)
    html = htm.text
    ret = etree.HTML(html)
    retuu = ret.xpath('//ul/li/div/dl/dd/a/@href')

    if retuu:
        all_lei = ret.xpath('//ul/li/div/dl/dd/a/@href')
        return all_lei

def get_all_city():
    city = []
    url = "http://www.ganji.com/index.htm"
    dadt = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36",
    }
    htm = requests.get(url, headers=dadt)
    html = htm.text
    ret = etree.HTML(html)
    retuu = ret.xpath("//div[@class='all-city']/dl/dd/a/@href")

    if retuu:
        all_city = ret.xpath("//div[@class='all-city']/dl/dd/a/@href")
        for i in all_city:
            a = i[:-1]
            city.append(a)
    return city
