# -*- coding: utf-8 -*-
import pymongo
from pymongo import UpdateMany

class AllInfoPipeline(object):

    def __init__(self):
        client = pymongo.MongoClient('127.0.0.1', 27017)
        self.db = client['wuba_Allinfo']
        self.post = self.db['wbAll_info']

    def process_item(self, item, spider):
        postItem = dict(item)
        self.post.insert(postItem)
        requests = [
            UpdateMany({'wu_ba__url': item['wu_ba__url']}, {'$set': dict(item)},True),]
        self.db.wbAll_info.bulk_write(requests)

