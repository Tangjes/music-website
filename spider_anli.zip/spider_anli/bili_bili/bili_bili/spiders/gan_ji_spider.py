# -*- coding: utf-8 -*-
import scrapy,re,time,datetime
from bili_bili.utils import util
from bili_bili.items import BiliBiliItem
from scrapy_redis.spiders  import RedisSpider


class ShoujiSpider(scrapy.Spider):
    name = 'gangji'
    allowed_domains = ['ganji.com']
    start_urls = util.all_url()

    def parse(self,response):
        a=response.xpath('//tbody/tr')
        for each in a:
            item = BiliBiliItem()
            item['url']= each.xpath("./td[@class ='img']/a/@href").extract()[0]
            item['url'] = item['url'].split("?")[0]

            item['name'] = each.xpath("./td/a[@class='t']/text()").extract()[0]
            item['name'] = util.get_Biaoqian(item['name'])

            item['price'] = each.xpath("./td/span/span[@class='price']").extract()[0]
            item['price'] = re.sub("\D", "", item['price']) +"RMB"

            item['desc'] = each.xpath("./td/span[@class='desc']").extract()[0]
            item['desc'] = util.get_Biaoqian(item['desc']).replace("\n","")

            item['img'] = each.xpath("./td[@class='img']/a/img[@class='js-lazy-load']/@src").extract()[0]

            item['addr'] = each.xpath("./td/span[@class='fl']").extract()[0]
            item['addr'] = util.get_Biaoqian(item['addr'])
            item['addr'] = item['addr'].replace("\r", "").replace("\n", "").replace("\t", "")
            yield item





