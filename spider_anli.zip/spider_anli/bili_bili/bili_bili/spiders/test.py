# #coding = utf-8
# import re,requests,scrapy
# from lxml import etree
# url = "https://sou.zhaopin.com/?jl=765&kw=python&kt=3"
#
# dade = {
#     "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) "
#                   "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36",
# }
#
# htm = requests.get(url, headers=dade)
# html = htm.text
# ret = etree.HTML(html)
# retuu = ret.xpath('//*[@id="listContent"]/div/div/div/div[1]/a/@href')
#
# if retuu:
#     all_lei = ret.xpath('//*[@id="listContent"]/div/div/div/div[1]/a/@href').extract()
#     for item in all_lei:
#         print(item)