# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import pymongo
from pymongo import UpdateMany


class bili_biliPipeline(object):

    def __init__(self):
        client = pymongo.MongoClient('127.0.0.1', 27017)  # 建立MongoDB数据库连接
        self.db = client['ganji_info']  # 连接所需数据库,wuba_Allinfo为数据库名
        self.post = self.db['Allganji_info']  # 连接所用集合，也就是我们通常所说的表，wbAll_info为表名

    def process_item(self, item, spider):
        postItem = dict(item)  # 把item转化成字典形式
        self.post.insert(postItem)  # 向数据库插入一条记录
        requests = [
            UpdateMany({'url': item['url']}, {'$set': dict(item)}, True), ]  # mongo去重
        self.db.Allganji_info.bulk_write(requests)

# from datetime import datetime
#
#
# class ExampPipeline(object):
#
#     def process_item(self,item,spider):
#        item['crawled'] = datetime.utcnow()  # 调用datetime.utcnow()方法获取爬虫执行时的UTC时间
#        item['spider'] = spider.name         # 调用spider.name属性获取当前爬虫名(因为可能同时有多个爬虫在爬取,这样可以看到谁爬了哪些网页)
#        return item