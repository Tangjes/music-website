#!/usr/bin/env python
#coding:utf-8

import redis
import pymongo
import json
def process_item():
      rediscli = redis.Redis(host='127.0.0.1',port=6379,db=0)       # 创建Redis连接对象
      mongocli = pymongo.MongoClient(host='127.0.0.1',port=27017)   # 创建MongoDB连接对象
      db_name = mongocli['gabji']                                       # 利用MongoDB连接对象在MongoDB中创建名为youyuan的数据库对象
      sheet_name = db_name['ganji_Allinfo']                                # 利用该数据库对象在youyuan数据库中创建名为beijing18-24的表对象
      count = 0
      while True:
         source,data = rediscli.blpop("ganji:items")                        # 使用循环通过redis连接对象的blpop()方法,不断取出redis中的数据(blpop即FIFO,rlpop即FILO)
         data = json.loads(data)                                         # 将取出的json字符串类型的数据转化为python类型的对象
         sheet_name.insert(data)
         # 利用mongodb的表对象的insert()方法,向表中插入(刚才转化的python对象)
         count += 1
         print ("已经成功从redis转移" + str(count) + "条数据到mongodb")

if __name__ == "__main__":
 process_item()