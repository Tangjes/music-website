# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class WbComputerItem(scrapy.Item):
    computer_url = scrapy.Field()
    # 详情连接
    computer_name = scrapy.Field()
    computer_price = scrapy.Field()
    computer_desc = scrapy.Field()
    computer_img = scrapy.Field()
    computer_addr = scrapy.Field()