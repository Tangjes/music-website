#coding  = utf-8
# def div1(x,y):
#     print("%s/%s=%s"%(x,y,x/y))
# def div2(x,y):
#     print("%s//%s=%s" % (x, y, x // y))
# div1(5,2)
# div1(5.,2)
# div2(5,2)
# div2(5.,2.)


# a= [1,3,4,6,2,7,9,43]
#
# for i in range(len(a)-1):
#     for j in range(len(a)-i-1):
#         if a[j]>a[j+1]:
#             a[j],a[j+1]=a[j+1],a[j]
# print(a)
#https://search.jd.com/s_new.php?keyword=%E6%8A%A4%E8%82%A4%E5%93%81&enc=utf-8&qrst=1&rt=1&stop=1&vt=2&wq=%E6%8A%A4%E8%82%A4%E5%93%81&stock=1&page=2&s=28&scrolling=y&log_id=1532337910.71138