# -*- coding: utf-8 -*-
import scrapy,re
from mei_shi.utils import util
from mei_shi.items import MeiShiItem


class Mei_shi_Spider(scrapy.Spider):
    name = 'meishi'
    url = "http://www.xiachufang.com"
    allowed_domains = ['xiachufang.com']
    start_urls = ["http://www.xiachufang.com/explore/monthhonor/?page=1",
                  "http://www.xiachufang.com/explore/monthhonor/?page=2"
                  ]
    # start_urls = util.get_city()
    # def parse(self,response):
    def parse(self, response):
        # urls = []
        a=response.xpath('//div/ul/li[@class="pure-g"]')
        item = MeiShiItem()

        for each in a:

            item['url']= each.xpath("./div/div/a/@href").extract()[0]
            item['url']="http://www.xiachufang.com" +item['url']

            item['name'] = each.xpath("./div/div/a/div/img/@alt").extract()[0]
            item['name'] = util.get_Biaoqian(item['name']).replace("\n","")

            item['yuanliao'] = each.xpath("./div/div/div/p[2]").extract()[0]
            item['yuanliao'] = util.get_Biaoqian(item['yuanliao']).replace("\n","")

            item['pinfeng'] = each.xpath("./div/div/div/p[3]").extract()[0]
            item['pinfeng'] = util.get_Biaoqian(item['pinfeng']).replace("\n","")

            item['img'] = each.xpath("./div/div/a/div/img/@data-src").extract()[0]

            item['author'] = each.xpath("./div/div/div/p[4]").extract()[0]
            item['author'] = util.get_Biaoqian(item['author']).replace("\n","")

        yield scrapy.Request(item['url'],callback=self.s_parse,meta={'tjs':item})

    def s_parse(self,response):
        item = response.meta['tjs']
        item["desc"]= response.xpath('//div[@class="block recipe-show"]/div[6]/text()').extract()
        # item['desc'] = util.get_Biaoqian(item['desc'])
        item["cai_liao"]=response.xpath('//tbody').extract()
        item['cai_liao'] = util.get_Biaoqian(item['cai_liao'])

        yield item
