# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import pymongo
from pymongo import UpdateMany

class MeiShiPipeline(object):

    def __init__(self):
        client = pymongo.MongoClient('127.0.0.1', 27017) # 建立MongoDB数据库连接
        self.db = client['Mei_shi']        # 连接所需数据库,wuba_Allinfo为数据库名
        self.post = self.db['Mei_shi_info']# 连接所用集合，也就是我们通常所说的表，wbAll_info为表名

    def process_item(self, item, spider):
        postItem = dict(item)  # 把item转化成字典形式
        self.post.insert(postItem)  # 向数据库插入一条记录
        # requests = [
        #     UpdateMany({'url': item['url']}, {'$set': dict(item)},True),]#mongo去重
        # self.db.wbAll_info.bulk_write(requests)

        return item