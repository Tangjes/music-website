#coding = utf-8

import json
import ssl
import requests
# import urllib3
#
# urllib3.disable_warnings()
# response = requests.get('https://www.12306.cn', verify=False)
# print(response.status_code)

# 2. 表示忽略未经核实的SSL证书认证
# context = ssl._create_unverified_context()

url = "https://app.newinterface.jescard.com/goods/detail.html?mallId=null&skuId=cartier_cn@b4086100_b4086144&script=true&language=zh&timestamp=1531450129461&t=1531450129463"
hearers = {
 "User-Agent": "Mozilla/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Mobile Safari/537.36"
 "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36",
}
html = requests.get(url, headers=hearers,verify=False)

# response = urllib.open(html, context = context,)


# data = json.loads()
# jsondata = data["result"]["data"]
print(html)