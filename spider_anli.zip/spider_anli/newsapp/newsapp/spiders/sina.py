# -*- coding: utf-8 -*-
import scrapy
from newsapp.items import NewsappItem
import json
from newsapp.utilz import util
from newsapp.dao import infodao
from newsapp.items import NewsappItem, News2
import re


class SinaSpider(scrapy.Spider):
    name = 'sina'

    # allowed_domains = ['sina.com.cn']
    # start_urls = [
    #         'https://feed.sina.com.cn/api/roll/get?pageid=123&lid=1367&num=20&versionNumber=1.2.4&page=%s&encode=utf-8&callback=feedCardJsonpCallback' % i
    #         for i in range(1, 16)]
    def start_requests(self):
        urls = [
            'https://feed.sina.com.cn/api/roll/get?pageid=123&lid=1367&num=20&versionNumber=1.2.4&page=1&encode=utf-8&callback=feedCardJsonpCallback' % i
            for i in range(1, 16)]
        for item in urls:
            yield scrapy.Request(url=item, callback=self.parse222)

    def parse222(self, response):
        body = response.body.decode('utf-8').replace('try{feedCardJsonpCallback(', '').replace(');}catch(e){};', '')
        data = json.loads(body)
        jsondata = data["result"]["data"]
        for item in jsondata:
            # TODO 如果时间已经不在是两天内的时间了，不需要再去爬取了
            intime = item["intime"]
            intime = util.getDatetime(intime)[:10]
            flag = util.getCompareTime(intime)
            if flag == True:
                # TODO 已经存在的URL不再爬取（redis），mysql去重
                url = item["url"]
                # rs = infodao.getDataByURl(url)
                # if rs[0] == 0:
                news = NewsappItem()
                news["url"] = url
                news['title'] = item['title']
                news["pushtime"] = intime
                yield scrapy.Request(url=url, callback=self.parsedetail, meta={"news": news})
                # yield news

    def parsedetail(self, response):
        news = response.meta["news"]
        body = response.body.decode('utf-8').replace('\n', '')
        bodydata = re.findall('id="article">(.*?)<p class="show_author">', body)
        if len(bodydata) > 0:
            news["body"] = bodydata[0]
        yield news
