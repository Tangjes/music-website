#coding=utf-8

import requests
from bs4 import BeautifulSoup as bs
import re

headers = {
    'User-Agent': 'Mozilla/4.0+(compatible;+MSIE+8.0;+Windows+NT+5.1;+Trident/4.0;+GTB7.1;+.NET+CLR+2.0.50727)'
}  # 设置UA模拟用户，还可设置多个UA提高搜索成功率

def baidu_url(word): # 构建百度搜索URL；因为是查收录，所以只显示了前10个搜索结果，还可以通过rn参数来调整搜索结果的数量
    '''
    get baidu search url
    '''
    return 'http://www.baidu.com/s?wd=%s' % word


def baidu_cont(url):  # 获取百度搜索结果页内容
    r = requests.get(url, headers=headers)
    return r.content


def serp_links(word):  #获取百度搜索结果的最终URL
    '''
    get baidu serp links with the word
    '''
    b_url = baidu_url(word)
    soup = bs(baidu_cont(b_url))
    b_tags = soup.find_all('h3', {'class': 't'})  # 获取URL的特征值是通过class="t"
    b_links = [tag.a['href'] for tag in b_tags]
    real_links = []
    for link in b_links:  # 使用requests库获取了最终URL，而不是快照URL
        try:
            r = requests.get(link, headers=headers, timeout=120)
        except Exception as e:
            real_links.append('page404')
        else:
            real_links.append(r.url)
    return real_links


def indexer(url):  # 待查URL是否在百度搜索结果的URL列表中，如果在就表示收录，反之未收录
    indexed_links = serp_links(url)
    if url in indexed_links:
        return True
    else:
        return False

aa= baidu_url("http://www.scrapyd.cn/download/138.html")