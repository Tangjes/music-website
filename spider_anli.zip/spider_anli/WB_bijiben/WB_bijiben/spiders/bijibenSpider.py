# -*- coding: utf-8 -*-
import scrapy,re,requests
from WB_bijiben.utils import util

from WB_bijiben.items import WbBijibenItem


ret = requests.get("http://www.58.com/changecity.html?")#发送URL请求
b=ret.status_code
ret.encoding='utf-8'#编码是utf-8
d= ret.content.decode('utf-8').replace('\n','').replace('\r','').replace('\t','').replace('{','').replace(' }','')
z =re.findall(' var cityList =(.*?) "其他"',d)
aa = str(z)
cc= re.sub('[^a-zA-Z]+',',',aa)
sd = str(cc)
ct = sd.split(",")
ct= ct[:-1]
del ct[0]

urls = ["http://%s.58.com/bijiben/" % i for i in ct]
start_urls = []
for i in urls:
    url = [i + "pn%s" % page for page in range(1, 11)]
    for x in url:
        start_urls.append(x)

class Bijiben_Spider(scrapy.Spider):
    name = 'bijiben'
    allowed_domains = ['58.com']
    url = "http://hf.58.com/bijiben/pn"
    # offset = 1
    start_urls = start_urls

    def parse(self,response):
        a=response.xpath('//tbody/tr')
        for each in a:
            item = WbBijibenItem()
            # 手机url
            item['bijiben_url']= each.xpath("./td[@class ='img']/a/@href").extract()[0]

            item['bijiben_name'] = each.xpath("./td/a[@class='t']/text()").extract()[0]
            item['bijiben_name'] = util.get_Biaoqian(item['bijiben_name'])
            # 手机价格
            item['bijiben_price'] = each.xpath("./td/span/span[@class='price']").extract()[0]
            item['bijiben_price'] = re.sub("\D", "", item['bijiben_price']) +"RMB"
            # 手机描述
            item['bijiben_desc'] = each.xpath("./td/span[@class='desc']").extract()[0]
            item['bijiben_desc'] = util.get_Biaoqian(item['bijiben_desc'])
            # 手机图片
            item['bijiben_img'] = each.xpath("./td[@class='img']/a/img/@lazy_src").extract()[0]
            # 出售地址
            item['bijiben_addr'] = each.xpath("./td/span[3]").extract()[0]
            item['bijiben_addr'] = util.get_Biaoqian(item['bijiben_addr'])
            # item['bijiben_addr'] = re.sub(r'\s+', '', item['bijiben_addr']) td/span[3]

            yield item




