# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class WbBijibenItem(scrapy.Item):
    # -*- coding: utf-8 -*-

    # Define here the models for your scraped items
    #
    # See documentation in:
    # https://doc.scrapy.org/en/latest/topics/items.html

    # define the fields for your item here like:
    # name = scrapy.Field()
    bijiben_url = scrapy.Field()
    # 详情连接
    bijiben_name = scrapy.Field()
    bijiben_price = scrapy.Field()
    bijiben_desc = scrapy.Field()
    bijiben_img = scrapy.Field()
    bijiben_addr = scrapy.Field()

    # define the fields for your item here like:
    # name = scrapy.Field()
    pass
