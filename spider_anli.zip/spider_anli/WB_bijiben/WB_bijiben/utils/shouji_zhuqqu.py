import re,requests,scrapy,json
url = "https://app.newinterface.jescard.com/goods/detail.html?mallId=null&skuId=cartier_cn@"
dade = {
 "User-Agent": "Mozilla/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Mobile Safari/537.36"
 "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36",
}
htm = requests.get(url, headers=dade)
data = htm.json()
print(htm)

