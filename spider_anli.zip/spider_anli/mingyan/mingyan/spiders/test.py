import re

urls = 'http://hf.58.com/shouji/pn2/'
urrr= 'http://lab.scrapyd.cn/page/2/'

aa=urls[-2]
bb = urrr[-2]

print(bb)