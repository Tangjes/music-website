from scrapy import cmdline

cmdline.execute("scrapy crawl shouji".split())