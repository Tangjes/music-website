# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class WubaInfoItem(scrapy.Item):
    # 职位名
    mobile_url = scrapy.Field()
    # 详情连接
    mobile_img = scrapy.Field()
    # 职位类别
    mobile_name= scrapy.Field()
    # 招聘人数
    mobile_price = scrapy.Field()
    # 工作地点
    mobile_desc = scrapy.Field()
    # 发布时间
    mobile_addr = scrapy.Field()

    pass
