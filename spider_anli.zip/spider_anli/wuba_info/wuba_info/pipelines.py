# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import json

# class WubaInfoPipeline(object):
#     def __init__(self):
#         self.filename = open("58.json", "w")
#
#     def process_item(self, item, spider):
#         text = json.dumps(dict(item), ensure_ascii = False) + ",\n"
#         self.filename.write(text.encode("utf-8"))
#         return item
#
#     def close_spider(self, spider):
#         self.filename.close()
#
import json
import codecs
#写pipeline时需要注意编码问题的处理
class WubaInfoPipeline(object):
    def __init__(self):
        self.file = codecs.open('shouji.json', mode='wb',encoding='utf-8')
    def process_item(self, item, spider):
        line = json.dumps(dict(item), ensure_ascii=False)+'\n'# ensure_ascii=False很重要
        self.file.write(line)
        return item
    def close_spider(self,spider):
        self.file.close()