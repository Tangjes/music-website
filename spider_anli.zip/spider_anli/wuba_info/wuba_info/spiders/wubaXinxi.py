#coding =utf-8
import scrapy
import requests
import re
from wuba_info.items import WubaInfoItem

class citySpider(scrapy.Spider):
    name = "shouji"
    allowed_domains = ["58.com"]
    start_urls = ["http://hf.58.com/shouji/pn1"]

    def parse(self, response):
        # global start_urls //tbody/tr
        aa = response.xpath('//tbody/tr[@class="zzinfo"]')
        print(aa)
        # for each in response.xpath('//tbody/tr[@class="zzinfo"]'):
        #     # 初始化模型对象
        #     item = WubaInfoItem()
        #     item['mobile_url']= each.xpath("//tr/td[2]/a/@href").extract()[0]
        #     # 手机名称
        #     item['mobile_name'] = each.xpath("//a[@class='t']").extract()[0]
        #     # 手机价格
        #     item['mobile_price'] = each.xpath("//span[@class='price']").extract()[0]
        #     # 手机描述
        #     item['mobile_desc'] = each.xpath("//span[@class='red_adinfo']").extract()[0]
        #     # 手机图片
        #     item['mobile_img'] = each.xpath("//td[@class='img']/a/img/@src").extract()[0]
        #     # 出售地址
        #     item['mobile_addr'] = each.xpath("//span[@class='fl']").extract()[0]
        #
        #     next_page = response.xpath('//*[@id="infolist"]/div[5]/a/@href').extract_first()
        #     # if next_page is not None:
        #     #     next_page = response.urljoin(next_page)
        #     #     yield scrapy.Request(next_page, callback=self.parse)
        #     yield item

            # if self.offer < 11:
            #     self.offer += 1

        # yield scrapy.Request(self.start_urls + self.page+str(self.offer) ,callback=self.parse)


