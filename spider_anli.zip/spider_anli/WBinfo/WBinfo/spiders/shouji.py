# -*- coding: utf-8 -*-
import scrapy,re,requests
from WBinfo.utils import util

from WBinfo.items import WbinfoItem


ret = requests.get("http://www.58.com/changecity.html?")#发送URL请求
b=ret.status_code
ret.encoding='utf-8'#编码是utf-8
d= ret.content.decode('utf-8').replace('\n','').replace('\r','').replace('\t','').replace('{','').replace(' }','')
z =re.findall(' var cityList =(.*?) "其他"',d)
aa = str(z)
cc= re.sub('[^a-zA-Z]+',',',aa)
sd = str(cc)
ct = sd.split(",")
ct= ct[:-1]
del ct[0]

urls = ["http://%s.58.com/shouji/" % i for i in ct]
start_urls = []
for i in urls:
    url = [i + "pn%s" % page for page in range(1, 11)]
    for x in url:
        start_urls.append(x)

class ShoujiSpider(scrapy.Spider):
    name = 'shouji'
    allowed_domains = ['58.com']
    url = "http://hf.58.com/shouji/pn"
    # offset = 1
    start_urls = start_urls

    def parse(self,response):
        a=response.xpath('//tbody/tr')
        for each in a:
            item = WbinfoItem()
            # 手机url
            item['mobile_url']= each.xpath("./td[@class ='img']/a/@href").extract()[0]

            item['mobile_name'] = each.xpath("./td/a[@class='t']/text()").extract()[0]
            item['mobile_name'] = util.get_Biaoqian(item['mobile_name'])
            # 手机价格
            item['mobile_price'] = each.xpath("./td/span/span[@class='price']").extract()[0]
            item['mobile_price'] = re.sub("\D", "", item['mobile_price']) +"RMB"
            # 手机描述
            item['mobile_desc'] = each.xpath("./td/span[@class='desc']").extract()[0]
            item['mobile_desc'] = util.get_Biaoqian(item['mobile_desc'])
            # 手机图片
            item['mobile_img'] = each.xpath("./td[@class='img']/a/img/@lazy_src").extract()[0]
            # 出售地址
            item['mobile_addr'] = each.xpath("./td/span[3]").extract()[0]
            item['mobile_addr'] = util.get_Biaoqian(item['mobile_addr'])
            # item['mobile_addr'] = re.sub(r'\s+', '', item['mobile_addr']) td/span[3]

            yield item




