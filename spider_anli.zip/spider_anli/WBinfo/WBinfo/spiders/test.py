# import re,requests,scrapy
#
#
# ret = requests.get("http://www.58.com/changecity.html?")#发送URL请求
# b=ret.status_code
# ret.encoding='utf-8'#编码是utf-8
# d= ret.content.decode('utf-8').replace('\n','').replace('\r','').replace('\t','').replace('{','').replace(' }','')
# z =re.findall(' var cityList =(.*?) "其他"',d)
# aa = str(z)
# cc= re.sub('[^a-zA-Z]+',',',aa)
# sd = str(cc)
# ct = sd.split(",")
# ct= ct[:-1]
# del ct[0]
# print(len(ct))

# urls = ["http://%s.58.com/shouji/"%i for i in ct]
# start_urls = []
# for i in urls:
#     url = [i +"pn%s"%page for page in range(1,11)]
#     for x in url:
#         start_urls.append(x)

