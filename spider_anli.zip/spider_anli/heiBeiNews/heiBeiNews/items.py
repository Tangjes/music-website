# -*- coding: utf-8 -*-
import scrapy

class HeibeinewsItem(scrapy.Item):
    title = scrapy.Field()
    # desc = scrapy.Field()
    newTime = scrapy.Field()
    # define the fields for your item here like:
    # name = scrapy.Field()
    pass

