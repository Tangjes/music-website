import scrapy,re
import requests
from heiBeiNews.items import HeibeinewsItem

class DmozSpider(scrapy.Spider):
    name = "hbNews"
    allowed_domains = ["hebnews.cn"]
    start_urls = [
        "http://sjz.hebnews.cn/node_73703.htm",
        "http://sjz.hebnews.cn/node_73703_2.htm",
        "http://sjz.hebnews.cn/node_73703_3.htm"
    ]
    def parse(self, response):
            data = response.xpath("//div[@class='list']/li")
            for sel in data:
                item = HeibeinewsItem()
                title = sel.xpath('@a').extract()
                newTime= sel.xpath('@span').extract()
                item['title'] = title[0]
                item['newTime'] = newTime[0]
                yield item

