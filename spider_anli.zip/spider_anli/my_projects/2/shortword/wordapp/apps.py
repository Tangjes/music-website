from django.apps import AppConfig


class WordappConfig(AppConfig):
    name = 'wordapp'
