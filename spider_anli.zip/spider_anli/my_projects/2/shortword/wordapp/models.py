from django.db import models


# Create your models here.
class Words(models.Model):
    wordId = models.CharField(max_length=50, primary_key=True)
    userId = models.CharField(max_length=50)
    insertTime = models.CharField(max_length=50)
    opertionTime = models.CharField(max_length=50)
    wordbar = models.CharField(max_length=100)  # 词条
    interpretation = models.CharField(max_length=200)  # 释义
    classification = models.CharField(max_length=100)  # 相关的奥运分类
    onecode = models.IntegerField()
    one = models.CharField(max_length=100)
    demo = models.TextField(blank=True, null=True)
    demoexplan = models.TextField(blank=True, null=True)
    tushi = models.CharField(max_length=255)
    isdelete=models.IntegerField(default=0)
