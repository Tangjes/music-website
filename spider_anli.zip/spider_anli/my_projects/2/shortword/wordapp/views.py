from django.shortcuts import render
from common import userdeco
from .models import Words
from django.http import JsonResponse, HttpResponseRedirect
from django.core.serializers import serialize
from django.core.cache import cache
import json
from django.conf import settings
import os, uuid, datetime
from django.core.paginator import Paginator


# Create your views here.
@userdeco.auth
def wordlist(request, **kwargs):
    userId = kwargs["data"]["userId"]
    words = None
    if request.method == "GET":
        page = request.GET.get('page')
        if int(page) < 6:
            words = cache.get("shortword:data%s" % page)
            if words == None:
                wordsdata = Words.objects.filter(userId=userId, isdelete=0)
                cache.set("shortword:data%s" % page, wordsdata, timeout=1800)
        else:
            words = Words.objects.filter(userId=userId, isdelete=0)
        paginator = Paginator(words, 2)
        contacts = paginator.get_page(page)
        return render(request, 'wordapp/personlist.html', {"words": contacts})
        #     return render(request, 'wordapp/personlist2.html')
        # else:
        #     words = Words.objects.filter(userId=userId).order_by('-insertTime')
        #     sea = serialize("json", words)
        #     data = json.loads(sea)
        #     return JsonResponse({"words": data})


@userdeco.auth
def addword(request, **kwargs):
    userId = kwargs["data"]["userId"]
    if request.method == "GET":
        return render(request, 'wordapp/addword.html')
    else:
        data = request.POST
        wordId = str(uuid.uuid4())
        tushi = ''
        try:
            f1 = request.FILES.get('tushi')
            tushi = wordId + f1.name
            fname = os.path.join(settings.MEDIA_ROOT, tushi)
            with open(fname, 'wb') as pic:
                for c in f1.chunks():
                    pic.write(c)
        except Exception as e:
            print(e)
        wordbar = data['wordbar']
        interpretation = data['interpretation']
        classification = data['classification']
        onecode = data['onecode']
        one = data['one']
        demo = data['demo']
        demoexplan = data['demoexplan']
        rs = Words.objects.filter(wordbar=wordbar)
        if len(rs) == 0:
            word = Words()
            word.wordId = wordId
            word.userId = userId
            word.insertTime = str(datetime.datetime.now())
            word.opertionTime = str(datetime.datetime.now())
            word.wordbar = wordbar
            word.interpretation = interpretation
            word.classification = classification
            word.onecode = onecode
            word.one = one
            word.demo = demo
            word.demoexplan = demoexplan
            word.tushi = tushi
            word.save()
        return HttpResponseRedirect('/word/')


@userdeco.auth
def updateword(request, **kwargs):
    userId = kwargs["data"]["userId"]
    wordId = request.GET.get('wordId')
    word = Words.objects.get(wordId=wordId)
    if request.method == "GET":
        return render(request, 'wordapp/updateword.html', {"word": word})
    else:
        data = request.POST
        f1 = request.FILES.get('tushi')
        if f1 != None:
            tushi = wordId + f1.name
            fname = os.path.join(settings.MEDIA_ROOT, tushi)
            with open(fname, 'wb') as pic:
                for c in f1.chunks():
                    pic.write(c)
            word.tushi = tushi
        wordbar = data['wordbar']
        interpretation = data['interpretation']
        classification = data['classification']
        onecode = data['onecode']
        one = data['one']
        demo = data['demo']
        demoexplan = data['demoexplan']
        word.opertionTime = str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        word.wordbar = wordbar
        word.interpretation = interpretation
        word.classification = classification
        word.onecode = onecode
        word.one = one
        word.demo = demo
        word.demoexplan = demoexplan
        word.save()
        return HttpResponseRedirect('/word/')


@userdeco.auth
def deleteword(request, **kwargs):
    wordId = request.GET.get('wordId')
    # word=Words.objects.get(wordId=wordId).delete()
    word = Words.objects.get(wordId=wordId)
    word.isdelete = 1
    word.save()
    return HttpResponseRedirect('/word/')
