from django.db import models


# Create your models here.
class Users(models.Model):
    userId = models.CharField(max_length=50, primary_key=True)
    phoneNo = models.CharField(max_length=20)
    password = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    realName = models.CharField(max_length=20)
    insertTime = models.DateTimeField()
    opertionTime = models.DateTimeField()
