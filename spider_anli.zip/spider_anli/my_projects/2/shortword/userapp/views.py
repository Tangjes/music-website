from django.shortcuts import render, HttpResponse, HttpResponseRedirect
from .models import Users
from django.http import JsonResponse
import uuid, datetime
from django.core.cache import cache
import random
from . import sendSMS, check_code


# Create your views here.
def index(request):
    if request.method == "GET":
        sessionId = request.COOKIES.get("sesIds")
        data = cache.get("shortword:%s" % sessionId)
        if sessionId != None and data != None:
            return HttpResponseRedirect('/word/')
        else:
            return render(request, 'userapp/login.html')
            # return HttpResponse('hello world')
    else:
        ret = {}
        ret["retCode"] = 0
        ret["retMessage"] = "用户和密码不匹配"
        ret["retData"] = ""
        data = request.POST
        phoneNo = data["phoneNo"]
        password = data["password"]
        users = Users.objects.filter(phoneNo=phoneNo, password=password)
        if len(users) > 0:
            ret["retCode"] = 1
            ret["retMessage"] = "/"
            sessionId = str(uuid.uuid4())
            cache.set("shortword:%s" % sessionId,
                      {"userId": users[0].userId, "phoneNo": users[0].phoneNo, "sessionId": sessionId}, timeout=1800)
            request.session["sessionId"] = sessionId
            request.session.set_expiry(1800)
            ret["retData"] = sessionId
        return JsonResponse(ret)


# Create your views here.
def register(request):
    if request.method == "GET":
        return render(request, 'userapp/register.html')
    else:
        ret = {}
        ret["retCode"] = 0
        ret["retMessage"] = "此电话号码已存在"
        ret["retData"] = ""
        data = request.POST
        phoneNo = data["phoneNo"]
        password = data["password"]
        realName = data["realName"]
        email = data["email"]
        users = Users.objects.filter(phoneNo=phoneNo)
        if len(users) == 0:
            ret["retCode"] = 1
            ret["retMessage"] = "/"
            # TODO 插入用户数据
            user = Users()
            user.phoneNo = phoneNo
            user.password = password
            user.email = email
            user.realName = realName
            user.userId = str(uuid.uuid4())
            user.insertTime = datetime.datetime.now()
            user.opertionTime = datetime.datetime.now()
            user.save()
            sessionId = str(uuid.uuid4())
            redisdata = {"sessionId": sessionId, "userId": user.userId, "phoneNo": user.phoneNo}
            cache.set('shortword:%s' % sessionId, redisdata)
            ret["retData"] = sessionId
            request.session["sessionId"] = sessionId
            request.session.set_expiry(1800)
        return JsonResponse(ret)


def resetpassword(request):
    if request.method == "GET":
        return render(request, 'userapp/passreset.html')
    else:
        ret = {}
        ret["retCode"] = 0
        ret["retMessage"] = "您的网络开小差了"
        yzm = request.POST["phoneNoyzm"]
        password = request.POST["password"]
        phoneNo = request.POST["phoneNo"]
        checkcode2 = request.POST["checkcode"]
        data = cache.get("shortword:loginpic")
        if checkcode2.lower() != data.lower():
            ret["retMessage"] = "图形验证码输入有误"
        data = cache.get("shortword:%s" % phoneNo)
        if yzm != str(data):
            ret["retMessage"] = "验证码输入有误"
        else:
            try:
                user = Users.objects.get(phoneNo=phoneNo)
                user.password = password
                user.save()
                ret["retCode"] = 1
                ret['retMessage'] = "/"
            except Exception as ex:
                print(ex)
        return JsonResponse(ret)


def yzmsend(request):
    ret = {}
    ret["retCode"] = 0
    ret["retMessage"] = "您的网络开小差了"
    if request.method == "POST":
        phoneNo = request.POST["phoneNo"]
        data = random.randint(100000, 1000000)
        cache.set("shortword:%s" % phoneNo, data, timeout=300)
        ret["retCode"] = 1
        sendSMS.sendSMS(data, phoneNo)
        # TODO 发送短信
        return JsonResponse(ret)


from io import BytesIO


def checkcode(request):
    text, image = check_code.gene_code()
    stream = BytesIO()
    image.save(stream, 'PNG')
    cache.set("shortword:loginpic", text)
    return HttpResponse(stream.getvalue(), content_type="image/png")
