from django.http import HttpResponseRedirect
from django.core.cache import cache


def auth(func):
    def inner(request, *args, **kwargs):
        v = request.COOKIES.get('sesIds')
        data = cache.get("shortword:%s" % v)
        '''
        第一种，使用redis解决浏览器不关闭，保存30分钟后，自动登录
         data = cache.get("shortword:%s" % v)
        if v == None or data == None:
            return HttpResponseRedirect('/')
        funcexe = func(request, *args, data=data)
        cache.set("shortword:%s" % v, data, timeout=1800)
        
        第二种方案：设置session
        '''
        sess = request.session.get("sessionId")
        if v == None or sess == None or data == None:
            return HttpResponseRedirect('/')
        funcexe = func(request, *args, data=data)
        request.session.set_expiry(1800)
        cache.set("shortword:%s" % v, data, timeout=1800)
        return funcexe

    return inner
