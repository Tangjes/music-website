import requests
import datetime, hashlib, json
from utilz import dbmysql


def getAllData():
    sql = "select * from info ORDER  BY insertTime;"
    rs = dbmysql.fetchall(sql)
    for item in rs:
        postData(body=item[4], url=item[2], title=item[3], infoId=item[0])
        pass


def postData(body, url, title, infoId):
    s = requests.session()
    try:
        timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        userId = "bb864474-7a86-11e8-bf0b-c85b765a8965"
        tokenId = "99975ddf0cf52e752b817d1ff72e0bec"
        sig = userId + timestamp + tokenId
        h1 = hashlib.md5()
        h1.update(sig.encode(encoding='utf-8'))
        token = h1.hexdigest()
        data = {"body": body, "title": title, "url": url, "userId": userId, "timestamp": timestamp,
                "infoId": infoId, "sig": token}
        r = s.post('http://127.0.0.1:5100/insertspider/', data=data)
        html = r.content.decode('utf-8')
        jsonhtml = json.loads(html)
        print(jsonhtml)
    except Exception as e:
        print(e)
    finally:
        if s:
            s.close()


getAllData()
