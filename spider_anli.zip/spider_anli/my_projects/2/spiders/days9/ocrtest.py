from PIL import Image
import pytesseract
image=Image.open('img.jpg')
im2=image.convert('L')
# im2.show()

im3 = im2.point(lambda x: 0 if x < 143 else 255)
# im3.show()
im3.save('b.jpg')
image=Image.open('b.jpg')
text = pytesseract.image_to_string(image)
print(text)
