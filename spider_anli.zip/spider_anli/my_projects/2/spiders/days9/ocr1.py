import requests
from PIL import Image
import pytesseract
'''
如果真的是验证码的话：需要如下操作
1.请求验证码的url
2.将此验证码保存到本地，形成图片
3.image打开验证码，进行图片识别
4.将识别出来的文字信息，发送web接口请求，接口返回cookie信息
5.拿着返回的cookie再去访问你要访问的页面
'''
'''
访问频繁出现验证码或者滑块验证的时候，解决方案如下：
1.代理IP
2.识别验证码
3.打码平台
4.访问速度降下来  time.sleep()
5.自己写个类似打码平台的管理平台
'''
while 1:
    r = requests.get('https://passport.zhaopin.com/checkCode/img')
    with open('a.jpg', 'wb') as f:
        f.write(r.content)

    image=Image.open('a.jpg')
    im2=image.convert('L')
    im3 = im2.point(lambda x: 0 if x < 143 else 255)
    im3.save('b.jpg')
    image=Image.open('b.jpg')
    text = pytesseract.image_to_string(image)
    print(text)


