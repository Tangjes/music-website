import requests
import datetime, hashlib,json



s = requests.session()
body = "hahahahahahahhahaha"
url = "jdjfjdfksdlfsdf"
title = "sdjfhjsdkfkds"
infoId = "sdjkfjkdsfhdfjkghdfjkg"
timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
userId = "f81ca567-79ad-11e8-bf0b-c85b765a8965"
tokenId="sdgdsfgfd"
sig = userId + timestamp + tokenId
h1 = hashlib.md5()
h1.update(sig.encode(encoding='utf-8'))
token = h1.hexdigest()
data = {"body": body, "title": title, "url": url, "userId": userId, "timestamp": timestamp,
        "infoId": infoId, "sig": token}
r = s.post('http://127.0.0.1:5000/insertspider/', data=data)
html = r.content.decode('utf-8')
jsonhtml=json.loads(html)
print(jsonhtml)
