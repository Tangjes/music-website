import numpy as np
import pandas as pd
import pymysql

'''
分析招聘网站中工资最低的公司和工资最高的公司
步骤如下：
1.读取数据库
2.数据预处理
3.将工资用-分割
4.排序取第一行数据
'''


def run_main():
    mysql_cn = pymysql.connect(host='localhost', port=3306, user='root', passwd='123456', db='zhaopin', charset='utf8')
    df = pd.read_sql('select salary,companyName from info;', con=mysql_cn)
    mysql_cn.close()
    '''
    数据预处理
    '''
    df['salary'].replace('面议&nbsp;', np.NaN, inplace=True)
    df['salary'].replace(regex=r'\d+元/月以下&nbsp;', value=np.NaN, inplace=True)
    df.dropna(inplace=True)
    df["salary"] = df["salary"].str.replace("元/月&nbsp;", "")
    df["salary"] = df["salary"].str.replace("元/月工作地点：", "")
    salarysplit = df["salary"].str.split('-', expand=True)
    df["minsalary"] = salarysplit[0]
    df["maxsalary"] = salarysplit[1]
    '''
    object排序默认为字符串格式的排序
    对于薪资的，需要转换成数字
    '''
    df['maxsalary'] = df['maxsalary'].astype(dtype=int)
    df['minsalary'] = df['minsalary'].astype(dtype=int)
    print(df.dtypes)
    '''
    排序取第一行数据
    '''
    ordermin = df.sort_values(by=['minsalary']).iloc[0]
    print('工资最低的公司为：', ordermin["companyName"], '工资为：', ordermin['minsalary'])
    ordermax = df.sort_values(by=['maxsalary'], ascending=False).iloc[0]
    print('工资最高的公司为：', ordermax['companyName'], '工资为：', ordermax['maxsalary'])


if __name__ == '__main__':
    run_main()
