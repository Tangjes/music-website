import Celery

app = Celery('tasks',  broker='amqp://:xia:123@192.168.145.1:5672//xia')

@app.task
def add(x, y):
    return x + y