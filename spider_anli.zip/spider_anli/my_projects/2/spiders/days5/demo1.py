import requests

s=requests.session()
r=s.get('http://fanyi.youdao.com/')
print(r.content.decode('utf-8'))