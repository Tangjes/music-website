from utilz import util
import requests

'''
cookie的使用：如果是由session设置的cookie，那么此时cookie只能使用requests.cookies.RequestsCookieJar()来设置
如果使用的是requests自己的get或者post方式，那么可以使用字典的形式设置

如果我们要请求的数据，需要登录，那么最懒的最直接的办法是：通过浏览器直接登录，然后把浏览器登录成功以后的cookie，复制到程序中
然后，拿着这个复制好的cookie去请求我们想要的数据

还有一种是自己破解登录算法，待登录成功后，拿着登录成功以后的cookie，去访问要获取的数据

'''
# r=util.post('http://www.miaodiyun.com/auth/login', data={"username": "18031363065", "passwd": "12345678"})
# cookie=r["cookie"]
jar = requests.cookies.RequestsCookieJar()
jar.set('userNameCookieKey', '18031363065')
jar.set('SESSION', '958a63e9-a17f-467f-a13f-7add89e94798')
r = util.get('http://www.miaodiyun.com/industrySMS_template.html', cookie=jar)
print(r["msg"].decode('utf-8'))

s = requests.session()
# s.get('http://www.miaodiyun.com/login.html')
# r=s.post('http://www.miaodiyun.com/auth/login', data={"username": "18031363065", "passwd": "12345678"})
# r2=s.get('http://www.miaodiyun.com/industrySMS_template.html')
# print(r2.content.decode('utf-8'))

# r = s.get('http://www.miaodiyun.com/industrySMS_template.html',
#           cookies={"userNameCookieKey": '18031363065', "SESSION": "958a63e9-a17f-467f-a13f-7add89e94798"})
# print(r.content.decode('utf-8'))
