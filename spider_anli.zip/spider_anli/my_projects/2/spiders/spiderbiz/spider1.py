import requests

s = requests.session()
heade = {
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"
}
s.headers = heade
s.params = {
    "app": "shopsearch", "q": "ddd"
}
jar = requests.cookies.RequestsCookieJar()
jar.set('isg', 'BP7-AARnKbBwEX2BE4j1apKeTxSAl_BF6Xw0ZqgHacE8S54lEM8SySQJxxeH9LrR')
s.cookies = jar
s.verify = False
# s.proxies = {"http": "", "https": ""}
# r = s.get('https://shopsearch.taobao.com/search', timeout=20)
# print(r.status_code)
# print(r.content)
