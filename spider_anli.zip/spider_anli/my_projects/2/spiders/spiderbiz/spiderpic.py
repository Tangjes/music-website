from  utilz import util

# 爬取图片
# r = util.get(
#     'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1528456437879&di=70f10095ae3c1a785051a73c71949d8a&imgtype=0&src=http%3A%2F%2Fimage5.tuku.cn%2Fpic%2Fwallpaper%2Fsheji%2Fmengxianglantuxunijianzhubizhi%2F003.jpg')
# with open('a.jpg', 'wb') as f:
#     f.write(r["msg"])

# 爬取视频
# r = util.get(
#     'http://vali.cp31.ott.cibntv.net/youku/677135c07bb4971d271b45fcd/03000801005B0B9C1EE7DA003E88032355CE08-423F-21DB-3297-1AA215494DBC.mp4?sid=052844420300010009265_00_Aed8e1687f4a530868d3b379463430b51&sign=75f59c618ce111906742e4d4bd24de18&ctype=50')
# with open('a.mp4', 'wb') as f:
#     f.write(r['msg'])

# 爬取音频
r = util.get('http://data.5sing.kgimg.com/G130/M07/05/15/YpQEAFr_CXCARaIiAJmimyZRs0A371.mp3')
with open('a.mp3', 'wb') as f:
    f.write(r['msg'])
