from utilz import util

'''
因为网络原因，导致上一次请求，可能发生故障，一般，再来一次请求，
如果二次请求，仍然错误，可以让整个程序退出
'''
proxies = {
    'http': 'http://10.10.1.10:3128',
    'https': 'http://120.76.231.27:3128',
}
r = util.get('http://www.sina.com.cn/', pro=proxies)
if r["code"] == 0:
    r = util.get('https://www.taobao.com', pro=proxies)
if r["code"] == 1:
    print(r["msg"])
