from utilz import util
import json, re

import requests

'''
设置cookie的方式
1. s.get(urs,cookie={"a":"b"})
2. headers里面设置
3. s.cookies=  jar=  requests.cookies.RequestsCookieJar()
'''


# s = requests.session()
# s.headers={
#     "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"}
# jar=requests.cookies.RequestsCookieJar()
# jar.set('antipas', '15cb4J7003729R3960R0662077')
# s.cookies=jar
# r = s.get('https://www.guazi.com/sjz/buy/p17/')
# print(r.content.decode('utf-8'))
header = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
    "Accept-Encoding": "gzip, deflate, br",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Cache-Control": "max-age=0",
    "Connection": "keep-alive",
    "Host": "www.guazi.com",
    "Upgrade-Insecure-Requests": "1",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36",
    "Cookie": "antipas=15cb4J7003729R3960R0662077"
}
def spiderlist():
    r = util.get('https://www.guazi.com/sjz/buy/p17/', head=header)
    html = r["msg"].decode('utf-8').replace('\n', '').replace('\r', '').replace('\t', '')
    print(html)
    info = re.findall(
        '<li data-scroll-track.*?title="(.*?)" href="(.*?)".*?t-i">(.*?)<span.*?/span>(.*?)</div>.*?<p>(.*?)</p>', html)
    if len(info) > 0:
        for item in info:
            print(item[0])
            title = item[0]
            url = "https://www.guazi.com%s" % item[1]
            year = item[2]
            licheng = item[3]
            money = item[4]
            detail(url)

def detail(url):
    r = util.get(url, head=header)
    html = r["msg"].decode('utf-8').replace('\n', '').replace('\r', '').replace('\t', '')
    print(html)
    chezhu=re.findall('<span class="f20">车主：(.*?)</span>',html)
    if len(chezhu)>0:
        print(chezhu[0])
    pailiang=re.findall('<ul class="assort clearfix">.*?three">.*?three"><span>(.*?)</span>',html)
    if len(pailiang)>0:
        pl=pailiang[0]
        print(pl)



spiderlist()
