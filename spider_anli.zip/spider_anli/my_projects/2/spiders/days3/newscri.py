from utilz import util
import json, re


def spiderlist():
    r = util.get('http://news.cri.cn/china/')
    html = r["msg"].decode('utf-8').replace('\n', '').replace('\r', '').replace('\t', '')
    parten = re.compile('<div class="list-wrap"(.*?)<div class="btn-a clear more-btn">')
    infos = parten.findall(html)
    if len(infos) > 0:
        info = infos[0]
        info2 = re.findall('<li> <a href="(.*?)" target="_blank".*?blank">(.*?)</a>.*?setDate">(.*?)</span>', info)
        if len(info2) > 0:
            for item in info2:
                url = item[0]
                title = item[1]
                date = item[2]
                url = "http://news.cri.cn%s" % url
                detail(url)
                print(url)


def detail(url):
    r = util.get(url)
    html = r["msg"].decode('utf-8').replace('\n', '').replace('\r', '').replace('\t', '')
    info = re.findall('<div id="abody".*?>(.*?)<div class="details-labels-style">', html)
    if len(info) > 0:
        body = info[0]
        print(body)


spiderlist()
