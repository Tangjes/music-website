import requests, re
from utilz import util

'''
初始版本
'''

# s = requests.session()
# headers = {
#     "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"}
# s.headers = headers
# r = s.get('https://sou.zhaopin.com/jobs/searchresult.ashx?jl=%E7%9F%B3%E5%AE%B6%E5%BA%84&kw=python&sm=0&p=1')
# html = r.content.decode('utf-8').replace('\r', '').replace('\n', '').replace('\t', '')
# print(html)
# info = re.findall(
#     'class="newlist">.*?href="(.*?)".*?>(.*?)</a>.*?blank">(.*?)</a>.*?zwyx">(.*?)</td>.*?gzdd">(.*?)</td>', html)
# if len(info) > 0:
#     for item in info:
#         prourl = item[0]
#         proname = item[1]
#         companyname = item[2]
#         salary = item[3]
#         address = item[4]
#         r2 = s.get(url=prourl)
#         html2 = r2.content.decode('utf-8').replace('\r', '').replace('\n', '').replace('\t', '')
#         '''
#         从哪开始必须唯一，到哪结束不一定了
#         '''
#         zwms = re.findall('class="tab-inner-cont">(.*?)<button id="applyVacButton1"', html2)
#         if len(zwms) > 0:
#             zwmsinfo = zwms[0]
#             print(zwmsinfo)

'''
改造
'''


def lists():
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"}
    r = util.get('https://sou.zhaopin.com/jobs/searchresult.ashx?jl=%E7%9F%B3%E5%AE%B6%E5%BA%84&kw=python&sm=0&p=1',
                 head=headers)
    html = r["msg"].decode('utf-8').replace('\r', '').replace('\n', '').replace('\t', '')
    print(html)
    info = re.findall(
        'class="newlist">.*?href="(.*?)".*?>(.*?)</a>.*?blank">(.*?)</a>.*?zwyx">(.*?)</td>.*?gzdd">(.*?)</td>', html)
    if len(info) > 0:
        for item in info:
            prourl = item[0]
            proname =util.getNoHtml( item[1])
            print(proname)
            companyname = item[2]
            salary = item[3]
            address = item[4]
            detail(url=prourl)


def detail(url):
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"}
    r = util.get(url=url, head=headers)
    html = r["msg"].decode('utf-8').replace('\r', '').replace('\n', '').replace('\t', '')
    print(html)
    zwms = re.findall('class="tab-inner-cont">(.*?)<button id="applyVacButton1"', html)
    if len(zwms) > 0:
        zwmsinfo = zwms[0]
        print(zwmsinfo)

lists()