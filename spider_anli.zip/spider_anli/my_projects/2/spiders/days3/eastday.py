from utilz import util
import json,re


def spiderlist():
    r = util.get(
        'http://pcflow.dftoutiao.com/toutiaopc_jrtt/newspool?callback=jQuery18306902479991396349_1528681097966&type=toutiao&uid=15283545379237826&qid=null&position=%25E6%25B2%25B3%25E5%258C%2597&domain=mini&startkey=&newkey=&pgnum=1&idx=0&_=1528681098410')
    html = r["msg"].decode('utf-8')

    data = json.loads(html.replace('jQuery18306902479991396349_1528681097966(', '')[:-1])
    if 'data' in data.keys():
        listdata = data["data"]
        for item in listdata:
            topic = item["topic"]
            url = item["url"]
            print(topic)
            print(url)
            spiderdetail(url)
        print(data)


def spiderdetail(url):
    r = util.get(url)
    html = r["msg"].decode('utf-8').replace('\n','').replace('\r','').replace('\t','')
    # reresult=re.compile('id="J-contain_detail_cnt">(.*?)<div class="article_tags">')
    # reresult.findall(html)
    info=re.findall('id="J-contain_detail_cnt">(.*?)<div class="article_tags">',html)
    if len(info)>0:
        body=info[0]
        print(body)

spiderlist()