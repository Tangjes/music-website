from utilz import dbmysql

# sql="insert into url VALUES ('ddd',now(),now(),'ddd','ddd');"
# row=dbmysql.execute(sql)
# print(row)

# sql = "select * from url where infoId='ddd';"
# row = dbmysql.first(sql)
# print(row)
# print('*' * 50)
# sql = "select * from url;"
# row = dbmysql.fetchall(sql)
# print(row)

sql = "call addurl2('http://laggggg//oooo/pppp')"
row = dbmysql.execute(sql)
print(row)
