import requests
from urllib.parse import quote

url = "http://www.app-echo.com/#/album/info?id=2185848"
text = quote(url, 'utf-8')

r = requests.get('http://192.168.50.203:8050/render.html?url=%s&timeout=10&wait=0.5' % text)
print(r.content.decode('utf-8'))
