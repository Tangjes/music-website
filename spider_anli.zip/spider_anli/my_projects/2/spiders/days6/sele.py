from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time, requests

# browser = webdriver.PhantomJS()
# browser.get('https://www.baidu.com/')
# info = browser.find_element_by_id('kw')
# info.send_keys('python')
# info.send_keys(Keys.ENTER)
# browser.refresh()
# print(browser.page_source)

browser = webdriver.PhantomJS()
browser.get('https://passport.csdn.net/account/login')
a = browser.find_element_by_xpath('//div[@class="row wrap-login"]//div[2]//a')
a.click()
time.sleep(2)
username = browser.find_element_by_id('username')
username.send_keys('18031363065')
passwd = browser.find_element_by_id('password')
passwd.send_keys('ASDFghjkl_')
button=browser.find_element_by_class_name('logging')
button.click()
# passwd.send_keys(Keys.ENTER)
browser.refresh()
# print(browser.page_source)
# print(browser.get_cookies())
# browser.close()

cookie = [item["name"] + ":" + item["value"] for item in browser.get_cookies()]
# cookiestr = ';'.join(item for item in cookie)
cook_map = {}
for item in cookie:
    str = item.split(':')
    cook_map[str[0]] = str[1]
cookies3 = requests.utils.cookiejar_from_dict(cook_map, cookiejar=None, overwrite=True)

s = requests.session()
s.headers = {
             "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"}
s.cookies=cookies3
r = s.get('https://my.csdn.net/my/account/changepwd')
print(r.content.decode('utf-8'))



# browser.get('https://my.csdn.net/my/account/changepwd')
# browser.refresh()
# print(browser.page_source)
