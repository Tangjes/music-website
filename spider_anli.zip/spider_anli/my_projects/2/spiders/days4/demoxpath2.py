from lxml import etree
import requests

r = requests.get(
    'http://list.youku.com/category/show/c_96_s_1_d_1_a_%E9%A6%99%E6%B8%AF.html?spm=a2hmv.20009921.m_86982.5~5~5!2~1~3~A')
html = r.content.decode('utf-8')
html = etree.HTML(html)

result = html.xpath('//ul[@class="info-list"]')
for item in result:
    dianying = item.xpath('li[1]/a')
    dianyingname = dianying[0].text
    dianyingurl = dianying[0].attrib["href"]

    author = item.xpath('li[2]/a')
    zhuyaninfo = ''
    for i2 in author:
        zhuyaninfo = "%s，%s" % (zhuyaninfo, i2.text)
    zhuyaninfo=zhuyaninfo[1:]
    print(author)
