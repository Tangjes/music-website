from lxml import etree
import requests

r = requests.get('https://www.qidian.com/all')
html = r.content.decode('utf-8')
html = etree.HTML(html)

result = html.xpath('//div[@class="book-mid-info"]')
for item in result:
    zuopin=item.xpath('h4/a')
    zuopinname=zuopin[0].text
    zuopinurl=zuopin[0].attrib["href"]
    author=item.xpath('p[@class="author"]')
    authorname=author[0].xpath('a[1]')
    print(author)
    zuopintype=author[0].xpath('a[2]')
    print(zuopintype)
    zuopintype2 = author[0].xpath('a[3]')
    print(zuopintype2)
    #
    # print(zuopin)
    # href = item.attrib["href"]
    # text = item.text
    # print(text)
    # print(href)
