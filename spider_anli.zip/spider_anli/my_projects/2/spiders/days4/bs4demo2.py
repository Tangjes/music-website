import requests
from bs4 import BeautifulSoup

r = requests.get('http://www.xxsy.net/search?s_type=2')
html2 = r.content.decode('utf-8')
html = BeautifulSoup(html2, 'lxml')
info = html.find_all(class_="info")
for item in info:
    bookinfo = item.contents[1].a
    bookurl = bookinfo["href"]
    bookname = bookinfo.string
    introduce = item.contents[3].string
    yueinfo = item.contents[5].find_all('span')
    print(yueinfo[0].string)
    print('d')

print(info)
