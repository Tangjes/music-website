import requests
from bs4 import BeautifulSoup

r = requests.get('https://www.qidian.com/all')
html2 = r.content.decode('utf-8')
html = BeautifulSoup(html2, 'lxml')
info = html.find_all(class_="book-mid-info")
for item in info:
    bookinfo = item.contents[1].a
    bookurl = bookinfo["href"]
    bookname = bookinfo.string
    authorinfo = item.contents[3].a
    authorurl = authorinfo["href"]
    authorname = authorinfo.string
    introduce = item.contents[5].string
    
print(info)
