from scrapy import cmdline

name = 'liepin'
cmd = 'scrapy crawl {0}'.format(name)
cmdline.execute(cmd.split())
