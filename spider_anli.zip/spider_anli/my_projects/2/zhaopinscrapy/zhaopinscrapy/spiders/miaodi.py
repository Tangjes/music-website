# -*- coding: utf-8 -*-
import scrapy


class MiaodiSpider(scrapy.Spider):
    name = 'miaodi'
    allowed_domains = ['miaodiyun.com']

    def start_requests(self):
        head = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"}
        data = {"username": "18031363065", "passwd": "12345678"}
        yield scrapy.FormRequest("http://www.miaodiyun.com/auth/login",
                                 formdata=data,
                                 callback=self.logged_in,
                                 meta={"cookiejar": 1})

    def logged_in(self, response):
        yield scrapy.Request(url="http://www.miaodiyun.com/industrySMS_template.html", meta={"cookiejar": 1},
                             callback=self.sss)

    def sss(self, response):
        body = response.body
        body = body.decode('utf-8')
        print(body)
