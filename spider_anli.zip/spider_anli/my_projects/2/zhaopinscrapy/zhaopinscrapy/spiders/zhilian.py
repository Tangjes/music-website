# -*- coding: utf-8 -*-
import scrapy
from ..items import ZhaopinscrapyItem


class ZhilianSpider(scrapy.Spider):
    name = 'zhilian'
    allowed_domains = ['zhaopin.com']
    headers = {}
    start_urls = ['https://sou.zhaopin.com/jobs/searchresult.ashx?jl=北京&kw=python&sm=0&p=1',
                  'https://sou.zhaopin.com/jobs/searchresult.ashx?jl=北京&kw=python&sm=0&p=2',
                  'https://sou.zhaopin.com/jobs/searchresult.ashx?jl=北京&kw=python&sm=0&p=3',
                  'https://sou.zhaopin.com/jobs/searchresult.ashx?jl=上海&kw=python&sm=0&p=1',
                  'https://sou.zhaopin.com/jobs/searchresult.ashx?jl=广州&kw=python&sm=0&p=1',
                  'https://sou.zhaopin.com/jobs/searchresult.ashx?jl=深圳&kw=python&sm=0&p=1',
                  'https://sou.zhaopin.com/jobs/searchresult.ashx?jl=杭州&kw=python&sm=0&p=1', ]

    def parse(self, response):
        info = response.xpath('//td[@class="zwmc"]/div/a[1]/@href')
        for item in info:
            zhaopinitem = ZhaopinscrapyItem()
            href = item.extract()
            zhaopinitem["url"] = href
            zhaopinitem["source"] = "智联"
            yield scrapy.Request(url=href, callback=self.parseDetail, meta={"items": zhaopinitem})

    def parseDetail(self, response):
        items = response.meta["items"]
        title = response.css("h1").extract()[0]
        companyName = response.xpath('//h2/a/text()').extract()[0]
        items["postionName"] = title
        items["companyName"] = companyName
        yield items
