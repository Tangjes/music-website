# -*- coding: utf-8 -*-
import scrapy
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor
from ..items import ZhaopinscrapyItem
import re

class LiepinSpider(CrawlSpider):
    name = 'liepin'
    allowed_domains = ['liepin.com']
    start_urls = ['https://www.liepin.com/zhaopin/?ckid=d6ef296894f1d5a7&fromSearchBtn=2&init=-1&sfrom=click-pc_homepage-centre_searchbox-search_new&degradeFlag=0&key=python&headckid=d6ef296894f1d5a7&d_pageSize=40&siTag=I-7rQ0e90mv8a37po7dV3Q~fA9rXquZc5IkJpXC-Ycixw&d_headId=628c72270e13058a1a1452bcc4327407&d_ckId=628c72270e13058a1a1452bcc4327407&d_sfrom=search_fp&d_curPage=1&curPage=0']

    rules = (
        # 提取匹配 'category.php' (但不匹配 'subsection.php') 的链接并跟进链接(没有callback意味着follow默认为True)
        Rule(LinkExtractor(allow=('d_curPage=\d+&curPage=\d+')), follow=True),

        # 提取匹配 'item.php' 的链接并使用spider的parse_item方法进行分析
        Rule(LinkExtractor(allow=('/a/\d+.shtml',)), callback='detail'),
        Rule(LinkExtractor(allow=('/job/\d+.shtml',)), callback='detail'),
    )

    def detail(self, response):
        item = ZhaopinscrapyItem()
        body = response.body.replace('\n', '').replace('\t', '').replace('\r', '')
        salarys = re.findall('class="job-item-title">(.*?)<em>', body)
        if len(salarys) > 0:
            item["salary"] = salarys[0]
        com = re.findall('class="job-note">.*?company-name">(.*?)</a>', body)
        if len(com) > 0:
            item["comName"] = com[0]
        address = re.findall('icons24 icons24-position">.*?">(.*?)</a>', body)
        if len(address) > 0:
            item["address"] = address[0]
        desc = re.findall('class="job-item main-message job-description"(.*?)</div>', body)
        if len(desc) > 0:
            item["desc"] = desc[0]
        cominfo = re.findall('data-selector="introduction"(.*?)</div>', body)
        if len(cominfo) > 0:
            item["cominfo"] = cominfo[0]
        yield item
