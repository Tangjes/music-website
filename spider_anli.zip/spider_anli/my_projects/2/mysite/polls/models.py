from django.db import models

# Create your models here.
from django.db import models


class Users(models.Model):
    userId = models.CharField(max_length=50, primary_key=True)
    insertTime = models.DateTimeField()
    opertionTime = models.DateTimeField()
    username = models.CharField(max_length=30)
    password = models.CharField(max_length=30)
    age = models.IntegerField()
    email = models.CharField(max_length=50)

    class Meta:
        db_table = 'Users'
