from django.http import HttpResponseRedirect


def auth(func):
    def inner(request, *args, **kwargs):
        v = request.COOKIES.get('username')
        userId = request.session.get("userId")
        if v == None or userId == None:
            return HttpResponseRedirect('/polls')
        funcexe = func(request, *args, userId=userId)
        request.session["userId"] = userId
        request.session["username"] = v
        request.session.set_expiry(1800)
        return funcexe

    return inner
