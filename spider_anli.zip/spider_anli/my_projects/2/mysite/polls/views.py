from django.shortcuts import render
from django.http import JsonResponse, HttpResponseRedirect, HttpResponse
import hashlib
from .models import Users
from .loginpd import auth
from django.core.cache import cache
from django.views.decorators.cache import cache_page
from django.core.paginator import EmptyPage, PageNotAnInteger, Paginator


# Create your views here.
def login(request):
    if request.method == "POST":
        ret = {}
        ret["retCode"] = 0
        ret["retMsg"] = "用户名密码不匹配"
        data = request.POST
        tokenKey = "ff8102be74b6ae19c3bb4ad85b9ff5c3"
        username = data["username"]
        password = data["password"]
        timestr = data["timestr"]
        token = data["token"]
        # content=md5(tokenkey+username+password+timestr)   规则
        content = tokenKey + username + password + timestr
        h1 = hashlib.md5()
        h1.update(content.encode(encoding='utf-8'))
        tokenmiwen = h1.hexdigest()
        if tokenmiwen != token:
            ret["retMsg"] = "token错误"
            return JsonResponse(ret)
        queryset = Users.objects.filter(username=username, password=password)
        if len(queryset) > 0:
            # TODO 写入cookie  写入session
            cache.set("mysite:userId", queryset[0].userId, timeout=300)
            request.session["userId"] = queryset[0].userId
            request.session["username"] = username
            request.session.set_expiry(1800)
            ret["retCode"] = 1
            ret["retMsg"] = "loginsuccess"
            ret["retData"] = queryset[0].userId
        return JsonResponse(ret)


def index(request):
    # userId = cache.get("mysite:userId")
    # print(userId)
    # user = request.GET.get('user')
    # print(user)
    return render(request, 'index.html')


def index2(request, user2):
    print(user2)
    return render(request, 'index.html')


def loginsuccess(request):
    username = request.COOKIES.get("username")
    userId = request.session.get("userId")
    if username == None or userId == None:
        return HttpResponseRedirect('/polls')
    else:
        return render(request, 'loginsuccess.html')


@auth
def updatePassword(request, **kwargs):
    userId = kwargs["userId"]
    result = Users.objects.get(userId=userId)
    print(userId)
    # username=request.COOKIES.get("username")
    # userId=request.session.get("userId")
    # if username==None or userId==None:
    #     return HttpResponseRedirect('/polls')
    # else:
    return render(request, 'personupdate.html')


def writecookie(request):
    response = HttpResponseRedirect('loginsuccess')
    # 将username写入浏览器cookie,失效时间为3600
    response.set_cookie('uspw', "www", max_age=10000)
    return response


def register(request):
    if request.method == "GET":
        data = {"vartitle": "用户注册"}
        return render(request, 'register.html', data)
    else:
        data = request.POST
        return HttpResponse('sdfh')


@cache_page(600)
def userlist(request):
    # if page in (1,2,3,4,5,6):
    #     print('123456')
    #     data = cache.get("mysite:userlist")
    #     if data == None:
    #         userlists = Users.objects.all()
    #         cache.set("mysite:userlist")
    # else:
    #     userlists = Users.objects.all()
    # data = {"vartitle": "用户列表",
    #         "userlist": userlists}
    # return render(request, 'users2.html', data)
    return HttpResponse('sdf')


# @cache_page(200)
def listing(request):
    page = request.GET.get('page')
    contact_list = None
    if int(page) in (1, 2, 3, 4, 5, 6):
        users = cache.get("mysite:userlist%s" % (page))
        if users:
            contact_list = users
        else:
            contact_list = Users.objects.all()
            cache.set("mysite:userlist%s" % (page), contact_list, timeout=300)
    else:
        contact_list = Users.objects.all()
    paginator = Paginator(contact_list, 1)  # Show 25 contacts per page

    contacts = paginator.get_page(page)
    # data = {"vartitle": "用户列表",
    #         "userlist": contact_list}
    return render(request, 'users2.html', {'contacts': contacts})
