from mongoengine import *


class url(Document):
    infoId = StringField()
    insertTime = StringField()
    opertionTime = StringField()
    url = StringField()
    source = StringField()


class info(Document):
    infoId = StringField()
    insertTime = StringField()
    opertionTime = StringField()
    postionName = StringField()
    companyName = StringField()
    salary = StringField()
    address = StringField()
    pushTime = StringField()
    welfare = StringField()
    experience = StringField()
    education = StringField()
    nature = StringField()
    recruits = StringField()
    posttype = StringField()
    description = StringField()
    introduce = StringField()
    industry = StringField()
    comaddress = StringField()
    url = StringField()
