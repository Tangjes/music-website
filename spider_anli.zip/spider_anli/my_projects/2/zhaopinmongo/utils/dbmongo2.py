from pymongo import MongoClient
import config

# conn = MongoClient()
# db = conn.sss

# db.table.insert({"ss":123,"aa":"b"})
# cc=db.table.find_one({"ss":123})
# cc["bb"]="fff"
# db.table.save(cc)
# db.table.remove(cc)
# print(cc)
# for item in cc:
#     print(item)

#
from mongoengine import *

#
# connect(host='mongodb://用户名:密码@ip:port/数据库名字')
connect(host='mongodb://localhost/sss')


#
#
class User(Document):
    email = StringField(required=True)
    first_name = StringField(max_length=50)
    last_name = StringField(max_length=50)


# user = User()
# user.email = '111@111.com'
# user.first_name = "111"
# user.last_name = "111"
# user.save()
# ss=User.objects(email='111@111.com')
# ss.first_name="lisi"
# ss.save()
ss = User.objects(email='111@111.com').delete()

#
#
# # orm   把数据库里面 映射成  class  操作class 相当于操作 那个数据表
# # orm有点是：我们可以不用再去写sql  orm框架帮我们完成
# # orm弊端：全表载入内存，然后再从内存中，检索我们需要的数据，性能很低
# ross = User(email='ross@example.com', first_name='Ross', last_name='Lawley').save()
