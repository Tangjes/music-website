import uuid, re, requests
import hashlib
import logging
import uuid, json
from utils import dbredis

try:
    logging.basicConfig(level=logging.INFO,
                        format='[%(asctime)s - %(filename)s -%(funcName)s %(levelname)s]:%(message)s')
    logger = logging.getLogger()
except Exception as e:
    print(e)


def getUUID():
    return str(uuid.uuid4())


def setredis(key, value):
    try:
        dbredis.sr.setex(key, value=value, time=1800)
    except Exception as e:
        logger.error(e)


def getredis(key):
    value = None
    try:
        value = dbredis.sr.get(name=key)
    except Exception as e:
        logger.error(e)
    return value


'''
如果要请求的网站，没有太多限制，为了代码写起来更好看一些，进行封装，
如果涉及到登录的时候，则不能使用此方法：

其中代理和timeout的设置是requests的，而非session
'''


def get(url, parmas=None, head=None, cookie=None, pro=None, verfiy=None):
    ret = {}
    ret["code"] = 0
    ret["msg"] = ""
    s = requests.session()
    try:
        if parmas != None:
            s.params = parmas
        if head != None:
            s.headers = head
        if cookie != None:
            s.cookies = cookie
        if verfiy != None:
            s.verify = verfiy
        if pro != None:
            r = s.get(url=url, proxies=pro, timeout=10)
        else:
            r = s.get(url=url, timeout=10)
        ret["code"] = 1
        ret["msg"] = r.content
    except Exception as e:
        print(e)
    finally:
        if s:
            s.close()
    return ret


'''
如果要请求的网站，没有太多限制，为了代码写起来更好看一些，进行封装，
如果涉及到登录的时候，则不能使用此方法：

post与get的不同在于：post方式有两个必传参数，url，data，而get则没有data参数
'''


def post(url, data, parmas=None, head=None, cookie=None, pro=None, verfiy=None):
    ret = {}
    ret["code"] = 0
    ret["msg"] = ""
    ret["cookie"] = None
    s = requests.session()
    try:
        if parmas != None:
            s.params = parmas
        if head != None:
            s.headers = head
        if cookie != None:
            s.cookies = cookie
        if verfiy != None:
            s.verify = verfiy
        if pro != None:
            r = s.post(url=url, data=data, proxies=pro, timeout=10)
        else:
            r = s.post(url=url, data=data, timeout=10)
        ret["code"] = 1
        ret["msg"] = r.content
        ret["cookie"] = r.cookies
    except Exception as e:
        print(e)
    finally:
        if s:
            s.close()
    return ret


def getNoFh(body):
    return body.replace("'", "’").replace('"', "“").replace(',', '，').replace(';', '；')


def getNoHtml(body):
    dr = re.compile(r'<[^>]+>', re.S)
    dd = dr.sub('', body)
    return dd
