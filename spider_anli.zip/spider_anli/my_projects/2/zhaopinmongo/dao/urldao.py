from models import model
from utils import util
import datetime


def insertUrlData(infoId, url, source):
    try:
        urls = model.url()
        urls.infoId = infoId
        urls.insertTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        urls.opertionTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        urls.url = url
        urls.source = source
        urls.save()
        return url
    except Exception  as e:
        util.logger.error(e)


def selectByUrl(url):
    '''
    返回值为0表示可以插入，返回值为1，表示此url地址已存在，不可以插入，
    出错了，返回False
    :param url:
    :return:
    '''
    try:
        rs = model.url.objects(url=url).first()
        if rs == None:
            return 2
        else:
            return 1
    except Exception as e:
        util.logger.error(e)
        return False
