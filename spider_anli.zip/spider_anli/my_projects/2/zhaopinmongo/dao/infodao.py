from models import model
from utils import util
import datetime


def insertInfoData(postionName, companyName, salary, address, pushTime, welfare, experience, education, nature,
                   recruits,
                   posttype, description, introduce, industry, comaddress, url):
    try:
        info = model.info()
        info.infoId = util.getUUID()
        info.insertTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        info.opertionTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        info.postionName = postionName
        info.companyName = companyName
        info.salary = salary
        info.address = address
        info.pushTime = pushTime
        info.welfare = welfare
        info.experience = experience
        info.education = education
        info.nature = nature
        info.recruits = recruits
        info.posttype = posttype
        info.description = description
        info.introduce = introduce
        info.industry = industry
        info.comaddress = comaddress
        info.url = url
        info.save()
        return info
    except Exception  as e:
        util.logger.error(e)
