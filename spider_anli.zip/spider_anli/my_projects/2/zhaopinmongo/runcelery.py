# coding=utf-8
import job51work, zhilianwork
import threading


def getCity():
    return ['北京', '上海', '广州', '深圳']


def getPost():
    return ['python', 'java', 'c#.net']


def job51():
    for item in getCity():
        for item2 in getPost():
            job51work.job51work.delay(item, item2)


def zhilian():
    for item in getCity():
        for item2 in getPost():
            zhilianwork.zhilianwork.delay(item, item2)


threads = []
t1 = threading.Thread(target=job51)
threads.append(t1)
t2 = threading.Thread(target=zhilian)
threads.append(t2)

if __name__ == '__main__':
    for t in threads:
        if t.isAlive() == False:
            t.start()
