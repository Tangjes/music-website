from dao import infodao, urldao


def insertData(postionName, companyName, salary, address, pushTime, welfare, experience, education, nature,
               recruits,
               posttype, description, introduce, industry, comaddress, url, source):
    info = infodao.insertInfoData(postionName, companyName, salary, address, pushTime, welfare, experience, education,
                                  nature,
                                  recruits,
                                  posttype, description, introduce, industry, comaddress, url)
    url = urldao.insertUrlData(infoId=info.infoId, url=url, source=source)
    return url


def selectByUrl(url):
    return urldao.selectByUrl(url)
