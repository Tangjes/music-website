import os


class MongoConfig():
    # MONGO_PROD = "mongodb://用户名:密码@host:端口号/数据库"
    MONGO_PROD = "mongodb://127.0.0.1/zhaopin"


class RedisConfig():
    redisIp = '192.168.50.203'
    redisPort = 6379
    redisPassword = ''
    redisDb = 0


class Header():
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"}
