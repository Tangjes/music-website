from wz import base


class Job51(base.Base):
    def __init__(self):
        base.Base.__init__(self)

    def pageLists(self):
        url = 'page'
        self.lists(url)

    def lists(self, url):
        result = []
        for i in result:
            # TODO url去重
            self.getDataByUrl()
            self.detail()
            self.insertData()

    def detail(self):
        pass
