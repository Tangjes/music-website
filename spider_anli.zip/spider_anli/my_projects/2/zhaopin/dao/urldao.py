from utilz import dbmysql, util


def insertData(url, source):
    resutl = False
    try:
        infoId = util.getUUID()
        sql = "insert into url(infoId,insertTime,opertionTime,url,source) VALUES ('%s',now(),now(),'%s','%s');" % (
            infoId, url, source
        )
        resutl = dbmysql.query(sql)
    except Exception as e:
        print(e)
    return resutl


def selectByUrl(url):
    '''
    返回值为0表示可以插入，返回值为1，表示此url地址已存在，不可以插入，
    出错了，返回False
    :param url:
    :return:
    '''
    try:
        sql = "select count(1) from url WHERE url='%s';" % url
        rs = dbmysql.first(sql)
        if rs[0] == 0:
            return 2
        else:
            return 1
    except Exception as e:
        print(e)
        return False
