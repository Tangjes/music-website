from utilz import dbmysql, util


def insertData(postionName, companyName, salary, address, pushTime, welfare, experience, education, nature, recruits,
               posttype, description, introduce, industry, comaddress, url, source):
    resutl = False
    try:
        infoId = util.getUUID()
        # sql = "START TRANSACTION;insert into info(infoId,insertTime,opertionTime,postionName,companyName,salary,address,pushTime,welfare,experience,education,nature,recruits,posttype,description,introduce,industry,comaddress,url)  VALUES ('%s',now(),now(),'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s'); insert into url(infoId,insertTime,opertionTime,url,source) VALUES ('%s',now(),now(),'%s','%s');COMMIT ;" % (
        #     infoId, postionName, companyName, salary, address, pushTime, welfare, experience,
        #     education, nature, recruits, posttype, description, introduce, industry, comaddress, url, infoId, url,
        #     source
        # )
        sql = "CALL addData('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s');" % (
        infoId, postionName, companyName, salary, address,
        pushTime, welfare, experience, education, nature, recruits,
        posttype, description, introduce, industry, comaddress, url, source)
        resutl = dbmysql.query(sql)
    except Exception as e:
        print(e)
    return resutl


def selectByInfoId(infoId):
    rs = None
    try:
        sql = "select * from info WHERE infoId='%s';" % infoId
        rs = dbmysql.first(sql)
    except Exception as e:
        print(e)
    return rs


def selectInfo():
    rs = None
    try:
        sql = "select * from info;"
        rs = dbmysql.fetchall(sql)
    except Exception as e:
        print(e)
    return rs
