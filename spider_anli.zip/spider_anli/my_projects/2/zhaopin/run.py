from biz import zhilian2
import time

while 1:
    zhilian = zhilian2.zhilian()
    zhilian.pagelist()
    print('进入休眠期')
    time.sleep(600)
