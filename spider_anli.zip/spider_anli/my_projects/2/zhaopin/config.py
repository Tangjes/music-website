class Config():
    DB_URI_MYSQL = "mysql+pymysql://root:123456@127.0.0.1:3306/zhaopin?charset=utf8"
    DB_URI_MSSQL = "mssql+pymssql://root:123456@127.0.0.1:3306/alertCenter?charset=utf8"


class Header():
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"}
