# coding=utf-8
import job51work, zhilianwork
import threading
import time


def getCity():
    return ['北京', '上海', '广州', '深圳']


def getPost():
    return ['python', 'java', 'c#.net']


def job51():
    for item in getCity():
        for item2 in getPost():
            job51work.job51work.delay(item, item2)
    time.sleep(1800)


def zhilian():
    print('正在生产智联的数据')
    for item in getCity():
        for item2 in getPost():
            zhilianwork.zhilianwork.delay(item, item2)
    print('智联生产已经入休眠状态')
    time.sleep(1800)


threads = []
# t1 = threading.Thread(target=job51)
# threads.append(t1)
t2 = threading.Thread(target=zhilian)
threads.append(t2)

if __name__ == '__main__':
    for t in threads:
        if t.isAlive() == False:
            t.start()
