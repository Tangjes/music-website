from biz import job51
import time

while 1:
    job51 = job51.Job51()
    job51.pageLists()
    time.sleep(600)
