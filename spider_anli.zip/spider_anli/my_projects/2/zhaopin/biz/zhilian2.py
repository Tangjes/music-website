import re
from utilz import util
import time
from . import base
import config


class zhilian(base.Base):
    def __init__(self, **kwargs):
        base.Base.__init__(self)
        self.source = "智联"
        self.__city = kwargs["city"]
        self.__postion = kwargs["postion"]

    def pagelist(self):
        for i in range(1, 3):
            url = "https://sou.zhaopin.com/jobs/searchresult.ashx?jl=%s&kw=%s&sm=0&p=%s" % (
                self.__city, self.__postion, i)
            self.lists(url)

    def lists(self, url):
        r = util.get(url=url, head=config.Header.headers)
        html = r["msg"].decode('utf-8').replace('\r', '').replace('\n', '').replace('\t', '')
        info = re.findall('class="newlist">.*?href="(.*?)"', html)
        if len(info) > 0:
            for item in info:
                time.sleep(2)
                self.url = item
                print("当前的url为%s" % self.url)
                # TODO url去重 根据url去数据库里面查看，看看有没有存过此url
                value = self.getDataByUrl()
                if value == 1:
                    continue
                elif value == False:
                    return
                self.detail()
                self.insertData()

    def detail(self):
        r = util.get(url=self.url, head=config.Header.headers)
        html = r["msg"].decode('utf-8').replace('\r', '').replace('\n', '').replace('\t', '')
        zwmc = re.findall('<h1>(.*?)</h1>', html)
        if len(zwmc) > 0:
            self.postionName = util.getNoHtml(zwmc[0])
        gsmc = re.findall('Str_CompName = "(.*?)"', html)
        if len(gsmc) > 0:
            self.companyName = util.getNoHtml(gsmc[0])
        zwyx = re.findall('<span>职位月薪：(.*?)<a', html)
        if len(zwyx) > 0:
            self.salary = util.getNoHtml(zwyx[0])
        fbrq = re.findall('发布日期：(.*?)</li>', html)
        if len(fbrq) > 0:
            self.pushTime = util.getNoHtml(fbrq[0])
        gzjy = re.findall('工作经验：(.*?)</li>', html)
        if len(gzjy) > 0:
            self.experience = util.getNoHtml(gzjy[0])
        zprs = re.findall('招聘人数：(.*?)</li>', html)
        if len(zprs) > 0:
            self.recruits = util.getNoHtml(zprs[0])
        zwlb = re.findall('职位类别：(.*?)</li>', html)
        if len(zwlb) > 0:
            self.posttype = util.getNoHtml(zwlb[0])
        zdxl = re.findall('最低学历：(.*?)</li>', html)
        if len(zdxl) > 0:
            self.education = util.getNoHtml(zdxl[0])
        gzdd = re.findall('工作地点：(.*?)</li>', html)
        if len(gzdd) > 0:
            self.address = util.getNoHtml(gzdd[0])
        gzxz = re.findall('工作性质：(.*?)</li>', html)
        if len(gzxz) > 0:
            self.nature = util.getNoHtml(gzxz[0])
        zwms = re.findall('class="tab-inner-cont">(.*?)<button id="applyVacButton1"', html)
        if len(zwms) > 0:
            self.description = util.getNoFh(zwms[0])
        gsms = re.findall('style="display:none;word-wrap:break-word;">(.*?)<div class="today_recommend">', html)
        if len(gsms) > 0:
            self.introduce = util.getNoFh(gsms[0])
        gshy = re.findall('公司行业：(.*?)</li>', html)
        if len(gshy) > 0:
            self.industry = util.getNoHtml(gshy[0])
        gsdz = re.findall('公司地址：(.*?)</strong>', html)
        if len(gsdz) > 0:
            self.comaddress = util.getNoFh(util.getNoHtml(gsdz[0]))
