from dao import infodao, urldao


class Base():
    def __init__(self):
        self.opertionTime = ''
        self.postionName = ''
        self.companyName = ''
        self.salary = ''
        self.address = ''
        self.pushTime = ''
        self.welfare = ''  # 福利
        self.experience = ''  # 经验
        self.education = ''  # 学历
        self.nature = ''  # 工作性质
        self.recruits = ''  # 招聘人数
        self.posttype = ''  # 职位类别
        self.description = ''  # 职位描述
        self.introduce = ''  # 公司描述
        self.industry = ''  # 公司行业
        self.comaddress = ''  # 公司地址
        self.url = ''
        self.source = ''

    def getDataByUrl(self):
        value = urldao.selectByUrl(self.url)
        return value

    def insertData(self):
        if len(self.comaddress) > 100:
            self.comaddress = self.comaddress[:80]
        infodao.insertData(postionName=self.postionName, companyName=self.companyName,
                           salary=self.salary, address=self.address, pushTime=self.pushTime,
                           welfare=self.welfare, experience=self.experience,
                           education=self.education, nature=self.nature,
                           recruits=self.recruits, posttype=self.posttype,
                           description=self.description, introduce=self.introduce,
                           industry=self.industry, comaddress=self.comaddress, url=self.url, source=self.source)
        # urldao.insertData(source=self.source, url=self.url)

    def clear(self):
        self.opertionTime = ''
        self.postionName = ''
        self.companyName = ''
        self.salary = ''
        self.address = ''
        self.pushTime = ''
        self.welfare = ''
        self.experience = ''
        self.education = ''
        self.nature = ''
        self.recruits = ''
        self.posttype = ''
        self.description = ''
        self.introduce = ''
        self.industry = ''
        self.comaddress = ''
        self.url = ''
        self.source = ''
