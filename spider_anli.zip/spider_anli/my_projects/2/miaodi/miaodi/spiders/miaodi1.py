import scrapy


class Miaodi1Spider(scrapy.Spider):
    name = "miaodi1"

    def start_requests(self):
        urls = [
            'http://www.miaodiyun.com/account.html',
        ]
        head = {
                "Upgrade-Insecure-Requests": "1",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"}
        cookie = {"SESSION": "82023c98-b1d9-4229-87c4-c6f6c56339f3", "userNameCookieKey": ""}
        for url in urls:
            yield scrapy.Request(url=url, callback=self.parse, cookies=cookie,headers=head)

    def parse(self, response):
        body = response.body
        body2 = body.decode('utf-8')
        print(body2)
