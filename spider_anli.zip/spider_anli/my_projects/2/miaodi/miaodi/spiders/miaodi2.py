import scrapy


class Miaodi2Spider(scrapy.Spider):
    name = "miaodi2"

    def start_requests(self):
        url = "http://www.miaodiyun.com/auth/login"
        data = {"username": "18031363065", "passwd": "12345678"}
        yield scrapy.FormRequest(url=url,
                                 formdata=data,
                                 callback=self.parse)

    # start_urls = [
    #     'http://www.miaodiyun.com/account.html'
    # ]

    def parse(self, response):
        # body = response.body
        # body = body.decode('utf-8')
        # print(body)
        yield scrapy.Request(url="http://www.miaodiyun.com/account.html", callback=self.successParse
                             )

    def successParse(self, response):
        body = response.body
        body = body.decode('utf-8')
        print(body)
