from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
from miaodi.items import MiaodiItem
from scrapy_redis.spiders import RedisCrawlSpider


class ZhilianSpiderRedis(RedisCrawlSpider):
    """Spider that reads urls from redis queue (myspider:start_urls)."""
    name = 'zhilianredis'
    redis_key = 'zhilian:start_urls'
    #
    # start_urls = ['https://sou.zhaopin.com/jobs/searchresult.ashx?jl=北京&kw=python&sm=0&p=1']

    rules = (
        # 提取匹配 'category.php' (但不匹配 'subsection.php') 的链接并跟进链接(没有callback意味着follow默认为True)
        Rule(LinkExtractor(allow=('kw=python&sm=0&sg=\w+&p=\d+',)),follow=True),


        # 提取匹配 'item.php' 的链接并使用spider的parse_item方法进行分析
        Rule(LinkExtractor(allow=('jobs\.zhaopin\.com/\w{15,25}\.htm',)), callback='parse_item'),
    )

    def parse_item(self, response):
        item = MiaodiItem()
        title = response.css("h1").extract()[0]
        item["title"] = title
        item["url"] = response.url
        yield item
