import scrapy


class JianzhuSpider(scrapy.Spider):
    name = "jianzhu"

    def start_requests(self):
        url = "http://www.zzguifan.com/"
        yield scrapy.Request(url=url, callback=self.parse, meta={"cookiejar": 1})

    def parse(self, response):
        cookie = response.meta["cookiejar"]
        data = {"act": "login",
                "loginname": "lienzhi",
                "password": "lienzhi123",
                "client_token": cookie["zz_client_token"]}
        yield scrapy.FormRequest(url="http://www.zzguifan.com/content/passport/login.aspx", callback=self.successParse,
                                 formdata=data)

    def successParse(self, response):
        body = response.body
        body = body.decode('utf-8')
        print(body)
