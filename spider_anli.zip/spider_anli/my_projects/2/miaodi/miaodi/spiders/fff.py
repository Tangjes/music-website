# import requests

# s = requests.session()
#
# r = s.post('http://www.zzguifan.com/content/passport/content/login.aspx', data={"login": "createclienttoken"})
# print(r.content.decode('utf-8'))
# print('sss')
# r = s.get('http://www.zzguifan.com/')
# ss = s.cookies["zz_client_token"]
# print(r.cookies)
