from mongoengine import *


class userinfo(Document):
    userId = StringField()
    insertTime = StringField()
    username = StringField()
    password = StringField()
    email = StringField()
    address = StringField()
    phoneNo = StringField()
    shouname = StringField()


class orderinfo(Document):
    orderId = StringField()
    insertTime = StringField()
    userId = StringField()
    isPay = StringField()
    totalcount = StringField()
    address = StringField()
    totalprice = StringField()


class orderdetailinfo(Document):
    detailId = StringField()
    insertTime = StringField()
    orderId = StringField()
    userId = StringField()
    goodId = StringField()
    count = StringField()
    price = StringField()


class goodinfo(Document):
    goodId = StringField()
    insertTime = StringField()
    title = StringField()
    pic = StringField()
    price = FloatField()
    unit = StringField()
    jianjie = StringField()
    content = StringField()
    kucun = StringField()
    typeId = StringField()
    typeName = StringField()
    ishot = IntField()


class gwcinfo(Document):
    userId = StringField()
    goodId = StringField()
    insertTime = StringField()
    count = IntField()
    isdelete = IntField()
    price = StringField()


class typeinfo(Document):
    typeId = StringField()
    typeName = StringField()
    insertTime = StringField()
    typepic = StringField()
