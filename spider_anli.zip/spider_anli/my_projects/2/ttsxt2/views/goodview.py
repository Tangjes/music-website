from flask import render_template, Blueprint, request, jsonify, session, redirect
from biz import orderbiz, gwcbiz, goodbiz, userbiz
import json
import config

good = Blueprint('good', __name__,
                 url_prefix='/',
                 static_folder='static',
                 static_url_path='static',
                 template_folder='templates')


@good.route('search',methods=['POST'])
def search():
    title = request.form["q"]
    rs = goodbiz.getGoodByTitle(title)
    return render_template(
        'list.html', rs=rs
    )


@good.route('good/detail/<goodId>')
def detail(goodId):
    rs = goodbiz.getGoodByGoodId(goodId=goodId)
    return render_template(
        'detail.html', rs=rs
    )


@good.route('insertGood')
def insertGood():
    rs = goodbiz.getType()
    return render_template('addgood.html', rs=rs)


@good.route('insertGood2', methods=['POST'])
def insertGood2():
    filename = config.Qt.defaultfile
    try:
        f = request.files['file']
        path = config.Qt.goodsavepath + f.filename
        f.save(path)
        filename = f.filename
    except Exception as ex:
        print(ex)
    data = request.form
    title = data["title"]
    pic = config.Qt.gooddbpath + filename
    price = data["price"]
    unit = data["unit"]
    jianjie = data["jianjie"]
    content = data["content"]
    kucun = data["kucun"]
    typeId = data["types"]
    goodbiz.insertGood(title=title, pic=pic, price=price, unit=unit, jianjie=jianjie, content=content, kucun=kucun,
                       typeId=typeId)
    return redirect('insertGood')


@good.route('addtype')
def addtype():
    return render_template('addtype.html')


@good.route('addtype2', methods=['POST'])
def addtype2():
    filename = config.Qt.defaultfile
    try:
        f = request.files['file']
        path = config.Qt.qtsavepath + f.filename
        f.save(path)
        filename = f.filename
    except Exception as ex:
        print(ex)
    data = request.form
    typename = data["typename"]
    typepic = config.Qt.qtdbpath + filename
    goodbiz.insertType(typename, typepic=typepic)
    return redirect('addtype')
