from flask import render_template, Blueprint, request, jsonify, session, redirect
from biz import orderbiz, gwcbiz, goodbiz, userbiz
import json
from utils import logindecotor

order = Blueprint('order', __name__,
                  url_prefix='/',
                  static_folder='static',
                  static_url_path='static',
                  template_folder='templates')


@order.route('addgwc/<goodId>/<price>')
@logindecotor.decorator
def addgwc(goodId='', price=0):
    userId = session["userId"]
    gwcbiz.insertGwc(userId=userId, goodId=goodId, price=price)
    return redirect('usergwc')


@order.route('updategwc/<goodId>/<count>')
@logindecotor.decorator
def updategwc(goodId, count):
    userId = session["userId"]
    rs = gwcbiz.updateGwc(userId=userId, goodId=goodId, count=count)
    if rs:
        return jsonify({"retCode": 1, "retMessage": "success"})
    else:
        return jsonify({"retCode": 0, "retMessage": count})


@order.route('deletegwc/<goodId>')
@logindecotor.decorator
def deletegwc(goodId):
    userId = session["userId"]
    rs = gwcbiz.deleteGwc(userId=userId, goodId=goodId)
    if rs:
        return jsonify({"retCode": 1, "retMessage": "success"})
    else:
        return jsonify({"retCode": 0, "retMessage": 'fail'})


@order.route('addjiesuan')
@logindecotor.decorator
def addjiesuan():
    userId = session["userId"]
    userinfo = userbiz.getUserByUserId(userId)
    rs = gwcbiz.getGwInfo(userId=userId)
    cart_ids = []
    for i in rs:
        cart_ids.append(i["goodId"])
    cart_ids = ','.join(cart_ids)
    return render_template('place_order.html', user=userinfo, cart=rs, cart_ids=cart_ids)


@order.route('lijigoumai')
@logindecotor.decorator
def lijigoumai():
    userId = session["userId"]
    goodId=request.args.get("goodId")
    count=request.args.get("count")
    userinfo = userbiz.getUserByUserId(userId)
    rs=json.loads(goodbiz.getGoodByGoodId(goodId=goodId).to_json())
    rs["count"]=count

    return render_template('place_order.html', user=userinfo, cart=[rs], cart_ids=goodId)

@order.route('addorders', methods=['POST'])
@logindecotor.decorator
def addorders():
    userId = session["userId"]
    data = request.form
    cart_ids = data["cart_ids"]
    address = data["address"]
    totalprice = data["total4"]
    totalcount = data["total1"]

    rs = orderbiz.insertOrder(userId=userId, cart_ids=cart_ids, address=address, totalprice=totalprice,
                              totalcount=totalcount
                              )
    return render_template('paysuccess.html', order=rs)
