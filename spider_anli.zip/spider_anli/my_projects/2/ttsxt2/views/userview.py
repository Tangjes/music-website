from flask import render_template, Blueprint, request, jsonify, session, redirect, make_response
from biz import userbiz, orderbiz, gwcbiz
import json, datetime
from utils import logindecotor, util

user = Blueprint('user', __name__,
                 url_prefix='/',
                 static_folder='static',
                 static_url_path='static',
                 template_folder='templates')


@user.route('login')
def login():
    return render_template(
        'login.html', user_error=''
    )


@user.route('loginyz', methods=['POST'])
def loginyz():
    data = request.form
    username = data["username"]
    password = data["pwd"]
    if username.strip() == "" or password.strip() == "":
        return render_template(
            'login.html', user_error='用户名密码不匹配'
        )
    rs = userbiz.getUserInfoByUser(username=username, password=password)
    if rs == 0:
        return render_template(
            'login.html', user_error='用户名密码不匹配'
        )
    else:
        session['username'] = username
        session['userId'] = rs.userId
        resp = make_response(redirect('userinfo'))
        '''
        cookie存入到本地后不删除，永远有效，真正的要控制时间的话，
        要想做到像淘宝那样，网页打开了，但是老半天没去管，再次使用的时候，需要让我们登录，
        以及要解决同一台服务器上应对多个用户，此时可以把session存入到缓存中--redis
        
        '''
        util.setloginredis(userId=rs.userId, username=username)
        resp.set_cookie('username', username, path='/', max_age=60)
        return resp


@user.route('register')
def register():
    return render_template(
        'register.html'
    )


@user.route('registeryz', methods=['POST'])
def registeryz():
    data = request.form
    username = data["username"]
    password = data["password"]
    email = data["email"]

    rs = userbiz.getUserInfo(username=username, password=password, email=email)
    if rs == 0:
        return jsonify({"retCode": 0, "retMessage": "此用户已存在"})
    else:
        session['username'] = username
        session['userId'] = rs.userId
        util.setloginredis(userId=session["userId"], username=session["username"])
        return jsonify({"retCode": 1, "retMessage": "userinfo"})


@user.route('userinfo')
@logindecotor.decorator
def userinfo():
    rs = userbiz.getUserByUserId(session["userId"])
    return render_template('user_center_info.html', rs=rs)


@user.route('userorder')
@logindecotor.decorator
def userorder():
    userId = session["userId"]
    rs = orderbiz.getOrderByUserId(userId=userId)
    return render_template('user_center_order.html', rs=rs)


@user.route('useraddress')
@logindecotor.decorator
def useraddress():
    userId = session["userId"]
    rs = userbiz.getUserByUserId(userId=userId)
    return render_template('user_center_site.html', rs=rs)


@user.route('useraddressupdate', methods=['POST'])
@logindecotor.decorator
def useraddressupdate():
    userId = session["userId"]
    data = request.form
    shouname = data["shouname"]
    phoneNo = data["phoneNo"]
    address = data["address"]
    userbiz.updateUserInfo(userId=userId, shouname=shouname, address=address, phoneNo=phoneNo)
    return redirect('useraddress')


@user.route('usergwc')
@logindecotor.decorator
def usergwc():
    userId = session["userId"]
    rs = gwcbiz.getGwInfo(userId=userId)
    return render_template('cart.html', rs=rs)


@user.route('logout')
def logout():
    # redis清除
    try:
        util.deleteredis(name='user:' + session["username"])
    except Exception as e:
        print(e)
    session.clear()
    return redirect('/')
