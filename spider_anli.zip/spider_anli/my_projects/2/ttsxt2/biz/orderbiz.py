from dao import orderdao, orderdetaildao
from biz import goodbiz, gwcbiz
import json


def getOrderByUserId(userId):
    rs = orderdao.getOrderByUserId(userId)
    result = []
    if rs:
        for order in rs:
            orderinfo = json.loads(order.to_json())
            info = {"orderId": orderinfo}
            rs2 = orderdetaildao.getDetailByOrderId(orderId=order["orderId"])
            goodidlist = []
            for i in rs2:
                goodidlist.append(i["goodId"])
            if len(goodidlist) > 0:
                rs3 = goodbiz.getGoodByGoodIdList(goodIdList=goodidlist)
                if len(rs3) > 0:
                    orderdetail = []
                    for i in range(len(rs2)):
                        if rs2[i]["goodId"] == rs3[i]["goodId"]:
                            detail = json.loads(rs2[i].to_json())
                            good = json.loads(rs3[i].to_json())
                            orderdetail.append({"detail": detail, "good": good})
                    info["data"] = orderdetail
                    result.append(info)
    return result


def getOrderByDetailId(detailId):
    return orderdetaildao.getDetailByDetailId(detailId=detailId)


def insertOrder(userId, cart_ids, totalprice, address, totalcount):
    cart_ids = cart_ids.split(',')
    rs = orderdao.insertOrder(userId=userId, totalcount=totalcount, address=address, totalprice=totalprice)
    for item in cart_ids:
        rscart = gwcbiz.getGwInfoByUserAndGood(userId=userId, goodId=item).order_by('-insertTime').first()
        print(rscart.price)
        print(rscart.count)
        orderdetaildao.insertOrderDetail(orderId=rs.orderId, userId=userId, goodId=item, count=str(rscart.count),
                                         price=rscart.price)
        gwcbiz.deleteGwc(userId=userId, goodId=item)
    return rs
