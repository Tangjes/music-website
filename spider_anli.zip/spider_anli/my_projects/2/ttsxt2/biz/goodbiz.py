from dao import gooddao, typedao
from utils import util, dbredis
import json


def getGoodByGoodIdList(goodIdList):
    return gooddao.getGoodByGoodList(goodIdList)


def getGoodByTitle(title):
    return gooddao.getGoodByTitle(title)


def getGoodByType(typeId, ishot=0):
    return gooddao.getGoodByType(typeId, ishot)


def getGoodByGoodId(goodId):
    return gooddao.getGoodByGoodId(goodId=goodId)


def getGoodSy():
    result = []
    try:
        isflag = False
        # 有些网站为了让用户的体验更好，会选择将前几页存放到缓存中，来降低IO阻塞，提升体验
        try:
            result = json.loads(dbredis.sr.get(name='ttsx:sy'))
            isflag = True
        except Exception as e:
            print(e)
        if isflag == False:
            rs = getType()
            for item in rs:
                rsnew = json.loads(getGoodByType(item["typeId"]).order_by('-insertTime')[:4].to_json())
                rshot = json.loads(getGoodByType(item["typeId"], ishot=1).order_by('-insertTime')[:3].to_json())
                result.append({"name": item["typeName"], "rsnew": rsnew, "rshot": rshot, "typepic": item.typepic})
                try:
                    dbredis.sr.setex(name='ttsx:sy', value=json.dumps(result), time=300)
                except Exception as e:
                    print(e)
    except Exception as e:
        print(e)
    return result


def getType():
    return typedao.getType()


def insertGood(title, pic, price, unit, jianjie, content, kucun, typeId):
    gooddao.insertGood(title=title, pic=pic, price=price, unit=unit, jianjie=jianjie, content=content, kucun=kucun,
                       typeId=typeId)


def insertType(typename, typepic):
    typedao.insertType(typeName=typename, typepic=typepic)
