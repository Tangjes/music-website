from dao import gwcdao
from dao import gooddao
import json


def getGwInfo(userId):
    rs = gwcdao.getGwcGoodByUserIdAndNotDelete(userId)
    if rs:
        goodidlist = []
        for item in rs:
            goodidlist.append(item["goodId"])
        rs2 = gooddao.getGoodByGoodList(goodIdList=goodidlist)
        result = []
        for item in rs2:
            data = json.loads(item.to_json())
            for i in rs:
                if data["goodId"] == i.goodId:
                    data["count"] = i["count"]
                    result.append(data)
        return result
    return []


def getGwInfoByUserAndGood(userId, goodId):
    rs = gwcdao.getGwcGoodByUserAndGood(userId=userId, goodId=goodId)
    return rs


def insertGwc(userId, goodId,price):
    rs = gwcdao.getGwcGoodByUserAndGood(userId, goodId=goodId).first()
    if rs:
        gwcdao.updateGwc(userId=userId, goodId=goodId, count=int(rs["count"]) + 1)
    else:
        gwcdao.insertGwc(userId=userId, goodId=goodId, count=1,price=price)


def updateGwc(userId, goodId, count):
    rs = gwcdao.updateGwc(userId, goodId, count)
    return rs


def deleteGwc(userId, goodId):
    rs = gwcdao.deleteGwc(userId=userId, goodId=goodId)
    return rs
