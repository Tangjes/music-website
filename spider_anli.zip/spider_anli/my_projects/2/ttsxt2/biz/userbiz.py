from dao import userdao


def getUserInfo(username, password, phoneNo=None, email=None, address=None):
    rs = userdao.getUserByUserName(username=username)
    if rs != None:
        return 0
    else:
        return userdao.UserReg(username=username, email=email, password=password, phoneNo=phoneNo, address=address)


def getUserInfoByUser(username, password):
    rs = userdao.getUser(userName=username, password=password)
    if rs == None:
        return 0
    else:
        return rs


def getUserByUserId(userId):
    rs = userdao.getUserByUserId(userId=userId)
    if rs == None:
        return 0
    else:
        return rs


def updateUserInfo(userId, shouname, phoneNo, address):
    return userdao.updateUser(userId=userId, address=address, phoneNo=phoneNo, shouname=shouname)
