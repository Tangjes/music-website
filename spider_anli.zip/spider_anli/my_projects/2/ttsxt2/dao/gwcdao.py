from models import usermodel
import datetime


def getGwcGoodByUserId(userId):
    try:
        rs = usermodel.gwcinfo.objects(userId=userId)
        return rs
    except Exception as e:
        print(e)
        return None

def getGwcGoodByUserIdAndNotDelete(userId):
    try:
        rs = usermodel.gwcinfo.objects(userId=userId,isdelete=0)
        return rs
    except Exception as e:
        print(e)
        return None


def getGwcGoodByUserAndGood(userId, goodId):
    try:
        rs = usermodel.gwcinfo.objects(userId=userId, goodId=goodId, isdelete=0)
        return rs
    except Exception as e:
        print(e)
        return None


def insertGwc(userId, goodId, count, price):
    try:
        gwc = usermodel.gwcinfo()
        gwc.userId = userId
        gwc.goodId = goodId
        gwc.count = count
        gwc.insertTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        gwc.isdelete = 0
        gwc.price = price
        gwc.save()
        return gwc
    except Exception  as e:
        print(e)


def updateGwc(userId, goodId, count):
    try:
        gwc = usermodel.gwcinfo.objects(userId=userId, goodId=goodId).first()
        gwc.update(set__count=count)
        return gwc
    except Exception  as e:
        print(e)


def deleteGwc(userId, goodId):
    try:
        # usermodel.gwcinfo.objects(userId=userId, goodId=goodId).delete()
        rs = usermodel.gwcinfo.objects(userId=userId, goodId=goodId)
        rs.update(set__isdelete=1)
        return 1
    except Exception  as e:
        print(e)
        return 0
