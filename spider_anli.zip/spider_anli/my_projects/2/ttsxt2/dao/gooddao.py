from models import usermodel
from utils import util
import datetime


def getGoodByGoodId(goodId):
    try:
        rs = usermodel.goodinfo.objects(goodId=goodId).first()
        print(rs.goodId)
        return rs
    except Exception as e:
        print(e)
        return None


def getGoodByType(typeId,ishot=0):
    try:
        if ishot==0:
            rs = usermodel.goodinfo.objects(typeId=typeId)
        else:
            rs = usermodel.goodinfo.objects(typeId=typeId,ishot=1)
        return rs
    except Exception as e:
        print(e)
        return None


def getGoodByTitle(title):
    try:
        rs = usermodel.goodinfo.objects(title__contains=title).order_by('-insertTime')
        return rs
    except Exception as e:
        print(e)
        return None


def getGoodByGoodList(goodIdList):
    try:
        rs = usermodel.goodinfo.objects(goodId__in=goodIdList)
        return rs
    except Exception as e:
        print(e)
        return None


def insertGood(title, pic, price, unit, jianjie, content, kucun, typeId, typeName=''):
    try:
        good = usermodel.goodinfo()
        good.goodId = util.getUUID()
        good.insertTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        good.title = title
        good.pic = pic
        good.price = float(price)
        good.unit = unit
        good.jianjie = jianjie
        good.content = content
        good.kucun = kucun
        good.typeId = typeId
        good.typeName = typeName
        good.ishot = 0
        good.save()
        return good
    except Exception  as e:
        print(e)
