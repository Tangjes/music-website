from models import usermodel
from utils import util
import datetime


def getOrderByUserId(userId):
    try:
        rs = usermodel.orderinfo.objects(userId=userId)
        return rs
    except Exception as e:
        print(e)
        return None


def getOrderByorderId(orderId):
    try:
        rs = usermodel.orderinfo.objects(orderId=orderId)
        return rs
    except Exception as e:
        print(e)
        return None


def insertOrder(userId, totalcount, address, totalprice, isPay='未支付'):
    try:
        order = usermodel.orderinfo()
        order.orderId = util.getUUID()
        order.insertTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        order.userId = userId
        order.isPay = isPay
        order.totalprice = totalprice
        order.address = address
        order.totalcount = totalcount
        order.save()
        return order
    except Exception  as e:
        print(e)
