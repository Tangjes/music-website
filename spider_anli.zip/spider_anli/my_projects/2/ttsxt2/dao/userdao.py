from models import usermodel
from utils import util
import datetime


def UserReg(username, password, email, address, phoneNo, shouname=None):
    try:
        user = usermodel.userinfo()
        user.userId = util.getUUID()
        user.insertTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        user.username = username
        user.password = password
        user.email = email
        user.address = address if address != None else ''
        user.phoneNo = phoneNo if phoneNo != None else ''
        user.shouname = shouname if shouname != None else ''
        user.save()
        return user
    except Exception  as e:
        print(e)


def getUserByUserId(userId):
    try:
        rs = usermodel.userinfo.objects(userId=userId).first()
        return rs
    except Exception as e:
        print(e)
        return None

def getUserByUserName(username):
    try:
        rs = usermodel.userinfo.objects(username=username).first()
        return rs
    except Exception as e:
        print(e)
        return None


def getUser(userName, password):
    try:
        rs = usermodel.userinfo.objects(username=userName, password=password).first()
        return rs
    except Exception as e:
        print(e)
        return None


def updateUser(userId, shouname, address, phoneNo):
    user = usermodel.userinfo.objects(userId=userId).first()
    # user.password=''
    # user.phoneNo=''
    # user.save()
    user.update(set__shouname=shouname, set__address=address,
                set__phoneNo=phoneNo)
    return user
