from models import usermodel
from utils import util
import datetime


def insertType(typeName, typepic):
    try:
        typed = usermodel.typeinfo()
        typed.typeId = util.getUUID()
        typed.typeName = typeName
        typed.insertTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        typed.typepic = typepic
        typed.save()
        return typed
    except Exception  as e:
        print(e)


def getType():
    try:
        rs = usermodel.typeinfo.objects()
        return rs
    except Exception as ex:
        print(ex)
        return None
