from models import usermodel
from utils import util
import datetime


def getDetailByUserId(userId):
    try:
        rs = usermodel.orderdetailinfo.objects(userId=userId)
        return rs
    except Exception as e:
        print(e)
        return None


def getDetailByOrderId(orderId):
    try:
        rs = usermodel.orderdetailinfo.objects(orderId=orderId)
        return rs
    except Exception as e:
        print(e)
        return None


def getDetailByDetailId(detailId):
    try:
        rs = usermodel.orderdetailinfo.objects(detailId=detailId)
        return rs
    except Exception as e:
        print(e)
        return None


def insertOrderDetail(orderId, userId, goodId, count, price):
    try:
        detail = usermodel.orderdetailinfo()
        detail.detailId = util.getUUID()
        detail.insertTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        detail.orderId = orderId
        detail.userId = userId
        detail.goodId = goodId
        detail.count = count
        detail.price = price
        detail.save()
        return detail
    except Exception  as e:
        print(e)
