import os


class MongoConfig():
    # MONGO_PROD = "mongodb://用户名:密码@host:端口号/数据库"
    MONGO_PROD = "mongodb://127.0.0.1/ttsx"


class RedisConfig():
    redisIp = '192.168.50.203'
    redisPort = 6379
    redisPassword = ''
    redisDb = 0


class Qt():
    basepath = os.path.dirname(__file__)
    goodsavepath = basepath + "/static/images/goods/"
    qtsavepath = basepath + "/static/images/"
    gooddbpath = 'images/goods/'
    qtdbpath = 'images/'
    defaultfile = 'goods_detail.jpg'
