from flask import Flask, render_template
from utils import dbmongo
from biz import goodbiz
from views import userview, orderview, goodview
import datetime

app = Flask(__name__)
app.secret_key = r'+@\x14\x9f\x8b\xa1\xcf\xb7\x1c\x9f\xa1\x0e\xcf\xa5\xd8\xb8\xcd\xb9rcuz\xe6['
app.register_blueprint(userview.user)
app.register_blueprint(orderview.order)
app.register_blueprint(goodview.good)


@app.route('/')
def hello_world():
    result = goodbiz.getGoodSy()
    return render_template('index.html', result=result)


if __name__ == '__main__':
    app.run(port=5022)
