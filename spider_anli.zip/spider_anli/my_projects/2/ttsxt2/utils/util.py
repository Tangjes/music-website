import uuid
import hashlib
import logging
import uuid,json
from utils import dbredis

try:
    logging.basicConfig(level=logging.INFO,
                        format='[%(asctime)s - %(filename)s -%(funcName)s %(levelname)s]:%(message)s')
    logger = logging.getLogger()
except Exception as e:
    print(e)


def getUUID():
    return str(uuid.uuid4())


def gethertext(text):
    m = hashlib.md5()
    m.update(text)
    return m.hexdigest()


def setloginredis(userId,  username):
    value = {"userId": userId, "username": username}
    setredis(key='user:' + username, value=json.dumps(value))


def getloginredis(username):
    value = getredis(key='user:' + username)
    if value:
        return json.loads(value)


def setredis(key, value):
    try:
        dbredis.sr.setex(key, value=value, time=1800)
    except Exception as e:
        print(e)


def getredis(key):
    value = None
    try:
        value = dbredis.sr.get(name=key)
    except Exception as e:
        print(e)
    return value
def deleteredis(name):
    dbredis.sr.delete(name=name)