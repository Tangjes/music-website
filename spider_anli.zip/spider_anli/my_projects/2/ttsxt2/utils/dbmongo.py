# coding=utf-8
import config
from mongoengine import *

try:
    connect(host=config.MongoConfig.MONGO_PROD)
except Exception as ex:
    print(u"mongoengine 初始化失败!")
