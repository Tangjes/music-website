# coding=utf-8
import redis, config

sr = redis.Redis(host=config.RedisConfig.redisIp, port=config.RedisConfig.redisPort, db=config.RedisConfig.redisDb,
                 password=config.RedisConfig.redisPassword)
