from flask import redirect, session, request
from functools import wraps
from utils import dbredis, util


def decorator(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # 让装饰器来判断需要使用session的部分是否已经过期
        username = request.cookies.get("username")
        user = None
        try:
            user = util.getloginredis(username=session["username"])
        except Exception as e:
            print(e)
        '''
        需要登录的三个条件：
        第一个条件 ：浏览器是否关闭，一旦关闭，在开启的时候，需要登录
        第二个条件：浏览器没有关闭，手动清除浏览器的cookie信息
        第三个条件：浏览器在没有关闭的状态下，cookie又存在的情况，30分钟重新登录
        '''
        if 'userId' not in session.keys() or username == None or user == None:
            return redirect('login')
        fun = f(*args, **kwargs)
        # 每次在使用完后，需要重新设置session
        util.setloginredis(userId=session["userId"], username=session["username"])
        return fun

    return decorated_function
