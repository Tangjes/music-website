import uuid
from utilz import dbmysql


# 插入数据表
def insertData(title, body, url, logId, userId):
    try:
        sql = "insert into spiderwebinfo(logId,insertTime,title,body,url,userId) VALUE ('%s',now(),'%s','%s','%s','%s');" % (
            logId, title, body, url, userId)
        rs = dbmysql.execute(sql)
        return rs
    except Exception as e:
        print(e)
        return None


def getData(userId):
    try:
        sql = "select * from spiderwebinfo WHERE userId='%s' ORDER by insertTime desc;" % userId
        return dbmysql.fetchall(sql)
    except Exception as e:
        print(e)
        return None


def updateData(logId, title, body, url):
    try:
        sql = "update spiderwebinfo set title='%s',body='%s',url='%s' WHERE logId='%s';" % (title, body, url, logId)
        dbmysql.execute(sql)
    except Exception as e:
        print(e)


def getDataByLogId(logId):
    try:
        sql = "select * from spiderwebinfo WHERE logId='%s';" % logId
        return dbmysql.first(sql)
    except Exception as e:
        print(e)
        return None
