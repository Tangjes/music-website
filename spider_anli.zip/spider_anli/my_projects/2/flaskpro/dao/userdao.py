from utilz import dbmysql, util
import uuid,json
from utilz import util

# 根据userID查询用户信息是否存在
def getDataByUserId(userId):
    try:
        rs=util.readRedis(userId)
        if rs==None:
            sql = "select * from USERS WHERE userId='%s';" % userId
            rs = dbmysql.first(sql)
            util.insertRedis(userId,json.dumps({"rs":rs}),times=8000000)
        else:
            rs=json.loads(rs)
            rs=rs["rs"]
        return rs
    except Exception as e:
        print(e)
        return 3


def getUserByUserName(username):
    try:
        sql = "select * from users WHERE username='%s';" % username
        rs = dbmysql.first(sql)
        return rs
    except Exception as e:
        print(e)
        return 2


def getUserByPhoneNo(phoneNo):
    try:
        sql = "select * from users WHERE phoneNo='%s';" % phoneNo
        rs = dbmysql.first(sql)
        return rs
    except Exception as e:
        print(e)
        return 2


def insertData(username, password, phoneNo):
    try:
        userId = str(uuid.uuid4())
        sql = "insert into users(userId,username,password,tokeId,phoneNo) VALUE ('%s','%s','%s',md5(uuid()),'%s');" % (
            userId, username, password, phoneNo)
        rs = dbmysql.execute(sql)
        return rs
    except Exception as e:
        print(e)
        return 2
