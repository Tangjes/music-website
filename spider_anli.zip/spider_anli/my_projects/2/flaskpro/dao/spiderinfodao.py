import uuid
from utilz import dbmysql


# 插入数据表
def insertData(title, body, url, infoId):
    try:
        logId = str(uuid.uuid4())
        sql = "insert into spiderinfo(logId,insertTime,title,body,url,infoId,isdelete) VALUE ('%s',now(),'%s','%s','%s','%s',0);" % (
            logId, title, body, url, infoId)
        rs = dbmysql.execute(sql)
        return rs
    except Exception as e:
        print(e)
        return None


def getData():
    try:
        sql = "select * from spiderinfo WHERE isdelete=0 ORDER by insertTime desc;"
        return dbmysql.fetchall(sql)
    except Exception as e:
        print(e)
        return None


def getDataByLogId(logId):
    try:
        sql = "select * from spiderinfo WHERE logId='%s';" % logId
        return dbmysql.first(sql)
    except Exception as e:
        print(e)
        return None


def updatespiderInfo(logId):
    try:
        sql = "update spiderinfo set isdelete=1 WHERE logId='%s';" % logId
        return dbmysql.execute(sql)
    except Exception as e:
        print(e)
        return None
