from flask import Blueprint, jsonify, request
from biz import spiderinfobiz, userbiz
from utilz import deco
import hashlib, json, uuid
import apipushwork
from utilz import util

api = Blueprint('api', __name__,
                template_folder='templates',
                static_folder='static',
                static_url_path='static',
                url_prefix='/')


@api.route('insertspider/', methods=['POST'])
def insertSpider():
    # 定义要返回的信息
    ret = {}
    ret["retCode"] = "1111"
    ret["retMsg"] = "您的信息有误"
    # 读取传递过来的信息
    token = request.form.get('sig')
    body = request.form.get('body')
    url = request.form.get('url')
    title = request.form.get('title')
    infoId = request.form.get('infoId')
    timestamp = request.form.get('timestamp')
    userId = request.form.get('userId')
    data = {"token": token, "body": body, "url": url, "title": title, "infoId": infoId, "timestamp": timestamp,
            "userId": userId}
    # s = str(uuid.uuid4())
    # util.insertRedis(s, json.dumps(data), times=120)
    # apipushwork.add.delay(s)
    # # TODO 读取数据库
    rs = userbiz.getDataByUserId(userId=userId)
    if rs == None:
        ret["retCode"] = "1114"
        ret["retMsg"] = "您的用户不存在"
        return jsonify(ret)
    tokenId = rs[3]
    mw = userId + timestamp + tokenId
    h1 = hashlib.md5()
    h1.update(mw.encode(encoding='utf-8'))
    rk = h1.hexdigest()
    if rk != token:
        ret["retCode"] = "1112"
        ret["retMsg"] = "token信息有误"
        return jsonify(ret)
    rs=spiderinfobiz.insertData(url=url, title=title, body=body, infoId=infoId)
    logId=rs[0]
    #如果手机号码是180开头的
    #1. requests.get("中国电信")
    #2.celeryapp.add.delay(logId)

    ret["retCode"] = "0000"
    ret["retMsg"] = "操作成功"
    return jsonify(ret)
