from flask import Blueprint, render_template, request, jsonify, session, make_response
import uuid, json
from biz import userbiz, code, sendSMS
from utilz import util
from io import BytesIO
import random

user = Blueprint('users', __name__,
                 template_folder='templates',
                 static_folder='static',
                 static_url_path='static',
                 url_prefix='/')


@user.route('index2', methods=['GET', 'POST'])
def index2():
    if request.method == "GET":
        return render_template('index2.html')


@user.route('login', methods=['GET', 'POST'])
def login():
    if request.method == "GET":
        return render_template('index.html')


@user.route('login2', methods=['POST'])
def login2():
    ret = {}
    ret["retCode"] = 0
    ret["retMsg"] = "用户名密码不匹配"
    username = request.form.get('username')
    password = request.form.get('password')
    val_code = request.form.get('val_code')
    imgsessionId = request.cookies.get("imgsessionId")
    codestr = session[imgsessionId]
    if val_code.lower() != codestr.lower():
        ret["retCode"] = 0
        ret["retMsg"] = "验证码错误，请输入"
        return jsonify(ret)

    # TODO 数据库里面查用户名和密码是否存在
    # if username == "123" and password == "123":
    rs = userbiz.getUserByUserName(username=username)
    if rs == None:
        ret["retCode"] = 0
        ret["retMsg"] = "用户名不存在"
        return jsonify(ret)
    if rs[2] == password:
        ret["retCode"] = 1
        ret["retMsg"] = "/"
        sessionId = uuid.uuid4()
        util.insertRedis(sessionId, json.dumps({"userID": rs[0],"tokenId":rs[3]}))
        # session['username'] = username
        ret["retData"] = sessionId
        return jsonify(ret)
    else:
        return jsonify(ret)


@user.route('code')
def get_code():
    image, strs = code.validate_picture()
    # 将验证码图片以二进制形式写入在内存中，防止将图片都放在文件夹中，占用大量磁盘
    buf = BytesIO()
    image.save(buf, 'jpeg')
    buf_str = buf.getvalue()
    # 把二进制作为response发回前端，并设置首部字段
    response = make_response(buf_str)
    response.headers['Content-Type'] = 'image/gif'
    # 将验证码字符串储存在session中
    imgsessionId = str(uuid.uuid4())
    response.set_cookie("imgsessionId", imgsessionId)
    session[imgsessionId] = strs
    return response


@user.route('register')
def register():
    return render_template('register.html')


@user.route('sendvalcode', methods=['POST'])
def sendvalcode():
    phoneNo = request.form.get("phoneNo")
    strcode = random.randint(100000, 1000000)
    util.insertRedis(phoneNo, str(strcode))
    # TODO 发送短信验证码
    sendSMS.sendSMS(content=strcode, phoneNo=phoneNo)
    return jsonify({"retCode": 1})


@user.route('registers', methods=['POST'])
def registers():
    ret = {}
    ret["retCode"] = 0
    ret["retMsg"] = "您的网络出故障了"
    phoneNo = request.form.get("phoneNo")
    phoneNocode = request.form.get("phoneNocode")
    username = request.form.get("username")
    password = request.form.get("password")
    val_code = request.form.get("val_code")

    # TODO 判断手机验证码是否正确
    phonecode = util.readRedis(phoneNo)
    if str(phoneNocode) != str(phonecode):
        ret["retMsg"] = "手机验证码错误"
        return jsonify(ret)

    phonecode = util.readRedis(phoneNo)
    if str(phoneNocode) != str(phonecode):
        ret["retMsg"] = "手机验证码错误"
        return jsonify(ret)
    # TODO 判断图形验证码是否正确
    imgsessionId = request.cookies.get("imgsessionId")
    codestr = session[imgsessionId]
    if val_code.lower() != codestr.lower():
        ret["retMsg"] = "图形验证码错误，请输入"
        return jsonify(ret)
    # TODO 判断手机号是否唯一
    rs = userbiz.getUserByPhoneNo(phoneNo)
    if rs != None:
        ret["retMsg"] = "此手机号码已注册"
        return jsonify(ret)
    # TODO 判断用户名是否唯一
    rs = userbiz.getUserByUserName(username)
    if rs != None:
        ret["retMsg"] = "此用户名已注册"
        return jsonify(ret)
    userbiz.insertData(username=username, phoneNo=phoneNo, password=password)
    return jsonify({"retCode": 1, "retMsg": "/login"})
