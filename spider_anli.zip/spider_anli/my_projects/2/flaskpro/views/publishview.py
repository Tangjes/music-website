from flask import Blueprint, render_template, jsonify, request, redirect
from biz import spiderinfobiz, spiderwebinfobiz
from utilz import deco
import json

push = Blueprint('pusher', __name__,
                 template_folder='templates',
                 static_folder='static',
                 static_url_path='static',
                 url_prefix='/')


@push.route('')
@deco.wapper
def index(**kwargs):
    data=json.loads(kwargs["data"])
    userId = data["userID"]
    tokenId = data["tokenId"][:4]+"****"+data["tokenId"][-4:]
    # 1 根据userID读一遍数据库，把token拿过来
    # 2. 登录成功以后，直接把token放在缓存，直接拿数据
    data = spiderwebinfobiz.getData(userId=userId)
    return render_template('lists.html', data=data, userId=userId,tokenId=tokenId)


@push.route('list')
@deco.wapper
def list(**kwargs):
    data = spiderinfobiz.getData()
    return render_template('lists.html', data=data)


@push.route('list2')
@deco.wapper
def list2(**kwargs):
    data = spiderinfobiz.getData()
    return render_template('listsajax.html', data=data)


@push.route('listajax')
@deco.wapper
def listajax(**kwargs):
    data = spiderinfobiz.getData()
    return jsonify(data)


@push.route('infodetail/<logId>')
@deco.wapper
def infodetail(logId, **kwargs):
    data = spiderinfobiz.getDataBylogId(logId)
    return render_template('detail.html', data=data)


@push.route('detailsave', methods=['POST'])
@deco.wapper
def detailsave(**kwargs):
    data = kwargs["data"]
    data2 = json.loads(data)["userID"]
    logId = request.form.get("logId")
    url = request.form.get("url")
    title = request.form.get("title")
    body = request.form.get("body")
    userId = data2
    spiderwebinfobiz.insertData(title=title, url=url, logId=logId, userId=userId, body=body)
    return redirect('/')
