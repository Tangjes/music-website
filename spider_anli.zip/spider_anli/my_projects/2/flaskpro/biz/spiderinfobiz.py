from dao import spiderinfodao


def insertData(title, body, url, infoId):
    return spiderinfodao.insertData(title, body, url, infoId)


def getData():
    return spiderinfodao.getData()


def getDataBylogId(logID):
    return spiderinfodao.getDataByLogId(logID)
