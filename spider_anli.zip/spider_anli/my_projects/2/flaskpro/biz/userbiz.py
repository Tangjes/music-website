from dao import userdao


def getDataByUserId(userId):
    return userdao.getDataByUserId(userId=userId)


def getUserByUserName(username):
    return userdao.getUserByUserName(username=username)


def getUserByPhoneNo(phoneNo):
    return userdao.getUserByPhoneNo(phoneNo)


def insertData(username, password, phoneNo):
    return userdao.insertData(username=username, password=password, phoneNo=phoneNo)
