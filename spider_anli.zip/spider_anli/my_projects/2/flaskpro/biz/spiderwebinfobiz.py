from dao import spiderwebinfodao


def insertData(title, body, url, logId, userId):
    rs = spiderwebinfodao.getDataByLogId(logId=logId)
    if rs:
        return spiderwebinfodao.updateData(logId=logId, title=title, url=url, body=body)
    else:
        return spiderwebinfodao.insertData(title, body, url, userId=userId, logId=logId)


def getData(userId):
    return spiderwebinfodao.getData(userId=userId)


def getDataBylogId(logID):
    return spiderwebinfodao.getDataByLogId(logID)
