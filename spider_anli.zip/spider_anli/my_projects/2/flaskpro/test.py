import requests
import datetime, hashlib

while 1:
    print(1)
    # s = requests.session()
    # phoneNo = '123456'
    # body = "李恩志"
    # userId = "41212df5-26b5-4b25-bbbd-8bd51bfbfe3d"
    # timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
    # token = '3ce457d72e2dea43e65f6f022720d272'
    # # sig =token +userId + timestamp
    # sig = userId + token + timestamp
    # h1 = hashlib.md5()
    # h1.update(sig.encode(encoding='utf-8'))
    # token2 = h1.hexdigest()
    # data = {"token": token2, "body": body, "phoneNo": phoneNo, "timestamp": str(timestamp), "userId": userId}
    # r = s.post('http://192.168.50.252:8400/asd', data=data)
    # html = r.content.decode('utf-8')
    # print(html)
