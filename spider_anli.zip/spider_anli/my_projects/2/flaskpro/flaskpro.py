from flask import Flask
from views.publishview import push
from views.userview import user
from views.apiview import api

app = Flask(__name__)
app.secret_key = 'r\x9ey8\nL\xbeP8\x8e\x82/\x87\xe5\xc0\x1b\xa9\x8f\xa0>-\x1a\xca6'
app.register_blueprint(push)
app.register_blueprint(user)
app.register_blueprint(api)

if __name__ == '__main__':
    app.run(debug=False, port=5100, host="0.0.0.0")
