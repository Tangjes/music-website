from . import dbredis


def insertRedis(sessionId, data, times=1800):
    try:
        dbredis.r.setex("flaskpro:%s" % sessionId, data, time=times)
    except Exception as e:
        print(e)


def readRedis(sessionId):
    try:
        return dbredis.r.get("flaskpro:%s" % sessionId)
    except Exception as e:
        print(e)
