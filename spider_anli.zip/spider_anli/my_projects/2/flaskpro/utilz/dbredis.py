import redis
import config

pool = redis.ConnectionPool(host=config.RedisConfig.host, port=config.RedisConfig.port, decode_responses=True)

r = redis.Redis(connection_pool=pool)
