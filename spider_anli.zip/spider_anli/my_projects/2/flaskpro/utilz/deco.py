from flask import redirect, request
from utilz import util
import functools

def wapper(func):
    @functools.wraps(func)
    def inner(*args, **kwargs):
        sessionIDS = request.cookies.get('sessionIDS')
        data = None
        if sessionIDS:
            data = util.readRedis(sessionId=sessionIDS)
            if data != None:
                funct = func(*args, **kwargs,data=data)
                util.insertRedis(sessionId=sessionIDS, data=data)
                return funct
        if sessionIDS == None or data == None:
            return redirect('/login')

    return inner
