import os


class DBMysql():
    host = '127.0.0.1'
    port = 3306
    user = 'root'
    passwd = '123456'
    db = 'webuse'


class RedisConfig():
    host = '192.168.50.203'
    port = 6379


class Paths():
    basedir = os.path.dirname(os.path.realpath(__file__))


class MQ():
    url = "amqp://spider:spider_123@127.0.0.1:5672//spider"
