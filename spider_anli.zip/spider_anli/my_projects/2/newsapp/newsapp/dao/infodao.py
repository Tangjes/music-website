from newsapp.utilz import dbmysql, util


def getDataByURl(url):
    try:
        sql = "SELECT count(1) FROM URL WHERE URL='%s';" % url
        rs = dbmysql.first(sql)
        return rs
    except Exception as e:
        print(e)
        return None


def insertData(url, title, body, pushTime):
    try:
        s = []
        infoId = util.getUUID()
        # body=util.getNoFh(body)
        sql = "insert into url(infoId,insertTime,opertionTime,url,source) VALUE ('%s',now(),now(),'%s','sina');" % (
            infoId, url)
        s.append(sql)
        sql = "insert into info(infoId,insertTime,title,url,body,pushTime) VALUE ('%s',now(),'%s','%s','%s','%s');" % (
            infoId, title, url, body, pushTime)
        s.append(sql)
        dbmysql.execute2(s)
    except Exception as e:
        print(e)
