import datetime, time, re, uuid


# 将时间戳转换为时间
def getDatetime(timeint):
    try:
        ltime = time.localtime(float(timeint))
        timeStr = time.strftime("%Y-%m-%d %H:%M:%S", ltime)
        return timeStr
    except Exception as ex:
        print(ex)


# 比较时间，只提取两天内的时间
def getCompareTime(time1):
    '''
    :param time1: 爬过来的时间
    :return:
    '''
    try:
        sdata = time1.split('-')  # 将爬过得时间字符串，分割，变成list
        dDate = datetime.date(int(sdata[0]), int(sdata[1]), int(sdata[2]))  # 将爬过的时间强制转换为日期格式
        adate = datetime.datetime.now() - datetime.timedelta(days=1)  # 求昨天的日期
        nDate = datetime.date(adate.year, adate.month, adate.day)  # 将昨天的日期转换为日期格式
        if dDate >= nDate:  # 如果爬取过来的日期大于昨天的日期，这条数据可用
            return True
        else:
            return False
    except Exception as ex:
        return False


def getNoHtmlBody(content):
    body = None
    try:
        dr = re.compile(r'<[^>]+>', re.S)
        body = dr.sub('', content)
    except Exception as ex:
        print(ex)
    return body


def getNoFh(body):
    return body.replace("'", "’").replace('"', "“").replace(',', '，').replace(';', '；')


def getUUID():
    '''
    生成UUID
    :return:
    '''
    return str(uuid.uuid4())
