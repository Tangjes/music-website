import pymysql
from newsapp import settings


def getConnect():
    cursor = None
    conn = None
    try:
        # 创建连接
        conn = pymysql.connect(host=settings.MYSQLHOST, port=settings.MYSQLPORT, user=settings.MYSQLUSER,
                               passwd=settings.MYSQLPASSWORD, db=settings.MYSQLDB, charset='utf8')
        # 创建游标
        cursor = conn.cursor()
    except Exception as e:
        print(e)
    return cursor, conn


# add update delete
def execute(sql):
    cursor, conn = getConnect()
    effect_row = 0
    try:
        effect_row = cursor.execute(sql)
        conn.commit()
    except Exception as e:
        print(e)
    finally:
        # 关闭游标
        cursor.close()
        # 关闭连接
        conn.close()

    return effect_row


# add update delete
def execute2(sql):
    cursor, conn = getConnect()
    effect_row = 0
    try:
        conn.begin()
        for item in sql:
            effect_row = cursor.execute(item)
        conn.commit()
    except Exception as e:
        print(e)
        print(sql)
    finally:
        # 关闭游标
        cursor.close()
        # 关闭连接
        conn.close()

    return effect_row


# one
def first(sql):
    cursor, conn = getConnect()
    row_1 = None
    try:
        cursor.execute(sql)
        # 获取剩余结果的第一行数据
        row_1 = cursor.fetchone()
        conn.commit()
    except Exception as e:
        print(e)
    finally:
        # 关闭游标
        cursor.close()
        # 关闭连接
        conn.close()

    return row_1


# 所有行
def fetchall(sql):
    cursor, conn = getConnect()
    rows = None
    try:
        cursor.execute(sql)
        # 获取剩余结果的所有行数据
        rows = cursor.fetchall()
        conn.commit()
    except Exception as e:
        print(e)
    finally:
        # 关闭游标
        cursor.close()
        # 关闭连接
        conn.close()

    return rows
