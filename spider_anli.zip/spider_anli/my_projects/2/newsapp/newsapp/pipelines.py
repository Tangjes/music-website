# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
from newsapp.items import NewsappItem, News2
from newsapp.dao import infodao


class NewsappPipeline(object):
    def process_item(self, item, spider):
        if isinstance(item, NewsappItem):
            data = dict(item)
            url = data["url"]
            title = data["title"]
            body = data["body"]
            pushtime = data["pushtime"]
            infodao.insertData(url=url, title=title, pushTime=pushtime, body=body)
        return item
