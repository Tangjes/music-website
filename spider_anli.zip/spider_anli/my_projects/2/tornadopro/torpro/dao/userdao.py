from utilz.dbmongo import db
from utilz import util
import datetime
import json
from utilz.util import JSONEncoder
table = db.users


def getUserByPhone(phoneNo):
    return table.find_one({"phoneNo": phoneNo})


def insertUser(phoneNo, password, dept):
    try:
        user = {}
        user["userId"] = util.getUUID()
        user["phoneNo"] = phoneNo
        user["password"] = password
        user["dept"] = dept
        user["tokenId"] = util.md5(util.getUUID())
        user["insertTime"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        user["opertionTime"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        table.insert(user)
        return user
    except Exception as e:
        util.logger.error(e)
        return None


'''
解决高并发mongodb的瓶颈问题，先去读缓存，再去读mongo
'''


def getUserByUserId(userID):
    rs = None
    iserror = False
    try:
        rs = util.getRedisByKey(userID)
        if rs:
            rs=json.loads(rs)
    except Exception as e:
        util.logger.error(e)
        iserror = True
    if rs == None or iserror == True:
        try:
            rs = table.find_one({"userId": userID})
            rsdata=JSONEncoder().encode(rs)
            util.insertRedis(userID, value=rsdata, time=1800)
        except Exception as e:
            util.logger.error(e)
            return 2
    return rs
