from utilz.dbmongo import db
from utilz import util
import datetime, json

table = db.module



def insertModule(qianming, body, userId):
    info = {}
    info["moduleId"] = util.getUUID()
    info["insertTime"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    info["opertionTime"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    info["qianming"] = qianming
    info["body"] = body
    info["userId"] = userId
    table.insert(info)
    return info


def updateModule(moduleId, qianming, body):
    data = getModuleByModuleId(moduleId=moduleId)
    data["qianming"] = qianming
    data["body"] = body
    data["opertionTime"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    table.save(data)
    return data


def deleteModule(moduleId):
    data =table.remove({"moduleId":moduleId})
    return data


def getModuleByModuleId(moduleId):
    return table.find_one({"moduleId": moduleId})


def getModules():
    return table.find()
