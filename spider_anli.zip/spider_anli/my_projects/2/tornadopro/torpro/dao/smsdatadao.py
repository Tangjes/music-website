from utilz.dbmongo import db
from utilz import util
import datetime, json
import pymongo

table = db.senddata


def getInfoByUserId(userId, page, rows):
    '''
    假设条件：一页显示20条数据
    第一页：0-20     （1-1）*20-1*20
    第二页 20-40     （2-1）*20----2*20
    第三页 40-60     （3-1）*20----3*20
    '''
    startnum = (page - 1) * rows
    return table.find({"userId": userId}).sort("insertTime", pymongo.DESCENDING).skip(startnum).limit(rows)


def getCacheInfoByUserId(userId, page, rows):
    data = util.getRedisByKey(userId + str(page))
    if data == None:
        startnum = (page - 1) * rows
        data = table.find({"userId": userId}).sort("insertTime", pymongo.DESCENDING).skip(startnum).limit(rows)
        listdata = []
        for item in data:
            listdata.append(item)
        util.insertRedis(userId + str(page), value=util.JSONEncoder().encode(listdata))
        return listdata
    else:
        data = json.loads(data)
        return data


def getCountByUserId(userId):
    return table.find({"userId": userId}).count()


def insertInfointocache(phoneNo, body, userId):
    info = {}
    info["smsId"] = util.getUUID()
    info["insertTime"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    info["opertionTime"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    info["phoneNo"] = phoneNo
    info["body"] = body
    info["userId"] = userId
    util.insertRedis(info["smsId"], json.dumps(info), time=600)
    # table.insert(info)
    return info


def insertInfo(smsId, phoneNo, body, userId):
    info = {}
    info["smsId"] = smsId
    info["insertTime"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    info["opertionTime"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    info["phoneNo"] = phoneNo
    info["body"] = body
    info["userId"] = userId
    table.insert(info)
    return info


def getInfoBysmsId(smsId):
    return table.find_one({"smsId": smsId})


def getInfoByPhoneNo(phoneNo):
    return table.find({"phoneNo": phoneNo})
