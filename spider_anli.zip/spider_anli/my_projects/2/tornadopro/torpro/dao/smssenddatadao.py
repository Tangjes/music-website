from utilz.dbmongo import db
from utilz import util
import datetime

table = db.sendthreedata


def getInfoByUserId(userId):
    return table.find({"userId": userId})


def insertInfo(smsId, phoneNo, body, userId, pingtai):
    info = {}
    info["smsId"] = smsId
    info["insertTime"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    info["opertionTime"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    info["phoneNo"] = phoneNo
    info["body"] = body
    info["userId"] = userId
    info["pingtai"] = pingtai
    table.insert(info)
    return info


def getInfoBysmsId(smsId):
    return table.find_one({"smsId": smsId})


def getInfoByPhoneNo(phoneNo):
    return table.find({"phoneNo": phoneNo})
