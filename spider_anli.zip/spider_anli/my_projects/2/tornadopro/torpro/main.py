import tornado.web
import tornado.httpserver
import tornado.ioloop
import tornado.options
import os.path
from tornado.options import define, options
from views import userview, dataviews, apiviews
from utilz import util

define("port", default=8400, help="run on the given port", type=int)


class Application(tornado.web.Application):
    def __init__(self):
        handlers = [
            (r"/", userview.IndexHandler),
            (r"/register", userview.RegisterHandler),
            (r"/list", dataviews.ListHandler),
            (r"/module", dataviews.ModuleHandler),
            (r"/tongji", dataviews.TongjiHandler),
            (r"/sendsms", userview.SendsmsHandler),
            (r"/scantoken", userview.ScanTokenHandler),
            (r"/asd", apiviews.ApiResiveHandler),
            (r"/sendthree", dataviews.SendthreeHandler),
            (r"/addmodule", dataviews.AddmoduleHandler),
            (r"/updatemodule", dataviews.UpdatemoduleHandler),
            (r"/deletemodule", dataviews.DeletemoduleHandler),
            (r"/search", dataviews.SearchHandler),
        ]
        settings = dict(
            template_path=os.path.join(os.path.dirname(__file__), "templates"),
            static_path=os.path.join(os.path.dirname(__file__), "static"),
            debug=False,
            cookie_secret="\x08\x9e\xd32\x12{\xf1\x9a\xbe[G\x11Rb\xe1F|\x04\x12\xdbz\x9e-\xfe"
        )

        tornado.web.Application.__init__(self, handlers, **settings)


if __name__ == "__main__":
    tornado.options.parse_command_line()
    http_server = tornado.httpserver.HTTPServer(Application())
    http_server.listen(options.port)
    util.logger.info('正在监听%s' % options.port)
    tornado.ioloop.IOLoop.instance().start()
