import tornado.web
from dao import smsdatadao, userdao
from utilz import util
import json
from utilz import deco
import smssendwork

'''
要求接口300的并发量
'''


class ApiResiveHandler(tornado.web.RequestHandler):
    def post(self, *args, **kwargs):
        ret = {}
        ret["retCode"] = 0
        ret["retMsg"] = "您的网络开小差了"
        phoneNo = self.get_argument("phoneNo", '')
        smsbody = self.get_argument("body", '')
        userId = self.get_argument("userId", '')
        token = self.get_argument("token", '')
        timestamp = self.get_argument("timestamp", '')

        # TODO 比对userId是否存在
        rs = userdao.getUserByUserId(userId)
        if rs == None:
            ret["retCode"] = "1000"
            ret["retMsg"] = "此用户不存在"
            return self.write(ret)
        # TODo 比对token是否合法

        md5str = userId + rs["tokenId"] + timestamp
        md5token = util.md5(md5str)
        if md5token != token:
            ret["retCode"] = "1001"
            ret["retMsg"] = "token失败"
            return self.write(ret)

        # TODO  数据入库
        data = smsdatadao.insertInfointocache(phoneNo=phoneNo, userId=userId, body=smsbody)
        # 发送短信
        smssendwork.add.delay(data["smsId"])
        ret["retCode"] = "0000"
        ret["retMsg"] = "接收成功"
        ret["retData"] = data["smsId"]
        self.write(ret)
