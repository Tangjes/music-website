import tornado.web
from torpro.dao import userdao
from torpro.utilz import util, deco
import json, random
from torpro.biz import sendSMS


class IndexHandler(tornado.web.RequestHandler):
    def get(self):
        info = self.get_argument('info', '')
        self.render('login.html', info=info)

    def post(self, *args, **kwargs):
        phoneNo = self.get_argument('phoneNo', '')
        password = self.get_argument('password', '')
        # 去数据库里面判断手机号码是否存在，如果存在，比对密码
        iscorrect = False
        rs = userdao.getUserByPhone(phoneNo)
        if rs:
            if rs["password"] == password:
                sessionId = util.md5(util.getUUID())
                # self.set_secure_cookie("phoneNo", phoneNo)
                self.set_secure_cookie("sessIds", sessionId, path='/')
                util.insertRedis(sessionId, json.dumps(
                    {"userId": rs["userId"], "tokenId": rs["tokenId"], "phoneNo": rs["phoneNo"]}))
                iscorrect = True
                self.redirect('/list')
        if rs == None or iscorrect == False:
            self.redirect('/?info=用户名密码不匹配')


class RegisterHandler(tornado.web.RequestHandler):
    def get(self):
        info = self.get_argument('info', '')
        self.render('register.html', info=info)

    def post(self, *args, **kwargs):
        phoneNo = self.get_argument('phoneNo', '')
        password = self.get_argument('password', '')
        dept = self.get_argument('dept', '')
        # 去数据库里面判断手机号码是否存在，如果不存在，则插入数据库
        rs = userdao.getUserByPhone(phoneNo)
        if rs:
            self.redirect('/register?info=此用户已存在')
        else:
            userdao.insertUser(phoneNo=phoneNo, password=password, dept=dept)
        self.redirect('/')


class SendsmsHandler(tornado.web.RequestHandler):
    @deco.wrapper
    def get(self, *args, **kwargs):
        data = json.loads(kwargs["data"])
        phoneNo = data["phoneNo"]
        # smsbody = random.randint(100000, 999999)
        smsbody=123
        util.insertRedis(phoneNo, json.dumps({"phoneNo": smsbody}))
        # sendSMS.sendSMS(smsbody, phoneNo)
        self.write(json.dumps({"retCode": 1,"retData":smsbody}))


class ScanTokenHandler(tornado.web.RequestHandler):
    @deco.wrapper
    def post(self, *args, **kwargs):
        data = json.loads(kwargs["data"])
        phoneNo = data["phoneNo"]
        ret = {}
        ret["retCode"] = 0
        ret["retMsg"] = "您的网络开小差了"
        yzm = self.get_argument("yzm")
        yzm2 = util.getRedisByKey(phoneNo)
        jsondata = json.loads(yzm2)["phoneNo"]
        if yzm == str(jsondata):
            ret["retCode"] = 1
            ret["retMsg"] = data["tokenId"]
            self.write(ret)
