import tornado.web
from dao import smsdatadao, smssenddatadao, moduledao
from utilz import util
import json
from utilz import deco
import math


class ListHandler(tornado.web.RequestHandler):
    @deco.wrapper
    def get(self, **kwargs):
        data = json.loads(kwargs["data"])
        userId = data["userId"]
        phoneNo = data["phoneNo"]
        tokenId = data["tokenId"][:4] + "****" + data["tokenId"][-4:]
        # TODO 获取当前页
        rows = 20
        page = int(self.get_argument('page', '1'))
        pre = 1  # 上一页
        if page >= 1:
            pre = page - 1
        count = smsdatadao.getCountByUserId(userId)
        next = 1
        sumpage = math.ceil(count / rows)
        if page < sumpage:
            next = page + 1
        else:
            next = 0
        # TODO 根据当前页计算上一页
        # TODO 根据当前页计算下一页
        if page < 6:
            # TODO 读缓存，如果缓存中，没有数据，先去读磁盘，然后将数据缓存
            data = smsdatadao.getCacheInfoByUserId(userId=userId, page=page, rows=rows)
        else:
            data = smsdatadao.getInfoByUserId(userId=userId, page=page, rows=rows)
        self.render('list.html', data=data, userId=userId, tokenId=tokenId, phoneNo=phoneNo, pre=pre, next=next)


class ModuleHandler(tornado.web.RequestHandler):
    @deco.wrapper
    def get(self, **kwargs):
        data = moduledao.getModules()
        self.render('module.html', data=data)


class TongjiHandler(tornado.web.RequestHandler):
    @deco.wrapper
    def get(self, **kwargs):
        self.render('tongji.html')


class SendthreeHandler(tornado.web.RequestHandler):
    @deco.wrapper
    def get(self, **kwargs):
        data = json.loads(kwargs["data"])
        userId = data["userId"]
        data = smssenddatadao.getInfoByUserId(userId=userId)
        self.render('listthree.html', data=data)


class AddmoduleHandler(tornado.web.RequestHandler):
    @deco.wrapper
    def get(self, **kwargs):
        data = json.loads(kwargs["data"])
        userId = data["userId"]
        self.render('addmodule.html')

    @deco.wrapper
    def post(self, *args, **kwargs):
        data = json.loads(kwargs["data"])
        userId = data["userId"]
        qianming = self.get_argument('qianming', '')
        body = self.get_argument('body', '')
        moduledao.insertModule(qianming=qianming, body=body, userId=userId)
        self.redirect('/module')


class UpdatemoduleHandler(tornado.web.RequestHandler):
    @deco.wrapper
    def get(self, **kwargs):
        moduleId = self.get_argument('moduleId')
        data = moduledao.getModuleByModuleId(moduleId=moduleId)
        self.render('updatemodule.html', module=data)

    @deco.wrapper
    def post(self, *args, **kwargs):
        moduleId = self.get_argument('moduleId')
        qianming = self.get_argument('qianming', '')
        body = self.get_argument('body', '')
        moduledao.updateModule(moduleId=moduleId, qianming=qianming, body=body)
        self.redirect('/module')


class DeletemoduleHandler(tornado.web.RequestHandler):
    @deco.wrapper
    def get(self, **kwargs):
        moduleId = self.get_argument('moduleId')
        moduledao.deleteModule(moduleId=moduleId)
        self.redirect('/module')


class SearchHandler(tornado.web.RequestHandler):
    @deco.wrapper
    def get(self, **kwargs):
        body = self.get_argument('search')
        listdata = []
        if len(body) == 36:
            # TODO 按照短信smsId查询
            first = smssenddatadao.getInfoBysmsId(body)

            second = smsdatadao.getInfoBysmsId(body)
            if first != None:
                listdata.append(first)
            if second != None:
                second["pingtai"] = ''
                listdata.append(second)
        else:
            # TODO 按照电话号码查询
            first = smssenddatadao.getInfoByPhoneNo(body)
            second = smsdatadao.getInfoByPhoneNo(body)
            [listdata.append(item) for item in first]
            [listdata.append(item) for item in second]

        self.render('search.html', data=listdata)
