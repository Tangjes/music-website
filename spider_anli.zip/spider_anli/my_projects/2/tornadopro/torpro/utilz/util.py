import uuid
import hashlib
from utilz import dbredis
import logging
import json
from bson import ObjectId

'''
linux上如下写法即可
# logging.basicConfig(level=logging.DEBUG,
#                     format='[%(asctime)s - %(filename)s-line:%(lineno)d - %(levelname)s]: %(message)s')
# logger = logging.getLogger()
'''
logging.basicConfig(level=logging.DEBUG,
                    format='[%(asctime)s - %(filename)s-line:%(lineno)d - %(levelname)s]: %(message)s')
logger = logging.getLogger()
'''
windows上写日志，必然指定文件名，如下写法
'''


# --------------------------begin-----------------------#
# def get_logger():
#     fh = logging.FileHandler('b.log', encoding='utf-8')  # 创建一个文件流并设置编码utf8
#     logger = logging.getLogger()  # 获得一个logger对象，默认是root
#     logger.setLevel(logging.DEBUG)  # 设置最低等级debug
#     fm = logging.Formatter("[%(asctime)s - %(filename)s-line:%(lineno)d - %(levelname)s]: %(message)s")  # 设置日志格式
#     logger.addHandler(fh)  # 把文件流添加进来，流向写入到文件
#     fh.setFormatter(fm)  # 把文件流添加写入格式
#     return logger


# logger = get_logger()


# --------------------------end-----------------------#

def getUUID():
    return str(uuid.uuid4())


def md5(md5str):
    h1 = hashlib.md5()
    h1.update(md5str.encode(encoding='utf-8'))
    return h1.hexdigest()


def insertRedis(key, value, time=1800):
    dbredis.r.setex("torpro:%s" % key, value=value, time=time)


def getRedisByKey(key):
    return dbredis.r.get("torpro:%s" % key)


class JSONEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, ObjectId):
            return str(o)
        return json.JSONEncoder.default(self, o)
