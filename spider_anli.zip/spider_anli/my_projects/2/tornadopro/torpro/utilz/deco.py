from utilz import util


def wrapper(fun):
    def inner(self, *args, **kwargs):
        sessionIds = self.get_secure_cookie("sessIds").decode('utf-8')
        if sessionIds != None:
            data = util.getRedisByKey(sessionIds)
            if data != None:
                f = fun(self,data=data)
                util.insertRedis(sessionIds, data)
                return f
            else:
                self.redirect('/')
        else:
            self.redirect('/')

    return inner
