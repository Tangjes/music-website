import pymongo
import config

client = pymongo.MongoClient(host=config.MongoDB.mongoIP, port=config.MongoDB.mongoPort)
db = client.sms
