import requests, datetime
import hashlib


def sendSMS(content, phoneNo):
    accountSid = "5a9e805d86c34a96af8713bf9febae68"
    timestamp = datetime.datetime.now().strftime('%b%d%y%H%M%S')
    authtoken = "6287ad25c6f24390851b3bd3a555a996"

    hl = hashlib.md5()
    hl.update(str(accountSid + authtoken + timestamp).encode(encoding='utf-8'))
    sig = hl.hexdigest()

    data = {
        "accountSid": accountSid,
        # "smsContent": "【奇酷科技】尊敬的用户，您的验证码为%s" % content,
        "smsContent": "【奇酷科技】尊敬，您的验证码为%s" % content,
        "to": phoneNo,
        "timestamp": timestamp,
        "sig": sig,
        "respDataType": "JSON"
    }
    r = requests.post(url='https://api.miaodiyun.com/20150822/industrySMS/sendSMS', data=data)
    print(r.content.decode('utf-8'))
    return r.content
