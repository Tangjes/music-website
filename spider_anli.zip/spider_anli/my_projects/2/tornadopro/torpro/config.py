class MongoDB():
    mongoIP = "192.168.50.203"
    mongoPort = 33356


class RedisConfig():
    host = '192.168.50.203'
    port = 6379


class MQ():
    url = "amqp://spider:spider_123@127.0.0.1:5672//spider"
