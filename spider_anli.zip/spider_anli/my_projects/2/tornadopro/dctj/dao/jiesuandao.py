from utils import dbmysql, util


def getjissuan():
    rs = None
    try:
        sql = "select * from jiesuan ORDER BY insertTime DESC ;"
        rs = dbmysql.fetchall(sql)
    except Exception as e:
        util.logger.error(e)
    return rs


def getjissuanByjsId(jsid):
    rs = None
    try:
        sql = "select * from jiesuan where jsid=%s ;" % jsid
        rs = dbmysql.first(sql)
    except Exception as e:
        util.logger.error(e)
    return rs


def insertJiesuan(userId, starttime, endtime, count, realName):
    rs = None
    try:
        sql = "insert into jiesuan(userId,insertTime,realName,本次结算条数,结算起始时间,结算结束时间) VALUES ('%s',now(),'%s','%s','%s','%s');" % (
            userId, realName, count, starttime, endtime)
        rs = dbmysql.query(sql)
    except Exception as e:
        util.logger.error(e)
    return rs


def deletejiesuan(jsid):
    rs = None
    try:
        sql = "delete from jiesuan where jsid=%s;" % (jsid)
        rs = dbmysql.query(sql)
    except Exception as e:
        util.logger.error(e)
    return rs
