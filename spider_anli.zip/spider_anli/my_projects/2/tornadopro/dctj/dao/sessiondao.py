from utils import dbmysql, util


def getSessionBySessionId(sessionId):
    rs = None
    try:
        sql = "select * from sessiontable as ss,users where ss.userId=users.userId and sessionId='%s';" % (sessionId.decode('utf8'))
        rs = dbmysql.first(sql)
    except Exception as e:
        util.logger.error(e)
    return rs


def insertSessionId(sessionId, userId):
    rs = None
    try:
        sql = "insert into sessiontable(sessionId,userId,insertTime) VALUES ('%s','%s',now());" % (
            sessionId, userId)
        rs = dbmysql.query(sql)
    except Exception as e:
        util.logger.error(e)
    return rs


def deleteSessionId(sessionId):
    rs = None
    try:
        sql = "delete sessiontable where sessionId='%s';" % (sessionId)
        rs = dbmysql.query(sql)
    except Exception as e:
        util.logger.error(e)
    return rs
