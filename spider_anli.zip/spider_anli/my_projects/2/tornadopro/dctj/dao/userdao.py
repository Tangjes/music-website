from utils import dbmysql, util


def insertUser(phoneNo, realName, bankCard, password):
    userId = util.getUUID()
    rs = None
    try:
        sql = "insert into users(userId,insertTime,phoneNo,realName,bankCard,password,isadmin) VALUES ('%s',now(),'%s','%s','%s','%s',0);" % (
            userId, phoneNo, realName, bankCard, password)
        dbmysql.query(sql)
        return userId
    except Exception as e:
        util.logger.error(e)
    return rs


def updateUser(userId, phoneNo, realName, bankCard, password):
    rs = None
    try:
        sql = "update users set "
        if phoneNo != '':
            sql = "%s phoneNo='%s'," % (sql, phoneNo)
        if realName != '':
            sql = "%s realName='%s'," % (sql, realName)
        if bankCard != '':
            sql = "%s bankCard='%s'," % (sql, bankCard)
        if password != '':
            sql = "%s password='%s'," % (sql, password)
        sql = "%s where userId='%s';" % (sql[:-1], userId)

        rs = dbmysql.query(sql)
    except Exception as e:
        util.logger.error(e)
    return rs


def getUserByUserId(userId):
    rs = None
    try:
        sql = "select * from users where userId='%s';" % (userId)
        rs = dbmysql.first(sql)
    except Exception as e:
        util.logger.error(e)
    return rs


def getUserByPhone(phoneNo):
    rs = None
    try:
        sql = "select * from users where phoneNo='%s';" % (phoneNo)
        rs = dbmysql.first(sql)
    except Exception as e:
        util.logger.error(e)
    return rs


def getSessionBySessionId(sessionId):
    rs = None
    try:
        sql = "select * from sessiontable where sessionId='%s';" % (sessionId)
        rs = dbmysql.first(sql)
    except Exception as e:
        util.logger.error(e)
    return rs


def insertSessionId(sessionId, userId, isadmin):
    rs = None
    try:
        sql = "insert into sessiontable(sessionId,userId,isadmin,insertTime) VALUES ('%s','%s',%s,now());" % (
            sessionId, userId, isadmin)
        rs = dbmysql.query(sql)
    except Exception as e:
        util.logger.error(e)
    return rs
