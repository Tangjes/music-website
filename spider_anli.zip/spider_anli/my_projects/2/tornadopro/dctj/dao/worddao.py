from utils import util, dbmysql


def insertWord(userId, realName, citiao, shiyi, jybjssm, xgayfl, xgyjxkdm, xgyjxk,
               xgejxkdm, xgejxk, xgsjxkdm, xgsnxk, liju, ljsy, ljyy, pic, tsyy, bg, bgyy):
    wordId = util.getUUID()
    try:
        sql = "insert into word(wordId,insertTime,opertionTime,userId,真实姓名,是否结算," \
              "词条,释义,进一步解释和说明,相关的奥运分类,相关一级学科代码,相关一级学科," \
              "相关二级学科代码,相关二级学科,相关三级学科代码,相关三级学科,例句,例句释义," \
              "例句引用,图示图例,图示引用,表格,表格引用,isdelete) VALUES " \
              "('%s',now(),now(),'%s','%s',0,'%s','%s','%s','%s',%s,'%s',%s,'%s',%s,'%s','%s','%s','%s','%s','%s','%s','%s',0);" % (
                  wordId, userId, realName, citiao, shiyi, jybjssm, xgayfl, xgyjxkdm,
                  xgyjxk, xgejxkdm, xgejxk, xgsjxkdm, xgsnxk, liju, ljsy, ljyy, pic, tsyy, bg, bgyy)
        dbmysql.query(sql)
        return wordId
    except Exception as e:
        util.logger.error(e)
        return None


def updateWord(wordId, citiao, shiyi, jybjssm, xgayfl, xgyjxkdm, xgyjxk, xgejxkdm, xgejxk, xgsjxkdm, xgsnxk, liju, ljsy,
               ljyy, pic, tsyy, bg, bgyy):
    try:
        sql = "update word set opertionTime=now(),词条='%s',释义='%s',进一步解释和说明='%s',相关的奥运分类='%s'," \
              "相关一级学科代码=%s,相关一级学科='%s',相关二级学科代码=%s,相关二级学科='%s'," \
              "相关三级学科代码=%s,相关三级学科='%s',例句='%s',例句释义='%s',例句引用='%s'," \
              "图示图例='%s',图示引用='%s',表格='%s',表格引用='%s' WHERE wordId='%s';" % (
                  citiao, shiyi, jybjssm, xgayfl, xgyjxkdm, xgyjxk, xgejxkdm, xgejxk, xgsjxkdm, xgsnxk, liju, ljsy,
                  ljyy, pic, tsyy, bg, bgyy, wordId)
        return dbmysql.query(sql)
    except Exception as e:
        util.logger.error(e)
        return None


def updateWordJs(userId, starttime, endtime, jsz=1):
    try:
        if jsz == 0:
            sql = "update word set 是否结算=0 where userId='%s' and insertTime BETWEEN '%s' and '%s'and 是否结算=1;" % (
                userId, starttime, endtime)
        else:
            sql = "update word set 是否结算=1 where userId='%s' and insertTime BETWEEN '%s' and '%s' and 是否结算=0;" % (
                userId, starttime, endtime)
        return dbmysql.query(sql)
    except Exception as e:
        util.logger.error(e)
        return None


def getWordbyUserId(userId, start=0, end=0):
    rs = None
    try:
        if start != 0 and end != 0:
            sql = "select * from word where userId='%s' and isdelete=0 ORDER BY insertTime DESC limit %s,%s;" % (
                userId, start, end)
        else:
            sql = "select * from word where userId='%s' and isdelete=0 ORDER BY insertTime DESC ;" % (
                userId)
        rs = dbmysql.fetchall(sql)
    except Exception as e:
        util.logger.error(e)
    return rs


def getWordbyUserIdcount(userId):
    rs = None
    try:
        sql = "select COUNT(1) from word where userId='%s' and isdelete=0 ;" % (
            userId)
        rs = dbmysql.first(sql)
    except Exception as e:
        util.logger.error(e)
    return rs


def getWordcount():
    rs = None
    try:
        sql = "select COUNT(1) from word where isdelete=0 ;"
        rs = dbmysql.first(sql)
    except Exception as e:
        util.logger.error(e)
    return rs


def getWordBywordId(wordId):
    rs = None
    try:
        sql = "select * from word where wordId='%s';" % (wordId)
        rs = dbmysql.first(sql)
    except Exception as e:
        util.logger.error(e)
    return rs


def deleteWordBywordId(wordId):
    try:
        sql = "update word set  isdelete=1 where wordId='%s';" % (wordId)
        return dbmysql.query(sql)
    except Exception as e:
        util.logger.error(e)
        return None


def getWordByword(word, start, end):
    rs = None
    try:
        if start != 0 and end != 0:
            sql = "select * from word where 词条 LIKE '%%%s%%' limit %s,%s;" % (word, start, end)
        else:
            sql = "select * from word where 词条 LIKE '%%%s%%' ORDER BY insertTime;" % (word)
        rs = dbmysql.fetchall(sql)
    except Exception as e:
        util.logger.error(e)
    return rs


def getWordBywordCount(word):
    rs = None
    try:
        sql = "select count(1) from word where 词条 LIKE '%%%s%%' ;" % (word)
        rs = dbmysql.first(sql)
    except Exception as e:
        util.logger.error(e)
    return rs


def getTjword(userId='', starttime='', endtime=''):
    rs = None
    try:
        sql = "select u.userId,count(*) as allcount,min(w.insertTime) as starttime,max(w.insertTime) as endtime,count(case when 是否结算=1 then  是否结算 else null end) as jscount,count(case when 是否结算=0 then  是否结算 else null end) as nojscount,u.realName,u.phoneNo from word w,users u where  "
        if userId != '':
            sql = sql + "u.userId='%s' and " % userId
        if starttime != '':
            sql = sql + "w.insertTime>='%s' and " % starttime
        if endtime != '':
            sql = sql + "w.insertTime<='%s' and " % endtime
        sql = sql + "w.userId=u.userId and 是否结算=0 group by userId;"
        rs = dbmysql.fetchall(sql)
    except Exception as ex:
        util.logger.error(ex)
    return rs
