from dao import worddao, jiesuandao


def insertWord(userId, realName, citiao, shiyi, jybjssm, xgayfl,
               xgyjxk, xgejxk, xgsnxk, liju, ljsy, ljyy, pic, tsyy, bg, bgyy, xgyjxkdm, xgejxkdm, xgsjxkdm):
    xgyjxkdm = xgyjxkdm if xgyjxkdm != '' else 0
    xgejxkdm = xgejxkdm if xgejxkdm != '' else 0
    xgsjxkdm = xgsjxkdm if xgsjxkdm != '' else 0
    return worddao.insertWord(userId=userId, realName=realName, citiao=citiao, shiyi=shiyi, jybjssm=jybjssm,
                              xgayfl=xgayfl, xgyjxkdm=xgyjxkdm,
                              xgyjxk=xgyjxk, xgejxkdm=xgejxkdm, xgejxk=xgejxk, xgsjxkdm=xgsjxkdm,
                              xgsnxk=xgsnxk, liju=liju, ljsy=ljsy, ljyy=ljyy, pic=pic, tsyy=tsyy,
                              bg=bg, bgyy=bgyy)


def updateWord(wordId, citiao, shiyi, jybjssm, xgayfl, xgyjxkdm, xgyjxk, xgejxkdm, xgejxk, xgsjxkdm, xgsnxk, liju, ljsy,
               ljyy, pic, tsyy, bg, bgyy):
    return worddao.updateWord(wordId=wordId, citiao=citiao, shiyi=shiyi, jybjssm=jybjssm,
                              xgayfl=xgayfl, xgyjxkdm=xgyjxkdm,
                              xgyjxk=xgyjxk, xgejxkdm=xgejxkdm, xgejxk=xgejxk, xgsjxkdm=xgsjxkdm,
                              xgsnxk=xgsnxk, liju=liju, ljsy=ljsy, ljyy=ljyy, pic=pic, tsyy=tsyy,
                              bg=bg, bgyy=bgyy)


def getWordbyUserId(userId, page=0, pagecount=0):
    start = (page - 1) * pagecount
    end = (page - 1) * pagecount + pagecount
    return worddao.getWordbyUserId(userId, start, end)


def getWordbyUserIdcount(userId):
    return worddao.getWordbyUserIdcount(userId)


def getWordcount():
    return worddao.getWordcount()


def getWordBywordId(wordId):
    rs = worddao.getWordBywordId(wordId=wordId)
    ss = str(rs.insertTime)
    dictdata = {"wordId": rs.wordId, "insertTime": str(rs.insertTime), "opertionTime": str(rs.opertionTime),
                "真实姓名": rs.真实姓名, "是否结算": rs.是否结算, "词条": rs.词条, "释义": rs.释义,
                "进一步解释和说明": rs.进一步解释和说明, "相关的奥运分类": rs.相关的奥运分类,
                "相关一级学科代码": rs.相关一级学科代码, "相关一级学科": rs.相关一级学科,
                "相关二级学科代码": rs.相关二级学科代码, "相关二级学科": rs.相关二级学科,
                "相关三级学科代码": rs.相关三级学科代码, "相关三级学科": rs.相关三级学科,
                "例句": rs.例句, "例句释义": rs.例句释义, "例句引用": rs.例句引用,
                "图示图例": rs.图示图例, "图示引用": rs.图示引用, "表格": rs.表格,
                "表格引用": rs.表格引用, "isdelete": rs.isdelete}

    return dictdata


def deleteWordBywordId(wordId):
    return worddao.deleteWordBywordId(wordId=wordId)


def getWordByword(word, page=0, pagecount=0):
    start = (page - 1) * pagecount
    end = (page - 1) * pagecount + pagecount
    return worddao.getWordByword(word=word, start=start, end=end)


def getWordBywordcount(word):
    return worddao.getWordBywordCount(word=word)


def getTJword(userId='', startTime='', endTime=''):
    return worddao.getTjword(userId=userId, starttime=startTime, endtime=endTime)


def getTjWordJk(userId='', startTime='', endTime=''):
    rs = getTJword(userId, startTime, endTime)
    jsondata = []
    for item in rs:
        jsondata.append(
            {"userId": item.userId, "realName": item.realName, "phoneNo": item.phoneNo, "allcount": item.allcount,
             "jscount": item.jscount, "nojscount": item.nojscount})
    return jsondata


def wordjs(userId, starttime, endtime, realName, count):
    worddao.updateWordJs(userId=userId, starttime=starttime, endtime=endtime)
    jiesuandao.insertJiesuan(userId=userId, realName=realName, starttime=starttime, endtime=endtime, count=count)


def wordqxjs(jsId):
    rs = jiesuandao.getjissuanByjsId(jsid=jsId)
    worddao.updateWordJs(userId=rs.userId, starttime=rs.结算起始时间, endtime=rs.结算结束时间,jsz=0)
    jiesuandao.deletejiesuan(jsId)


def getJsLsInfo():
    return jiesuandao.getjissuan()
