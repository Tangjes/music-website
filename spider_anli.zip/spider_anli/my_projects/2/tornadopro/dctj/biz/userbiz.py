from dao import userdao


def getUserByPhoneNo(phoneNo):
    return userdao.getUserByPhone(phoneNo=phoneNo)


def getUserByUserId(userId):
    return userdao.getUserByUserId(userId=userId)


def insertUser(phoneNo, realName, password, bankCard):
    rs = userdao.insertUser(phoneNo, realName, bankCard, password)
    return rs


def updateUser(userId, phoneNo='', realName='', password='', bankCard=''):
    rs = userdao.updateUser(userId=userId, phoneNo=phoneNo, realName=realName, password=password, bankCard=bankCard)
    return rs
