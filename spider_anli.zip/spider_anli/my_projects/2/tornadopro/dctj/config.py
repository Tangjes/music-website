class Config():
    DB_URI_MYSQL = "mysql+pymysql://root:123456@127.0.0.1:3306/tyfy?charset=utf8"

# class RedisConfig():
#     redisIp = '192.168.0.203'
#     redisPort = 6379
#     redisPassword = ''
#     redisDb = 0
