import tornado.web
import tornado.httpserver
import tornado.ioloop
import tornado.options
from biz import wordbiz
import tornado.escape
from utils import util
import json
from utils import logindecotor
import os


class WordInsertHandler(tornado.web.RequestHandler):
    @logindecotor.decorator
    def post(self, *args, **kwargs):
        userId = kwargs["data"]["userId"]
        realName = kwargs["data"]["realName"]
        wordId = self.get_body_argument('wordId', '')
        citiao = self.get_body_argument('citiao')
        shiyi = self.get_body_argument('shiyi')
        jybjssm = self.get_body_argument('jybjssm')
        xgayfl = self.get_body_argument('xgayfl')
        xgyjxkdm = self.get_body_argument('xgyjxkdm')
        xgyjxk = self.get_body_argument('xgyjxk')
        xgejxkdm = self.get_body_argument('xgejxkdm')
        xgejxk = self.get_body_argument('xgejxk')
        xgsjxkdm = self.get_body_argument('xgsjxkdm')
        xgsjxk = self.get_body_argument('xgsjxk')
        liju = self.get_body_argument('liju')
        lijushiyi = self.get_body_argument('lijushiyi')
        lijuyy = self.get_body_argument('lijuyy')
        tushiyy = self.get_body_argument('tushiyy')
        biaoge = self.get_body_argument('biaoge')
        biaogeyinyong = self.get_body_argument('biaogeyinyong')
        isinsert = 0
        if wordId == "":
            count = wordbiz.getWordBywordcount(word=citiao)[0]
            if count == 0:
                isinsert = 1
        file_path = ''
        if wordId != '' or isinsert == 1:
            inputfile = self.request.files.get('inputfile', None)
            if inputfile != None:
                for meta in inputfile:
                    file_name = meta['filename']
                    file_path = os.path.join('static', 'image', (userId + "_" + file_name))
                    with open(file_path, 'wb') as up:
                        up.write(meta['body'])
        if isinsert == 1:
            wordbiz.insertWord(userId=userId, realName=realName, citiao=citiao, shiyi=shiyi, jybjssm=jybjssm,
                               xgayfl=xgayfl,
                               xgyjxkdm=xgyjxkdm,
                               xgyjxk=xgyjxk, xgejxkdm=xgejxkdm, xgejxk=xgejxk, xgsjxkdm=xgsjxkdm, xgsnxk=xgsjxk,
                               liju=liju,
                               ljsy=lijushiyi,
                               ljyy=lijuyy, pic=file_path, tsyy=tushiyy, bg=biaoge, bgyy=biaogeyinyong)
        else:
            wordbiz.updateWord(wordId=wordId, citiao=citiao, shiyi=shiyi, jybjssm=jybjssm, xgayfl=xgayfl,
                               xgyjxkdm=xgyjxkdm,
                               xgyjxk=xgyjxk, xgejxkdm=xgejxkdm, xgejxk=xgejxk, xgsjxkdm=xgsjxkdm, xgsnxk=xgsjxk,
                               liju=liju,
                               ljsy=lijushiyi,
                               ljyy=lijuyy, pic=file_path, tsyy=tushiyy, bg=biaoge, bgyy=biaogeyinyong)
        self.redirect('/')


class WordIsexitstHandler(tornado.web.RequestHandler):
    @logindecotor.decorator
    def post(self, *args, **kwargs):
        citiao = self.get_body_argument('citiao')
        count = wordbiz.getWordBywordcount(word=citiao)[0]
        if count > 0:
            self.write({"retCode": 1, "retMessage": "此词条已经存在,您后续的操作都将无效"})
        else:
            self.write({'retCode': 0})


class WordUpdateHandler(tornado.web.RequestHandler):
    @logindecotor.decorator
    def get(self, *args, **kwargs):
        wordId = self.get_argument('wordId')
        word = wordbiz.getWordBywordId(wordId=wordId)
        self.write(word)


class WordDeleteHandler(tornado.web.RequestHandler):
    @logindecotor.decorator
    def get(self, *args, **kwargs):
        wordId = self.get_argument('wordId')
        wordbiz.deleteWordBywordId(wordId=wordId)
        self.redirect('/')


class WordJsLsHandler(tornado.web.RequestHandler):
    @logindecotor.decorator
    def get(self, *args, **kwargs):
        rs = wordbiz.getJsLsInfo()
        self.render('jsliushui.html', result=rs)


class WordSearchHandler(tornado.web.RequestHandler):
    @logindecotor.decorator
    def get(self, *args, **kwargs):
        userId = kwargs["data"]["userId"]
        word = self.get_argument('word')
        rs = wordbiz.getWordByword(word)
        self.render('searresultlist.html', words=rs)


class WordTjCountHandler(tornado.web.RequestHandler):
    @logindecotor.decorator
    def post(self, *args, **kwargs):
        userId = self.get_body_argument('userId')
        start = self.get_body_argument('start')
        end = self.get_body_argument('end')
        rs = wordbiz.getTjWordJk(userId=userId, startTime=start, endTime=end)
        self.write({"retCode": 1, "retMessage": rs})


class WordTjByUserIdHandler(tornado.web.RequestHandler):
    @logindecotor.decorator
    def get(self, *args, **kwargs):
        userId = self.get_argument("userId", '')
        rs = wordbiz.getWordbyUserId(userId=userId)
        self.render('searresultlist.html', words=rs)


class WordTjJSHandler(tornado.web.RequestHandler):
    @logindecotor.decorator
    def get(self, *args, **kwargs):
        userId = self.get_argument("userId", '')
        starttime = self.get_argument("startTime", '').replace('undefined', '')
        starttime = starttime if len(starttime) > 14 else starttime + " 00:00:00"
        endtime = self.get_argument("endtime", '').replace('undefined', '')
        endtime = endtime if len(endtime) > 14 else endtime + " 00:00:00"
        jscount = self.get_argument("count", 0)
        realName = self.get_argument("realName", '')
        wordbiz.wordjs(userId=userId, starttime=starttime, endtime=endtime, count=jscount, realName=realName)
        self.redirect('/wordjsls')


class WordTjQXJSHandler(tornado.web.RequestHandler):
    @logindecotor.decorator
    def get(self, *args, **kwargs):
        jsId = self.get_argument("jsid", 0)
        wordbiz.wordqxjs(jsId)
        self.redirect('/wordjsls')
