import tornado.web
import tornado.httpserver
import tornado.ioloop
import tornado.options
from biz import userbiz, wordbiz
import tornado.escape
from utils import util
import json
from utils import logindecotor
from dao import sessiondao


class MainHandler(tornado.web.RequestHandler):
    def get(self):
        sessionId = self.get_secure_cookie("sessionId")
        data = None
        if sessionId != None:
            data = sessiondao.getSessionBySessionId(sessionId)
            # data = util.getloginredis(sessionId)
        if data == None or sessionId == None:
            self.render(
                "index.html",
            )
        else:
            userId = data.userId
            isadmin = data.isadmin
            if isadmin == 0:
                page = self.get_argument('page', 1)
                page = int(page)
                info = {}
                info["next"] = page + 1
                info["pro"] = page - 1
                info["prostat"] = 1
                info["nextstat"] = 1
                pagecount = 20
                if page <= 1:
                    info["prostat"] = 0
                count = wordbiz.getWordbyUserIdcount(userId)[0]
                pagenum = int(count / pagecount) if count % pagecount == 0 else int(count / pagecount) + 1
                if page >= pagenum:
                    info["nextstat"] = 0
                words = wordbiz.getWordbyUserId(userId=userId, page=page, pagecount=pagecount)
                # todo 得到所有的单词记录
                self.render('wordlist.html', words=words, info=info)
            else:
                info = wordbiz.getTJword()
                self.render('admintj.html', info=info)


class LoginHandler(tornado.web.RequestHandler):
    def post(self, *args, **kwargs):
        phoneNo = self.get_body_argument('phoneNo')
        password = self.get_body_argument('password')
        rs = userbiz.getUserByPhoneNo(phoneNo)
        if rs == None or rs.password != password:
            # respon_json = tornado.escape.json_encode({"retCode": 0, "retMessage": "用户名和密码不匹配"})
            respon_json = {"retCode": 0, "retMessage": "用户名和密码不匹配"}
        else:
            sessionId = util.getUUID()
            self.set_secure_cookie("sessionId", sessionId, expires_days=1)
            sessiondao.insertSessionId(sessionId=sessionId, userId=rs["userId"])
            # util.setloginredis(sessionId=sessionId, userId=rs["userId"], isadmin=rs["isadmin"])
            respon_json = {"retCode": 1, "retMessage": "/"}
        self.write(respon_json)


class RegisterHandler(tornado.web.RequestHandler):
    def get(self, *args, **kwargs):
        self.render('register.html')

    def post(self, *args, **kwargs):
        phoneNo = self.get_body_argument('phoneNo')
        password = self.get_body_argument('password')
        realName = self.get_body_argument('realName')
        rs = userbiz.getUserByPhoneNo(phoneNo)
        if rs:
            respon_json = {"retCode": 0, "retMessage": "此手机号码已存在"}
        else:
            rs = userbiz.insertUser(phoneNo=phoneNo, realName=realName, password=password, bankCard='')
            sessionId = util.getUUID()
            self.set_secure_cookie("sessionId", sessionId, expires_days=1)
            sessiondao.insertSessionId(sessionId=sessionId, userId=rs)
            # util.setloginredis(sessionId=sessionId, userId=rs)
            respon_json = {"retCode": 1, "retMessage": "/"}
        self.write(respon_json)


class InfoUpdataHandler(tornado.web.RequestHandler):
    @logindecotor.decorator
    def get(self, *args, **kwargs):
        userId = kwargs["data"]["userId"]
        rs = userbiz.getUserByUserId(userId)
        self.render('personInfo.html', user=rs)

    @logindecotor.decorator
    def post(self, *args, **kwargs):
        userId = kwargs["data"]["userId"]
        phoneNo = self.get_body_argument('phoneNo')
        realname = self.get_body_argument('realname')
        userbiz.updateUser(phoneNo=phoneNo, realName=realname, userId=userId)
        self.redirect('/')


class LogoutHandler(tornado.web.RequestHandler):
    def get(self, *args, **kwargs):
        sessionId = self.get_secure_cookie("sessionId")
        sessiondao.deleteSessionId(sessionId=sessionId)
        # util.deleteloginredis(sessionId=sessionId)
        self.clear_cookie("sessionId")
        self.redirect('/')

class WordTjByUserId(tornado.web.RequestHandler):
    @logindecotor.decorator
    def get(self, *args, **kwargs):
        userId = kwargs["data"]["userId"]
        info = wordbiz.getTJword(userId=userId)
        self.render('persontj.html',info=info)