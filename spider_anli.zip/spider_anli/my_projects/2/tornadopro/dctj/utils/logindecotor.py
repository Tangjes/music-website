from dao import sessiondao

def decorator(func):
    def decorated_function(self, *args, **kwargs):
        sessionId = self.get_secure_cookie("sessionId")
        data = None
        if sessionId != None:
            data=sessiondao.getSessionBySessionId(sessionId=sessionId)
            # data = util.getloginredis(sessionId)
        if sessionId == None or data == None:
            self.redirect('/')
        else:
            self.set_secure_cookie("sessionId", sessionId.decode('utf8'), expires_days=1)
            func(self, *args, data=data)
            # util.setloginredis(userId=data["userId"], sessionId=sessionId)

    return decorated_function
