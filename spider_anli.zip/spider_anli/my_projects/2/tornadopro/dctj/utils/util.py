import uuid
import hashlib
import logging

try:
    logging.basicConfig(level=logging.INFO,
                        format='[%(asctime)s - %(filename)s -%(funcName)s %(levelname)s]:%(message)s')
    logger = logging.getLogger()
except Exception as e:
    print(e)


def getUUID():
    return str(uuid.uuid4())


def gethertext(text):
    m = hashlib.md5()
    m.update(text)
    return m.hexdigest()

# def setloginredis(userId, sessionId, isadmin=0):
#     value = {"userId": userId, "isadmin": isadmin}
#     setredis(key='user:' + sessionId, value=json.dumps(value))
#
#
# def getloginredis(sessionId):
#     value = getredis(key='user:' + sessionId.decode('utf-8'))
#     if value:
#         return json.loads(value)
#
#
# def deleteloginredis(sessionId):
#     deleteredis(name='user:' + sessionId.decode('utf-8'))
#
#
# def setredis(key, value):
#     try:
#         dbredis.sr.setex(key, value=value, time=1800)
#     except Exception as e:
#         print(e)
#
#
# def getredis(key):
#     value = None
#     try:
#         value = dbredis.sr.get(name=key)
#     except Exception as e:
#         print(e)
#     return value
#
#
# def deleteredis(name):
#     dbredis.sr.delete(name)
