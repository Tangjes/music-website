import tornado.web
import tornado.httpserver
import tornado.ioloop
import tornado.options
import os.path
from views import userview, wordview
from tornado.options import define, options

define("port", default=8010, help="run on the given port", type=int)


class Application(tornado.web.Application):
    def __init__(self):
        handlers = [
            (r"/", userview.MainHandler),
            (r"/loginyz", userview.LoginHandler),
            (r"/register", userview.RegisterHandler),
            (r"/infoupdate", userview.InfoUpdataHandler),
            (r"/wordjsls", wordview.WordJsLsHandler),
            (r"/logout", userview.LogoutHandler),
            (r"/insertWord", wordview.WordInsertHandler),
            (r"/updateword", wordview.WordUpdateHandler),
            (r"/deleteword", wordview.WordDeleteHandler),
            (r"/searchword", wordview.WordSearchHandler),
            (r"/isexitstword", wordview.WordIsexitstHandler),
            (r"/wordtj", wordview.WordTjCountHandler),
            (r"/wordtjbyuserId", wordview.WordTjByUserIdHandler),
            (r"/personwordtj", userview.WordTjByUserId),
            (r"/wordjs", wordview.WordTjJSHandler),
            (r"/quxiaojs", wordview.WordTjQXJSHandler),

        ]
        settings = dict(
            template_path=os.path.join(os.path.dirname(__file__), "templates"),
            static_path=os.path.join(os.path.dirname(__file__), "static"),
            cookie_secret='2bd7rtaw3i7fegrtrhdrytrftey5e',
        )
        tornado.web.Application.__init__(self, handlers, **settings)


if __name__ == "__main__":
    print('正在启动')
    tornado.options.parse_command_line()
    http_server = tornado.httpserver.HTTPServer(Application())
    http_server.listen(options.port)
    print('已启动成功，监听在8010端口')
    tornado.ioloop.IOLoop.instance().start()
