$(function () {
    var _Util = {
        _d: null,
        alert: function (content, timeout, url) {
            var _d = dialog();
            this._d = _d;
            this._d.content(content);
            this._d.showModal();
            setTimeout(function () {
                _Util._d.close();
                if (url != "") {
                    window.location.href = url;
                }
            }, timeout);
        },
        _m: null,
        showM: function (title, id) {
            var _m = dialog({width: 600});
            // this._m.width=400;
            // this._m.top=200;
            this._m = _m;
            this._m.title(title);
            this._m.content(document.getElementById(id));
            this._m.showModal();
        },
        closeM: function () {
            setTimeout(function () {
                _Util._m.close();
            }, 1);
        }

    };
    $("#word_add").bind("click", function () {
        // $("#chId").val("");
        _Util.showM("新增信息", "word_edit_div");
    });
    $("#quxiao").click(function () {
        _Util.closeM();
    });
    $(".word_edit").bind("click", function () {
        var wordId = $(this).attr("data");
        $.get("/updateword?wordId=" + wordId, function (json) {
            $("#wordId").val(wordId);
            $("#citiao").val(json.词条);
            $("#shiyi").val(json.释义);
            $("#jybjssm").val(json.进一步解释和说明);
            $("#xgayfl").val(json.相关的奥运分类);
            $("#xgyjxkdm").val(json.相关一级学科代码);
            $("#xgyjxk").val(json.相关一级学科);
            $("#xgejxkdm").val(json.相关二级学科代码);
            $("#xgejxk").val(json.相关二级学科);
            $("#xgsjxkdm").val(json.相关三级学科代码);
            $("#xgsjxk").val(json.相关三级学科);
            $("#liju").html(json.例句);
            $("#lijushiyi").html(json.例句释义);
            $("#lijuyy").val(json.例句引用);
            $("#tushiyy").val(json.图示引用);
            $("#biaoge").val(json.表格);
            $("#biaogeyinyong").val(json.表格引用);
            $("#pic").attr("src", json.图示图例);
            if (json.是否结算 == 1) {
                $("#tjbd").hide();
                $("#citiao").attr("disabled", true);
                $("#shiyi").attr("disabled", true);
                $("#jybjssm").attr("disabled", true);
                $("#xgayfl").attr("disabled", true);
                $("#xgyjxkdm").attr("disabled", true);
                $("#xgyjxk").attr("disabled", true);
                $("#xgejxkdm").attr("disabled", true);
                $("#xgejxk").attr("disabled", true);
                $("#xgsjxkdm").attr("disabled", true);
                $("#xgsjxk").attr("disabled", true);
                $("#liju").attr("disabled", true);
                $("#lijushiyi").attr("disabled", true);
                $("#lijuyy").attr("disabled", true);
                $("#tushiyy").attr("disabled", true);
                $("#biaoge").attr("disabled", true);
                $("#biaogeyinyong").attr("disabled", true);
                $("#inputfile").attr("disabled", true);
            } else {
                $("#tjbd").show();
                $("#citiao").removeAttr("disabled");
                $("#shiyi").removeAttr("disabled");
                $("#jybjssm").removeAttr("disabled");
                $("#xgayfl").removeAttr("disabled");
                $("#xgyjxkdm").removeAttr("disabled");
                $("#xgyjxk").removeAttr("disabled");
                $("#xgejxkdm").removeAttr("disabled");
                $("#xgejxk").removeAttr("disabled");
                $("#xgsjxkdm").removeAttr("disabled");
                $("#xgsjxk").removeAttr("disabled");
                $("#liju").removeAttr("disabled");
                $("#lijushiyi").removeAttr("disabled");
                $("#lijuyy").removeAttr("disabled");
                $("#tushiyy").removeAttr("disabled");
                $("#biaoge").removeAttr("disabled");
                $("#biaogeyinyong").removeAttr("disabled");
                $("#inputfile").removeAttr("disabled");
            }
            _Util.showM("编辑信息", "word_edit_div");
        }, "json");

    });

});