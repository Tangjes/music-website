class Base():
    def __init__(self):
        self.province = ''
        self.city = ''
        self.url = ''
        self.title = ''
        self.price = ''
        self.chengse = ''  # 成色
        self.sale = ''  # 卖家
        self.phoneNo = ''  # 联系电话
        self.description = ''  # 描述

    def getDataByUrl(self):
        pass

    def insertData(self):
        # TODO 插入完成后，对所有数据清空操作？
        self.__clearAll()
        pass

    def __clearAll(self):
        self.province = ''
        self.city = ''
        self.url = ''
        self.title = ''
        self.price = ''
        self.chengse = ''  # 成色
        self.sale = ''  # 卖家
        self.phoneNo = ''  # 联系电话
        self.description = ''  # 描述
