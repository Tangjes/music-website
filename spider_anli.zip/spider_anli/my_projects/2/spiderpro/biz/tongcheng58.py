from biz import base
from utilz import util
from lxml import etree
import re


class Tongcheng58(base.Base):
    def __init__(self, *args):
        base.Base.__init__(self)
        self.province = args[0]
        self.city = args[1]
        self.__code = args[2]
        self.__type = args[3]

    def main(self):
        for i in range(1, 11):
            # 'http://fz.58.com/shouji/'
            url = "http://%s.58.com/%s/pn%s/" % (self.__code, self.__type, i)
            if self.main2(url) == False:
                return

    def main2(self, url):
        ret = util.get(url)
        if ret["code"] == 0:
            ret = util.get(url)
        if ret["code"] == 0:
            # 需要预警，要不是网络故障，要不就是对方网站url改变规则
            return False
        html = ret['msg'].decode('utf-8')
        xpthinfo = etree.HTML(html)
        data = xpthinfo.xpath('//tbody/tr/td[1]/a/@href')
        if len(data) == 0:
            # 第三方网站改变规则，所以爬虫程序拿不到，此时就要有机制去处理（预警）
            '''
            预警中心提供api接口，程序故障后，调用预警中心的api接口，发送预警通知
            预警中心的接口设计：预警中心接收到预警数据后，调用短信中心的api接口，将数据传送给短信中心，发送短信通知
            '''
            return False
        for item in data:
            self.url = str(item)
            falg = self.getDataByUrl()
            if falg == 1:
                continue
            if self.__detail() == False:
                return False
            self.insertData()

    def __detail(self):
        ret = util.get(self.url)
        if ret["code"] == 0:
            ret = util.get(self.url)
        if ret["code"] == 0:
            # 需要预警，要不是网络故障，要不就是对方网站url改变规则
            return False
        html = ret['msg'].decode('utf-8').replace('\n', '')
        title = re.findall('<h1>(.*?)</h1>', html)
        if len(title) == 0:
            title = re.findall('class="info_titile">(.*?)</h1>', html)
        if len(title) > 0:
            self.title = title[0]
        else:
            # 预警
            pass
        price = re.findall('价格：(.*?)元', html)
        if len(price) == 0:
            price = re.findall('现价：(.*?)元', html)
        if len(price) > 0:
            self.price = util.getNoHtml(price[0])
        else:
            # 预警
            pass
        cs = re.findall('成色：(.*?)</li>', html)
        if len(cs) > 0:
            self.chengse = util.getNoHtml(cs[0])
        else:
            # 预警
            pass
        sale = re.findall("username: '(.*?)'", html)
        if len(cs) > 0:
            self.sale = sale[0]
        else:
            # 预警
            pass
        phone = re.findall('id="t_phone">(.*?)</span>', html)
        if len(phone) > 0:
            self.phoneNo = phone[0]
        else:
            # 预警
            pass
        body = re.findall('class="descriptionBox" >(.*?)联系我时', html)
        if len(body) == 0:
            body = re.findall('class="baby_kuang clearfix">(.*?)<div class="ad_detail_middle">', html)
        if len(body) > 0:
            self.description = body[0]
        else:
            # 预警
            pass
