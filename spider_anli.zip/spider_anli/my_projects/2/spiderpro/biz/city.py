from utilz import util
import re, json


def getCity():
    ret = util.get('http://www.58.com/changecity.html')
    if ret["code"] == 0:
        ret = util.get('http://www.58.com/changecity.html')
    if ret["code"] == 0:
        return
    body = ret["msg"].decode('utf-8').replace('\n', '')
    city = re.findall('cityList = (.*?)</script>', body)
    cityjson = None
    if len(city) > 0:
        cityjson = json.loads(city[0])
        listdata = []
        for key, values in cityjson.items():
            if key in '其他,海外':
                continue
            for key2, val2 in values.items():
                val = val2.split('|')[0]
                cityinfo = {"province": key, "city": key2, "code": val}
                listdata.append(cityinfo)
    return listdata


getCity()
