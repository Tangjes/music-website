import tcwork, diannaowork
from biz import city
import time
import threading


def getShouji():
    while 1:
        data = city.getCity()
        for item in data:
            tcwork.add.delay(province=item["province"], city=item["city"], code=item["code"], type='shouji')
        print('进入休眠1')
        time.sleep(1800)


def getDiannao():
    while 1:
        data = city.getCity()
        for item in data:
            diannaowork.add.delay(province=item["province"], city=item["city"], code=item["code"], type='diannao')
        print('进入休眠2')
        time.sleep(2000)




threads = []
t1 = threading.Thread(target=getDiannao)
threads.append(t1)
t2 = threading.Thread(target=getShouji)
threads.append(t2)

if __name__ == '__main__':
    for t in threads:
        if t.isAlive() == False:
            t.start()
